import sqlite3
from dotenv import load_dotenv
import os
import json
from datetime import datetime

load_dotenv()

class Database:
    def __init__(self):
        self.db_path = os.path.join(os.path.dirname(__file__), 'database', 'bot.db')
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()

    def init_db(self):
        # Create botusers table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS botusers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT UNIQUE NOT NULL,
                username TEXT,
                balance REAL DEFAULT 0,
                mining_rate REAL DEFAULT 0.5,
                invite_code TEXT,
                invite_count INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Create bottasks table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS bottasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_name TEXT NOT NULL,
                reward REAL NOT NULL,
                url TEXT,
                status TEXT DEFAULT 'pending',
                user_id TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES botusers(user_id)
            )
        ''')
        
        self.conn.commit()

    def get_user(self, user_id):
        self.cursor.execute('SELECT * FROM botusers WHERE user_id = ?', (str(user_id),))
        row = self.cursor.fetchone()
        return dict(row) if row else None

    def create_user(self, user_id, username):
        try:
            self.cursor.execute('''
                INSERT INTO botusers (user_id, username)
                VALUES (?, ?)
            ''', (str(user_id), username))
            self.conn.commit()
            return self.get_user(user_id)
        except sqlite3.IntegrityError:
            return self.get_user(user_id)

    def update_user(self, user_id, update_data):
        placeholders = ', '.join([f'{k} = ?' for k in update_data.keys()])
        query = f'UPDATE botusers SET {placeholders} WHERE user_id = ?'
        values = list(update_data.values()) + [str(user_id)]
        self.cursor.execute(query, values)
        self.conn.commit()
        return self.get_user(user_id)

    def create_task(self, task_name, reward, url, user_id):
        self.cursor.execute('''
            INSERT INTO bottasks (task_name, reward, url, user_id)
            VALUES (?, ?, ?, ?)
        ''', (task_name, reward, url, str(user_id)))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_user_tasks(self, user_id):
        self.cursor.execute('SELECT * FROM bottasks WHERE user_id = ?', (str(user_id),))
        return [dict(row) for row in self.cursor.fetchall()]

    def update_task_status(self, task_id, status):
        self.cursor.execute('''
            UPDATE bottasks 
            SET status = ?
            WHERE id = ?
        ''', (status, task_id))
        self.conn.commit()

    def __del__(self):
        if hasattr(self, 'conn'):
            self.conn.close()
