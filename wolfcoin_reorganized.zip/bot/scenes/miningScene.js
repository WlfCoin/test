const { Scenes } = require('telegraf');
const { getMiningKeyboard } = require('../utils/keyboard');
const { formatMiningStatus } = require('../utils/formatter');
const Miner = require('../../backend/models/minerModel');

const miningScene = new Scenes.BaseScene('mining');

miningScene.enter(async (ctx) => {
    try {
        const action = ctx.scene.state.action;
        const userId = ctx.state.user._id;

        // Get miner status
        const miner = await Miner.findOne({ userId })
            .populate('activeBoosts');

        if (!miner) {
            await ctx.reply('❌ Mining profile not found. Please /start again.');
            return ctx.scene.leave();
        }

        // Handle different actions
        if (action) {
            switch (action) {
                case 'start':
                    if (miner.status === 'MINING') {
                        await ctx.reply('⚠️ You are already mining!');
                    } else {
                        await miner.startMining();
                        await ctx.reply(
                            '⛏️ Mining started!\n\n' +
                            formatMiningStatus(miner),
                            { reply_markup: getMiningKeyboard('MINING') }
                        );
                    }
                    break;

                case 'stop':
                    if (miner.status !== 'MINING') {
                        await ctx.reply('⚠️ You are not mining!');
                    } else {
                        await miner.stopMining();
                        await ctx.reply(
                            '⏹️ Mining stopped!\n\n' +
                            formatMiningStatus(miner),
                            { reply_markup: getMiningKeyboard('IDLE') }
                        );
                    }
                    break;

                case 'claim':
                    if (miner.accumulatedPoints <= 0) {
                        await ctx.reply('⚠️ No points to claim!');
                    } else {
                        const points = await miner.claimRewards();
                        await ctx.reply(
                            `💰 Claimed ${points.toFixed(2)} points!\n\n` +
                            formatMiningStatus(miner),
                            { reply_markup: getMiningKeyboard(miner.status) }
                        );
                    }
                    break;
            }
        } else {
            // Show current mining status
            await ctx.reply(
                '⛏️ Mining Status\n\n' + formatMiningStatus(miner),
                { reply_markup: getMiningKeyboard(miner.status) }
            );
        }

        // Schedule status updates if mining
        if (miner.status === 'MINING') {
            ctx.scene.state.statusInterval = setInterval(async () => {
                try {
                    const updatedMiner = await Miner.findOne({ userId })
                        .populate('activeBoosts');
                    
                    if (updatedMiner && updatedMiner.status === 'MINING') {
                        await ctx.reply(
                            '📊 Mining Update\n\n' + 
                            formatMiningStatus(updatedMiner),
                            { reply_markup: getMiningKeyboard('MINING') }
                        );
                    } else {
                        clearInterval(ctx.scene.state.statusInterval);
                    }
                } catch (error) {
                    console.error('Mining status update error:', error);
                    clearInterval(ctx.scene.state.statusInterval);
                }
            }, 5 * 60 * 1000); // Update every 5 minutes
        }
    } catch (error) {
        console.error('Mining scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

// Clear interval when leaving scene
miningScene.leave((ctx) => {
    if (ctx.scene.state.statusInterval) {
        clearInterval(ctx.scene.state.statusInterval);
    }
});

// Handle mining rate boost expiry
const handleBoostExpiry = async (miner) => {
    try {
        const now = new Date();
        const expiredBoosts = miner.activeBoosts.filter(boost => 
            boost.expiresAt && boost.expiresAt <= now
        );

        if (expiredBoosts.length > 0) {
            // Remove expired boosts
            miner.activeBoosts = miner.activeBoosts.filter(boost => 
                !boost.expiresAt || boost.expiresAt > now
            );

            // Recalculate mining rate
            let baseRate = 0.5; // Base mining rate
            miner.activeBoosts.forEach(boost => {
                if (boost.type === 'MINING_RATE') {
                    baseRate += boost.rateIncrease;
                }
            });
            miner.rate = baseRate;

            await miner.save();
        }
    } catch (error) {
        console.error('Boost expiry error:', error);
    }
};

module.exports = { miningScene };
