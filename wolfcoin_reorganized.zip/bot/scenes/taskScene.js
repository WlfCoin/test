const { Scenes } = require('telegraf');
const { getTaskKeyboard } = require('../utils/keyboard');
const { formatTaskInfo } = require('../utils/formatter');
const Task = require('../../backend/models/taskModel');
const Miner = require('../../backend/models/minerModel');
const { verifySocialMedia } = require('../../backend/utils/socialMediaUtils');

const taskScene = new Scenes.BaseScene('task');

taskScene.enter(async (ctx) => {
    try {
        const taskId = ctx.scene.state.taskId;
        const userId = ctx.state.user._id;

        if (taskId) {
            // Handle task verification
            await handleTaskVerification(ctx, taskId, userId);
        } else {
            // Show available tasks
            await showTasks(ctx, userId);
        }
    } catch (error) {
        console.error('Task scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

const showTasks = async (ctx, userId) => {
    // Get all active tasks
    const tasks = await Task.find({ active: true });
    
    // Group tasks by type
    const groupedTasks = {
        COMMUNITY: [],
        PARTNER: [],
        ACADEMY: []
    };

    // Check completion status for each task
    for (const task of tasks) {
        const completed = await task.isCompletedByUser(userId);
        groupedTasks[task.type].push({
            ...task.toObject(),
            completed
        });
    }

    // Send task list for each type
    for (const [type, typeTasks] of Object.entries(groupedTasks)) {
        if (typeTasks.length > 0) {
            let message = `${getTypeEmoji(type)} ${type} Tasks:\n\n`;
            
            typeTasks.forEach((task, index) => {
                message += `${task.completed ? '✅' : '⭕'} ${index + 1}. ${task.title}\n`;
                message += `💰 Reward: ${task.points} points\n\n`;
            });

            await ctx.reply(message, {
                parse_mode: 'HTML',
                reply_markup: getTaskKeyboard(typeTasks)
            });
        }
    }
};

const handleTaskVerification = async (ctx, taskId, userId) => {
    try {
        // Find task
        const task = await Task.findById(taskId);
        if (!task) {
            return ctx.reply('❌ Task not found.');
        }

        // Check if already completed
        if (await task.isCompletedByUser(userId)) {
            return ctx.reply('✅ You have already completed this task!');
        }

        // Show task details
        await ctx.reply(
            `🎯 Task Details:\n\n${formatTaskInfo(task)}\n\n` +
            'Verifying your completion...'
        );

        // Verify task completion
        let verified = false;
        switch (task.verificationMethod) {
            case 'BOT_CHECK':
                // Check if user is member of channel/group
                const chatMember = await ctx.telegram.getChatMember(
                    task.link.split('/').pop(),
                    ctx.from.id
                );
                verified = ['creator', 'administrator', 'member'].includes(
                    chatMember.status
                );
                break;

            case 'API_CHECK':
                // Verify through social media API
                verified = await verifySocialMedia(task.subType, userId);
                break;

            case 'MANUAL_CHECK':
                // Request proof from user
                await ctx.reply(
                    '📸 Please send a screenshot showing you completed the task.'
                );
                // Note: Handle image verification in separate handler
                return;
        }

        if (verified) {
            // Complete task and award points
            await task.completeForUser(userId);

            // Add points to miner
            const miner = await Miner.findOne({ userId });
            miner.totalPoints += task.points;
            await miner.save();

            await ctx.reply(
                `✅ Task completed!\n` +
                `💰 You earned ${task.points} points!\n` +
                `🏦 Total points: ${miner.totalPoints}`
            );
        } else {
            await ctx.reply(
                '❌ Task verification failed.\n' +
                'Please make sure you completed the task correctly and try again.'
            );
        }
    } catch (error) {
        console.error('Task verification error:', error);
        await ctx.reply(
            '❌ Verification failed. Please try again or contact support.'
        );
    }
};

const getTypeEmoji = (type) => {
    switch (type) {
        case 'COMMUNITY':
            return '👥';
        case 'PARTNER':
            return '🤝';
        case 'ACADEMY':
            return '📚';
        default:
            return '🎯';
    }
};

// Handle screenshot verification for manual tasks
taskScene.on('photo', async (ctx) => {
    try {
        const taskId = ctx.scene.state.taskId;
        if (!taskId) return;

        const task = await Task.findById(taskId);
        if (!task || task.verificationMethod !== 'MANUAL_CHECK') return;

        // Store photo for manual verification
        const photoId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
        
        await ctx.reply(
            '📸 Screenshot received!\n' +
            'Our team will verify it and award points soon.\n' +
            'Please check back later.'
        );

        // Notify admins (implement your notification system)
        notifyAdmins(ctx, task, photoId);
    } catch (error) {
        console.error('Screenshot handling error:', error);
        await ctx.reply('❌ Error processing screenshot. Please try again.');
    }
});

const notifyAdmins = async (ctx, task, photoId) => {
    // Implement your admin notification system
    // This is just a placeholder
    console.log('Task verification needed:', {
        taskId: task._id,
        userId: ctx.state.user._id,
        photoId
    });
};

module.exports = { taskScene };
