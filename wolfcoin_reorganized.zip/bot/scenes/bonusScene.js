const { Scenes } = require('telegraf');
const { getBonusKeyboard } = require('../utils/keyboard');
const { formatBonusInfo } = require('../utils/formatter');
const Bonus = require('../../backend/models/bonusModel');
const Miner = require('../../backend/models/minerModel');

const bonusScene = new Scenes.BaseScene('bonus');

bonusScene.enter(async (ctx) => {
    try {
        const action = ctx.scene.state.action;
        const userId = ctx.state.user._id;

        if (action === 'claim') {
            // Handle bonus claim
            await handleBonusClaim(ctx, userId);
        } else {
            // Show bonus status
            await showBonusStatus(ctx, userId);
        }
    } catch (error) {
        console.error('Bonus scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

const showBonusStatus = async (ctx, userId) => {
    try {
        // Get user's bonus info
        let bonus = await Bonus.findOne({ userId });
        
        // Create bonus record if it doesn't exist
        if (!bonus) {
            bonus = await Bonus.create({
                userId,
                lastClaim: new Date(0), // Set to past date
                streakDays: 0
            });
        }

        // Calculate time until next claim
        const now = new Date();
        const lastClaim = new Date(bonus.lastClaim);
        const nextClaimTime = new Date(lastClaim);
        nextClaimTime.setHours(0, 0, 0, 0);
        nextClaimTime.setDate(nextClaimTime.getDate() + 1);

        const timeUntilNextClaim = Math.max(0, nextClaimTime - now);
        const canClaim = timeUntilNextClaim === 0;

        // Calculate next bonus amount
        const nextBonus = calculateBonusAmount(bonus.streakDays);

        const bonusInfo = {
            ...bonus.toObject(),
            timeUntilNextClaim,
            canClaim,
            nextBonus
        };

        // Show bonus status
        await ctx.reply(
            '🎁 Daily Bonus Status\n\n' +
            formatBonusInfo(bonusInfo),
            {
                parse_mode: 'HTML',
                reply_markup: getBonusKeyboard(canClaim)
            }
        );

        // Schedule reminder if can't claim yet
        if (!canClaim) {
            ctx.scene.state.reminderTimeout = setTimeout(async () => {
                try {
                    await ctx.reply(
                        '🎁 Your daily bonus is ready to claim!',
                        {
                            reply_markup: getBonusKeyboard(true)
                        }
                    );
                } catch (error) {
                    console.error('Bonus reminder error:', error);
                }
            }, timeUntilNextClaim);
        }
    } catch (error) {
        console.error('Show bonus status error:', error);
        await ctx.reply(
            '❌ Error loading bonus status. Please try again.'
        );
    }
};

const handleBonusClaim = async (ctx, userId) => {
    try {
        // Get user's bonus info
        let bonus = await Bonus.findOne({ userId });
        if (!bonus) {
            return ctx.reply('❌ Bonus record not found. Please try again.');
        }

        // Check if can claim
        const now = new Date();
        const lastClaim = new Date(bonus.lastClaim);
        const nextClaimTime = new Date(lastClaim);
        nextClaimTime.setHours(0, 0, 0, 0);
        nextClaimTime.setDate(nextClaimTime.getDate() + 1);

        if (now < nextClaimTime) {
            return ctx.reply(
                '⚠️ Too early for next claim!\n' +
                formatBonusInfo({
                    ...bonus.toObject(),
                    timeUntilNextClaim: nextClaimTime - now,
                    canClaim: false,
                    nextBonus: calculateBonusAmount(bonus.streakDays)
                })
            );
        }

        // Check streak
        const oneDayMs = 24 * 60 * 60 * 1000;
        const daysSinceLastClaim = Math.floor(
            (now - lastClaim) / oneDayMs
        );

        // Reset streak if more than one day passed
        if (daysSinceLastClaim > 1) {
            bonus.streakDays = 0;
        }

        // Calculate bonus amount
        const bonusAmount = calculateBonusAmount(bonus.streakDays);

        // Update bonus record
        bonus.lastClaim = now;
        bonus.streakDays++;
        await bonus.save();

        // Add points to miner
        const miner = await Miner.findOne({ userId });
        miner.totalPoints += bonusAmount;
        await miner.save();

        // Send success message
        await ctx.reply(
            '✅ Daily bonus claimed!\n\n' +
            `💰 You received ${bonusAmount} points\n` +
            `🔥 Current streak: ${bonus.streakDays} days\n` +
            `🏦 Total points: ${miner.totalPoints}\n\n` +
            `Come back tomorrow for your next bonus!`
        );
    } catch (error) {
        console.error('Bonus claim error:', error);
        await ctx.reply(
            '❌ Error claiming bonus. Please try again.'
        );
    }
};

const calculateBonusAmount = (streakDays) => {
    // Base bonus amount
    let amount = 10;

    // Add streak bonus
    if (streakDays >= 30) {
        amount *= 5; // 5x bonus for 30+ days streak
    } else if (streakDays >= 14) {
        amount *= 3; // 3x bonus for 14+ days streak
    } else if (streakDays >= 7) {
        amount *= 2; // 2x bonus for 7+ days streak
    }

    return amount;
};

// Clear reminder timeout when leaving scene
bonusScene.leave((ctx) => {
    if (ctx.scene.state.reminderTimeout) {
        clearTimeout(ctx.scene.state.reminderTimeout);
    }
});

module.exports = { bonusScene };
