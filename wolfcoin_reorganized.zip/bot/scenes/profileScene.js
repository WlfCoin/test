const { Scenes } = require('telegraf');
const { getProfileKeyboard } = require('../utils/keyboard');
const { formatPoints, formatDuration } = require('../utils/formatter');
const User = require('../../backend/models/userModel');
const Miner = require('../../backend/models/minerModel');
const Bonus = require('../../backend/models/bonusModel');
const Task = require('../../backend/models/taskModel');

const profileScene = new Scenes.BaseScene('profile');

profileScene.enter(async (ctx) => {
    try {
        await showProfile(ctx, ctx.state.user._id);
    } catch (error) {
        console.error('Profile scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

const showProfile = async (ctx, userId) => {
    try {
        // Get user data
        const user = await User.findById(userId);
        const miner = await Miner.findOne({ userId })
            .populate('activeBoosts');
        const bonus = await Bonus.findOne({ userId });

        // Get task completion stats
        const tasks = await Task.find({ active: true });
        let completedTasks = 0;
        for (const task of tasks) {
            if (await task.isCompletedByUser(userId)) {
                completedTasks++;
            }
        }

        // Calculate mining stats
        const totalMined = miner.totalPoints;
        const currentRate = miner.rate;
        const activeBoosts = miner.activeBoosts.length;
        const offlineTime = miner.offlineDuration;

        // Calculate bonus stats
        const streakDays = bonus ? bonus.streakDays : 0;
        const nextBonus = calculateNextBonus(streakDays);

        // Generate referral stats
        const referralCount = await User.countDocuments({
            referredBy: user._id
        });
        const referralPoints = referralCount * 2; // 2 points per referral

        // Format profile message
        let message = `👤 Profile: ${user.username}\n\n`;

        // Mining stats
        message += '⛏️ Mining Stats:\n';
        message += `💰 Total Points: ${formatPoints(totalMined)}\n`;
        message += `⚡ Mining Rate: ${currentRate.toFixed(2)} points/hour\n`;
        message += `🚀 Active Boosts: ${activeBoosts}\n`;
        message += `⏰ Offline Mining: ${formatDuration(offlineTime)}\n\n`;

        // Task stats
        message += '🎯 Task Stats:\n';
        message += `✅ Completed: ${completedTasks}/${tasks.length}\n`;
        message += `📊 Progress: ${Math.round(completedTasks/tasks.length*100)}%\n\n`;

        // Bonus stats
        message += '🎁 Bonus Stats:\n';
        message += `🔥 Streak: ${streakDays} days\n`;
        message += `💎 Next Bonus: ${nextBonus} points\n\n`;

        // Referral stats
        message += '👥 Referral Stats:\n';
        message += `🔗 Referrals: ${referralCount}\n`;
        message += `💰 Earned: ${referralPoints} points\n`;
        
        // Add referral link
        const botUsername = (await ctx.telegram.getMe()).username;
        const referralLink = 
            `https://t.me/${botUsername}?start=${user.referralCode}`;
        message += `\n📢 Your Referral Link:\n${referralLink}`;

        // Send profile with keyboard
        await ctx.reply(message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: getProfileKeyboard()
        });
    } catch (error) {
        console.error('Show profile error:', error);
        await ctx.reply(
            '❌ Error loading profile. Please try again.'
        );
    }
};

// Handle profile menu actions
profileScene.action('profile_stats', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const miner = await Miner.findOne({ userId });

        // Calculate mining stats
        const hourlyStats = await calculateHourlyStats(miner);
        const dailyStats = await calculateDailyStats(miner);
        const weeklyStats = await calculateWeeklyStats(miner);

        let message = '📊 Detailed Statistics\n\n';

        // Hourly stats
        message += '⏱️ Last Hour:\n';
        message += `Points: ${formatPoints(hourlyStats.points)}\n`;
        message += `Rate: ${hourlyStats.rate.toFixed(2)} points/hour\n\n`;

        // Daily stats
        message += '📅 Last 24 Hours:\n';
        message += `Points: ${formatPoints(dailyStats.points)}\n`;
        message += `Average Rate: ${dailyStats.avgRate.toFixed(2)} points/hour\n`;
        message += `Active Time: ${formatDuration(dailyStats.activeTime)}\n\n`;

        // Weekly stats
        message += '📆 Last 7 Days:\n';
        message += `Points: ${formatPoints(weeklyStats.points)}\n`;
        message += `Average Daily: ${formatPoints(weeklyStats.avgDaily)}\n`;
        message += `Best Day: ${formatPoints(weeklyStats.bestDay)}\n`;

        await ctx.editMessageText(message, {
            parse_mode: 'HTML',
            reply_markup: getProfileKeyboard()
        });
    } catch (error) {
        console.error('Stats error:', error);
        await ctx.reply('❌ Error loading statistics.');
    }
});

profileScene.action('profile_history', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        
        // Get recent activities
        const activities = await getRecentActivities(userId);

        let message = '📜 Recent Activity\n\n';

        activities.forEach((activity, index) => {
            message += `${index + 1}. ${formatActivity(activity)}\n`;
        });

        await ctx.editMessageText(message, {
            parse_mode: 'HTML',
            reply_markup: getProfileKeyboard()
        });
    } catch (error) {
        console.error('History error:', error);
        await ctx.reply('❌ Error loading history.');
    }
});

profileScene.action('profile_settings', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const user = await User.findById(userId);

        let message = '⚙️ Settings\n\n';
        
        // Notification settings
        message += '🔔 Notifications:\n';
        message += `Mining Updates: ${user.settings?.miningUpdates ? '✅' : '❌'}\n`;
        message += `Bonus Reminders: ${user.settings?.bonusReminders ? '✅' : '❌'}\n`;
        message += `Task Alerts: ${user.settings?.taskAlerts ? '✅' : '❌'}\n\n`;

        // Display settings
        message += '🎨 Display:\n';
        message += `Points Format: ${user.settings?.pointsFormat || 'Default'}\n`;
        message += `Time Format: ${user.settings?.timeFormat || '24h'}\n\n`;

        // Add settings keyboard
        const settingsKeyboard = {
            inline_keyboard: [
                [
                    {
                        text: 'Toggle Mining Updates',
                        callback_data: 'toggle_mining_updates'
                    }
                ],
                [
                    {
                        text: 'Toggle Bonus Reminders',
                        callback_data: 'toggle_bonus_reminders'
                    }
                ],
                [
                    {
                        text: 'Toggle Task Alerts',
                        callback_data: 'toggle_task_alerts'
                    }
                ],
                [
                    {
                        text: 'Change Points Format',
                        callback_data: 'change_points_format'
                    }
                ],
                [
                    {
                        text: 'Change Time Format',
                        callback_data: 'change_time_format'
                    }
                ],
                [
                    {
                        text: '« Back to Profile',
                        callback_data: 'back_to_profile'
                    }
                ]
            ]
        };

        await ctx.editMessageText(message, {
            parse_mode: 'HTML',
            reply_markup: settingsKeyboard
        });
    } catch (error) {
        console.error('Settings error:', error);
        await ctx.reply('❌ Error loading settings.');
    }
});

// Helper functions
const calculateNextBonus = (streakDays) => {
    let amount = 10;
    if (streakDays >= 30) amount *= 5;
    else if (streakDays >= 14) amount *= 3;
    else if (streakDays >= 7) amount *= 2;
    return amount;
};

const calculateHourlyStats = async (miner) => {
    // Implement hourly stats calculation
    return {
        points: 0,
        rate: 0
    };
};

const calculateDailyStats = async (miner) => {
    // Implement daily stats calculation
    return {
        points: 0,
        avgRate: 0,
        activeTime: 0
    };
};

const calculateWeeklyStats = async (miner) => {
    // Implement weekly stats calculation
    return {
        points: 0,
        avgDaily: 0,
        bestDay: 0
    };
};

const getRecentActivities = async (userId) => {
    // Implement recent activities retrieval
    return [];
};

const formatActivity = (activity) => {
    // Implement activity formatting
    return '';
};

module.exports = { profileScene };
