const { Scenes } = require('telegraf');
const { getBoostKeyboard } = require('../utils/keyboard');
const { formatBoostInfo } = require('../utils/formatter');
const Boost = require('../../backend/models/boostModel');
const Miner = require('../../backend/models/minerModel');
const { verifyTonTransaction } = require('../../backend/utils/tonUtils');

const boostScene = new Scenes.BaseScene('boost');

boostScene.enter(async (ctx) => {
    try {
        const { type, level } = ctx.scene.state;
        const userId = ctx.state.user._id;

        if (type && level) {
            // Handle boost purchase
            await handleBoostPurchase(ctx, type, level, userId);
        } else {
            // Show available boosts
            await showBoosts(ctx, userId);
        }
    } catch (error) {
        console.error('Boost scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

const showBoosts = async (ctx, userId) => {
    try {
        // Get all available boosts
        const boosts = await Boost.find({ active: true });
        
        // Get user's miner to check active boosts
        const miner = await Miner.findOne({ userId })
            .populate('activeBoosts');

        let message = '🚀 Available Boosts\n\n';

        // Group boosts by type
        const miningBoosts = boosts.filter(b => b.type === 'MINING_RATE');
        const offlineBoosts = boosts.filter(b => b.type === 'OFFLINE_TIME');

        // Show mining rate boosts
        if (miningBoosts.length > 0) {
            message += '⚡ Mining Rate Boosts:\n\n';
            for (const boost of miningBoosts) {
                const isActive = miner.activeBoosts.some(
                    ab => ab._id.equals(boost._id)
                );
                message += formatBoostInfo(boost) + 
                    (isActive ? '\n✅ Active' : '') + '\n\n';
            }
        }

        // Show offline time boosts
        if (offlineBoosts.length > 0) {
            message += '⏰ Offline Time Boosts:\n\n';
            for (const boost of offlineBoosts) {
                const isActive = miner.activeBoosts.some(
                    ab => ab._id.equals(boost._id)
                );
                message += formatBoostInfo(boost) + 
                    (isActive ? '\n✅ Active' : '') + '\n\n';
            }
        }

        await ctx.reply(message, {
            parse_mode: 'HTML',
            reply_markup: getBoostKeyboard(boosts)
        });
    } catch (error) {
        console.error('Show boosts error:', error);
        await ctx.reply(
            '❌ Error loading boosts. Please try again.'
        );
    }
};

const handleBoostPurchase = async (ctx, type, level, userId) => {
    try {
        // Find boost
        const boost = await Boost.findOne({ type, level });
        if (!boost) {
            return ctx.reply('❌ Boost not found.');
        }

        // Get user's miner
        const miner = await Miner.findOne({ userId })
            .populate('activeBoosts');

        // Check if boost is already active
        const isActive = miner.activeBoosts.some(
            ab => ab._id.equals(boost._id)
        );
        if (isActive) {
            return ctx.reply('⚠️ This boost is already active!');
        }

        // Ask user to choose payment method
        await ctx.reply(
            `Choose payment method for ${boost.name}:\n\n` +
            `1️⃣ Points: ${boost.cost.points}\n` +
            `2️⃣ TON: ${boost.cost.ton}`,
            {
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: '💰 Pay with Points',
                                callback_data: `boost_points:${boost._id}`
                            }
                        ],
                        [
                            {
                                text: '💎 Pay with TON',
                                callback_data: `boost_ton:${boost._id}`
                            }
                        ]
                    ]
                }
            }
        );
    } catch (error) {
        console.error('Boost purchase error:', error);
        await ctx.reply(
            '❌ Error processing purchase. Please try again.'
        );
    }
};

// Handle points payment
boostScene.action(/boost_points:(.+)/, async (ctx) => {
    try {
        const boostId = ctx.match[1];
        const userId = ctx.state.user._id;

        // Find boost and miner
        const boost = await Boost.findById(boostId);
        const miner = await Miner.findOne({ userId });

        if (!boost || !miner) {
            return ctx.reply('❌ Invalid boost or miner not found.');
        }

        // Check if user has enough points
        if (miner.totalPoints < boost.cost.points) {
            return ctx.reply(
                '❌ Not enough points!\n' +
                `Required: ${boost.cost.points}\n` +
                `Available: ${miner.totalPoints}`
            );
        }

        // Deduct points and activate boost
        miner.totalPoints -= boost.cost.points;
        await activateBoost(boost, miner);

        await ctx.reply(
            '✅ Boost activated successfully!\n\n' +
            formatBoostInfo(boost) + '\n\n' +
            `Remaining points: ${miner.totalPoints}`
        );
    } catch (error) {
        console.error('Points payment error:', error);
        await ctx.reply(
            '❌ Payment failed. Please try again.'
        );
    }
});

// Handle TON payment
boostScene.action(/boost_ton:(.+)/, async (ctx) => {
    try {
        const boostId = ctx.match[1];
        const userId = ctx.state.user._id;

        // Find boost
        const boost = await Boost.findById(boostId);
        if (!boost) {
            return ctx.reply('❌ Boost not found.');
        }

        // Generate payment address and amount
        const { address, amount } = await generateTonPayment(boost.cost.ton);

        await ctx.reply(
            '💎 TON Payment Details\n\n' +
            `Amount: ${amount} TON\n` +
            `Address: ${address}\n\n` +
            'Please send the exact amount to activate your boost.\n' +
            'The boost will be activated automatically after payment confirmation.'
        );

        // Start payment check interval
        ctx.scene.state.paymentInterval = setInterval(async () => {
            try {
                const verified = await verifyTonTransaction(address, amount);
                if (verified) {
                    clearInterval(ctx.scene.state.paymentInterval);

                    // Activate boost
                    const miner = await Miner.findOne({ userId });
                    await activateBoost(boost, miner);

                    await ctx.reply(
                        '✅ Payment received! Boost activated successfully!\n\n' +
                        formatBoostInfo(boost)
                    );
                }
            } catch (error) {
                console.error('Payment check error:', error);
            }
        }, 30 * 1000); // Check every 30 seconds
    } catch (error) {
        console.error('TON payment error:', error);
        await ctx.reply(
            '❌ Payment setup failed. Please try again.'
        );
    }
});

// Clear payment check interval when leaving scene
boostScene.leave((ctx) => {
    if (ctx.scene.state.paymentInterval) {
        clearInterval(ctx.scene.state.paymentInterval);
    }
});

const activateBoost = async (boost, miner) => {
    // Set boost expiry time
    const now = new Date();
    boost.expiresAt = new Date(
        now.getTime() + boost.duration * 1000
    );

    // Add boost to miner's active boosts
    miner.activeBoosts.push(boost);

    // Update mining rate if it's a rate boost
    if (boost.type === 'MINING_RATE') {
        miner.rate += boost.rateIncrease;
    }
    // Update offline duration if it's an offline boost
    else if (boost.type === 'OFFLINE_TIME') {
        miner.offlineDuration += boost.offlineDuration;
    }

    await miner.save();
};

const generateTonPayment = async (amount) => {
    // Implement TON payment address generation
    // This is just a placeholder
    return {
        address: 'EQD...',  // Your TON wallet address
        amount: amount
    };
};

module.exports = { boostScene };
