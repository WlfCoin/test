const { Scenes } = require('telegraf');
const { mainKeyboard } = require('../utils/keyboard');
const User = require('../../backend/models/userModel');
const Miner = require('../../backend/models/minerModel');
const { generateToken } = require('../../backend/utils/authUtils');

const startScene = new Scenes.BaseScene('start');

startScene.enter(async (ctx) => {
    try {
        const telegramId = ctx.from.id.toString();
        const username = ctx.from.username;
        
        // Check if user already exists
        let user = await User.findOne({ telegramId });
        let isNewUser = false;

        if (!user) {
            // Create new user
            user = await User.create({
                telegramId,
                username,
                registeredAt: new Date()
            });

            // Create miner for the user
            await Miner.create({
                userId: user._id,
                deviceId: `telegram_${telegramId}`
            });

            isNewUser = true;
        }

        // Generate JWT token
        const token = generateToken({
            id: user._id,
            telegramId
        });

        // Store token in user document
        user.token = token;
        await user.save();

        // Welcome message
        let message = isNewUser ? 
            `🎉 Welcome to WolfCoin Mining Bot!\n\n` +
            `You've successfully registered and received:\n` +
            `- 🎮 Access to mining game\n` +
            `- 🎯 Access to tasks\n` +
            `- 🎁 Daily bonus system\n` +
            `- 🚀 Boost shop\n\n` +
            `Use the menu below to start your mining journey!` :
            `👋 Welcome back to WolfCoin Mining Bot!\n\n` +
            `Your mining journey continues. Use the menu below to:\n` +
            `- ⛏️ Start mining\n` +
            `- 🎯 Complete tasks\n` +
            `- 🎁 Claim daily bonus\n` +
            `- 🚀 Buy boosts`;

        // Add referral info if user was referred
        const referralCode = ctx.startPayload;
        if (isNewUser && referralCode) {
            try {
                const referrer = await User.findOne({ 
                    referralCode: referralCode 
                });

                if (referrer && referrer.telegramId !== telegramId) {
                    // Add referral bonus
                    const referrerMiner = await Miner.findOne({
                        userId: referrer._id
                    });
                    referrerMiner.totalPoints += 2; // Referrer gets 2 points
                    await referrerMiner.save();

                    const newUserMiner = await Miner.findOne({
                        userId: user._id
                    });
                    newUserMiner.totalPoints += 10; // New user gets 10 points
                    await newUserMiner.save();

                    message += `\n\n🎁 You received 10 points from referral!`;
                }
            } catch (error) {
                console.error('Referral error:', error);
            }
        }

        // Generate user's referral link if they don't have one
        if (!user.referralCode) {
            user.referralCode = generateReferralCode();
            await user.save();
        }

        // Add referral link to message
        const botUsername = (await ctx.telegram.getMe()).username;
        const referralLink = `https://t.me/${botUsername}?start=${user.referralCode}`;
        message += `\n\n📢 Share your referral link:\n${referralLink}`;

        // Send welcome message with main keyboard
        await ctx.reply(message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            ...mainKeyboard
        });

        // Leave scene
        await ctx.scene.leave();
    } catch (error) {
        console.error('Start scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

// Generate random referral code
const generateReferralCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
};

module.exports = { startScene };
