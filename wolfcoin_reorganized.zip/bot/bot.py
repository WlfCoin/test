import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, WebAppInfo
from datetime import datetime
import pytz
from dotenv import load_dotenv
import os
import schedule
import time
import random
from database import Database

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
CHANNEL_ID = "@WolfCoin_news"
ACTIVITY_CHANNEL = "@Activityofprojectusers"
TOTAL_SUPPLY = 120_000_000_000
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://wolfcoin.net")

bot = telebot.TeleBot(BOT_TOKEN)
db = Database()

# Admin panel states
class AdminState:
    SEND_MESSAGE = "send_message"
    CONFIRM_MESSAGE = "confirm_message"
    SEND_REWARD = "send_reward"
    SEND_REWARD_AMOUNT = "send_reward_amount"
    BLOCK_USER = "block_user"
    CONFIRM_BLOCK = "confirm_block"
    WAITING_2FA_SETUP = "WAITING_2FA_SETUP"
    WAITING_2FA_LOGIN = "WAITING_2FA_LOGIN"
    WAITING_2FA_CODE = "WAITING_2FA_CODE"
    WAITING_2FA_VERIFY = "WAITING_2FA_VERIFY"

admin_states = {}
temp_data = {}

def is_user_in_channel(user_id):
    try:
        member = bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        return member.status in ["member", "administrator", "creator"]
    except Exception:
        return False

def is_admin(user_id):
    try:
        current_id = int(user_id)
        result = current_id == ADMIN_ID
        print(f"Admin check: user_id={current_id}, ADMIN_ID={ADMIN_ID}, result={result}")
        return result
    except Exception as e:
        print(f"Error in admin check: {e}")
        return False

def get_2fa_status(user_id):
    return db.get_2fa_status(user_id)

def save_2fa_secret(user_id, secret):
    db.save_2fa_secret(user_id, secret)

@bot.message_handler(commands=['start'])
def welcome_message(message):
    user_id = message.from_user.id
    username = message.from_user.username

    if not is_user_in_channel(user_id):
        bot.reply_to(
            message,
            "⚠️ To enter the Wolf Coin Hunt, membership in the community channel "
            "https://t.me/wolfCoin_news is required. Please join first and restart the bot."
        )
        return

    # Check if user was invited
    if len(message.text.split()) > 1:
        inviter_id = int(message.text.split()[1])
        if inviter_id != user_id:  # Prevent self-invitation
            db.invite_user(inviter_id, user_id)
            # Add 2 points to inviter
            db.update_balance(inviter_id, 2)
            # Send notification to activity channel
            bot.send_message(
                ACTIVITY_CHANNEL,
                f"🎉 New referral! User earned 2 points for inviting a new member!"
            )

    # Register user
    db.register_user(user_id, username)

    try:
        # Send welcome message with photo
        photo_path = 'wellcombaner.jpg'
        with open(photo_path, 'rb') as photo:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🎮 Start Mining", web_app=WebAppInfo(url=WEBAPP_URL)))
            markup.add(
                InlineKeyboardButton("Community", url="https://t.me/wolfCoin_news"),
                InlineKeyboardButton("Activity", url="https://t.me/Activityofprojectusers")
            )
            markup.add(
                InlineKeyboardButton("Twitter", url="https://x.com/wlfcoinofficial"),
                InlineKeyboardButton("YouTube", url="http://www.youtube.com/@WolfCoinOfficial")
            )
            markup.add(
                InlineKeyboardButton("Instagram", url="https://www.instagram.com/wolfcoin.official"),
                InlineKeyboardButton("Get Invite Link", callback_data="get_invite")
            )

            bot.send_photo(
                message.chat.id,
                photo,
                caption=(
                    "Hello, welcome to wolf hunting.\n"
                    "Stay in the pack of wolves, let everyone know that the top hunter has come, "
                    "we will show no mercy, soon those who did not join us will definitely regret it.\n"
                    "Remember this name because you will hear it a lot in the future: Wolfcoin.\n"
                    "The hunt has started. If you want to be a part of the team and not starve, start now."
                ),
                reply_markup=markup
            )
    except Exception as e:
        print(f"Error sending welcome message: {e}")
        # Fallback message if photo sending fails
        bot.send_message(
            message.chat.id,
            "Hello, welcome to wolf hunting.\n"
            "Stay in the pack of wolves, let everyone know that the top hunter has come, "
            "we will show no mercy, soon those who did not join us will definitely regret it.\n"
            "Remember this name because you will hear it a lot in the future: Wolfcoin.\n"
            "The hunt has started. If you want to be a part of the team and not starve, start now.",
            reply_markup=markup
        )

@bot.callback_query_handler(func=lambda call: call.data == "get_invite")
def generate_invite_link(call):
    user_id = call.from_user.id
    invite_link = f"https://t.me/{bot.get_me().username}?start={user_id}"
    bot.answer_callback_query(call.id)
    bot.send_message(
        call.message.chat.id,
        f"🔗 Your invite link:\n{invite_link}\n\n"
        "Share this link with friends to earn 2 points for each invite!"
    )

# Admin Panel
@bot.message_handler(commands=['ad_panel'])
def admin_panel(message):
    user_id = message.from_user.id
    print(f"Admin panel requested by user {user_id}")
    
    if not is_admin(user_id):
        print(f"Access denied for user {user_id}")
        bot.reply_to(message, "⚠️ You don't have permission to access this panel.")
        return

    print(f"Access granted for admin {user_id}")
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("📨 Send Message to All", callback_data="admin_broadcast"))
    markup.add(InlineKeyboardButton("🎁 Send Reward", callback_data="admin_reward"))
    markup.add(InlineKeyboardButton("🚫 Block Users", callback_data="admin_block"))

    bot.reply_to(message, "👑 Admin Panel", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_"))
def admin_panel_handler(call):
    if not is_admin(call.from_user.id):
        return

    user_id = call.from_user.id
    action = call.data.split("_")[1]

    if action == "broadcast":
        admin_states[user_id] = AdminState.SEND_MESSAGE
        bot.send_message(user_id, "Send me the message you want to send to users")

    elif action == "reward":
        admin_states[user_id] = AdminState.SEND_REWARD
        bot.send_message(user_id, "Please enter the desired username or user ID")

    elif action == "block":
        admin_states[user_id] = AdminState.BLOCK_USER
        bot.send_message(
            user_id,
            "Please send the username or numerical ID of the desired person:\n\n"
            "Send /cancel to cancel the operation."
        )

@bot.message_handler(func=lambda message: is_admin(message.from_user.id) and message.from_user.id in admin_states)
def handle_admin_actions(message):
    user_id = message.from_user.id
    state = admin_states.get(user_id)

    if message.text == "/cancel":
        admin_states.pop(user_id, None)
        temp_data.pop(user_id, None)
        bot.reply_to(message, "Operation cancelled.")
        return

    if state == AdminState.SEND_MESSAGE:
        temp_data[user_id] = {"message": message.text}
        admin_states[user_id] = AdminState.CONFIRM_MESSAGE
        markup = InlineKeyboardMarkup()
        markup.add(
            InlineKeyboardButton("Yes", callback_data="confirm_broadcast_yes"),
            InlineKeyboardButton("No", callback_data="confirm_broadcast_no")
        )
        bot.reply_to(message, "You confirm sending the message?", reply_markup=markup)

    elif state == AdminState.SEND_REWARD:
        try:
            target_user = message.text.lstrip('@')  # حذف @ از اول نام کاربری
            user = db.get_user(target_user)
            
            if user:
                temp_data[user_id] = {"target_user_id": user["_id"]}
                admin_states[user_id] = AdminState.SEND_REWARD_AMOUNT
                bot.reply_to(
                    message,
                    f"User found: {user['username'] or user['_id']}\n"
                    f"How many points do you want to send?\n\n"
                    "Enter /cancel to cancel the operation."
                )
            else:
                bot.reply_to(
                    message, 
                    "User not found. Please make sure the username or ID is correct and the user has started the bot."
                )
                admin_states.pop(user_id, None)
        except Exception as e:
            bot.reply_to(message, f"Error: {str(e)}")
            admin_states.pop(user_id, None)

    elif state == AdminState.SEND_REWARD_AMOUNT:
        try:
            amount = int(message.text)
            target_user_id = temp_data[user_id]["target_user_id"]
            
            db.update_balance(target_user_id, amount)

            bot.send_message(
                target_user_id,
                f"🌟💥 Congratulations ⭐️☄\n"
                f"{amount} points were sent to you by the administration"
            )
            bot.reply_to(message, f"Successfully sent {amount} points.")
            
            admin_states.pop(user_id, None)
            temp_data.pop(user_id, None)
        except ValueError:
            bot.reply_to(message, "Please enter a valid number.")
        except Exception as e:
            bot.reply_to(message, f"Error: {str(e)}")
            admin_states.pop(user_id, None)

    elif state == AdminState.BLOCK_USER:
        try:
            target_user = message.text
            user = db.get_user(target_user)
            
            if user:
                temp_data[user_id] = {"target_user_id": user["_id"]}
                admin_states[user_id] = AdminState.CONFIRM_BLOCK
                markup = InlineKeyboardMarkup()
                markup.add(
                    InlineKeyboardButton("Yes", callback_data="confirm_block_yes"),
                    InlineKeyboardButton("No", callback_data="confirm_block_no")
                )
                bot.reply_to(
                    message,
                    f"Target user: {user['username']}\nDo you want to continue?",
                    reply_markup=markup
                )
            else:
                bot.reply_to(message, "User not found.")
                admin_states.pop(user_id, None)
        except Exception as e:
            bot.reply_to(message, f"Error: {str(e)}")
            admin_states.pop(user_id, None)

@bot.callback_query_handler(func=lambda call: call.data.startswith("confirm_"))
def handle_admin_confirmations(call):
    if not is_admin(call.from_user.id):
        return

    user_id = call.from_user.id
    action = call.data.split("_")[1]
    confirm = call.data.split("_")[2]

    if action == "broadcast" and confirm == "yes":
        message_text = temp_data[user_id]["message"]
        users = db.get_users()
        
        success = 0
        failed = 0
        for user in users:
            try:
                bot.send_message(user["_id"], message_text)
                success += 1
            except:
                failed += 1

        bot.edit_message_text(
            f"Message sent to {success} users\nFailed: {failed}",
            call.message.chat.id,
            call.message.message_id
        )

    elif action == "block" and confirm == "yes":
        target_user_id = temp_data[user_id]["target_user_id"]
        db.block_user(target_user_id)
        
        bot.edit_message_text(
            "User has been blocked.",
            call.message.chat.id,
            call.message.message_id
        )

    admin_states.pop(user_id, None)
    temp_data.pop(user_id, None)

@bot.message_handler(commands=['login'])
def admin_login(message):
    try:
        user_id = message.from_user.id
        print(f"Login attempt by user {user_id}")  # برای دیباگ

        if not is_admin(user_id):
            print(f"User {user_id} is not admin")  # برای دیباگ
            bot.reply_to(message, "⚠️ This command is only available for administrators.")
            return

        print(f"User {user_id} is admin, checking 2FA status")  # برای دیباگ
        two_fa_secret = get_2fa_status(user_id)
        
        if not two_fa_secret:
            print(f"Setting up 2FA for user {user_id}")  # برای دیباگ
            # First time setup - store state
            admin_states[user_id] = "WAITING_2FA_SETUP"
            markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
            markup.add(telebot.types.KeyboardButton('Setup 2FA'))
            
            bot.reply_to(
                message,
                "🔐 Welcome! You need to set up Two-Factor Authentication.\n"
                "Click 'Setup 2FA' to continue.",
                reply_markup=markup
            )
        else:
            print(f"2FA already set up for user {user_id}, requesting code")  # برای دیباگ
            # Already set up, ask for code
            admin_states[user_id] = "WAITING_2FA_CODE"
            markup = telebot.types.ReplyKeyboardRemove()
            bot.reply_to(
                message,
                "🔐 Please enter your 6-digit authentication code:",
                reply_markup=markup
            )
    except Exception as e:
        print(f"Error in admin_login: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred. Please try again later.")

@bot.message_handler(func=lambda message: message.text == 'Setup 2FA')
def setup_2fa(message):
    try:
        user_id = message.from_user.id
        print(f"Setup 2FA attempt by user {user_id}")  # برای دیباگ
        
        if not is_admin(user_id) or admin_states.get(user_id) != "WAITING_2FA_SETUP":
            print(f"Invalid setup attempt: admin={is_admin(user_id)}, state={admin_states.get(user_id)}")  # برای دیباگ
            return

        # Generate random secret
        secret = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        temp_data[user_id] = {"temp_2fa_secret": secret}
        
        markup = telebot.types.ReplyKeyboardRemove()
        bot.reply_to(
            message,
            f"🔐 Your secret code is: {secret}\n\n"
            "Please save this code securely and enter it back to verify:",
            reply_markup=markup
        )
        admin_states[user_id] = "WAITING_2FA_VERIFY"
    except Exception as e:
        print(f"Error in setup_2fa: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred. Please try again later.")

@bot.message_handler(func=lambda message: admin_states.get(message.from_user.id) in ["WAITING_2FA_CODE", "WAITING_2FA_VERIFY"])
def verify_2fa(message):
    try:
        user_id = message.from_user.id
        print(f"Verify 2FA attempt by user {user_id}")  # برای دیباگ
        
        if not is_admin(user_id):
            print(f"User {user_id} is not admin")  # برای دیباگ
            return

        state = admin_states.get(user_id)
        entered_code = message.text.strip()

        if state == "WAITING_2FA_VERIFY":
            # Verifying during setup
            stored_secret = temp_data.get(user_id, {}).get("temp_2fa_secret")
            if not stored_secret:
                bot.reply_to(message, "⚠️ Something went wrong. Please try /login again.")
                admin_states.pop(user_id, None)
                return

            if entered_code == stored_secret:
                save_2fa_secret(user_id, stored_secret)
                temp_data.pop(user_id, None)
                admin_states.pop(user_id, None)
                send_admin_panel(message)
            else:
                bot.reply_to(message, "❌ Invalid code. Please try again or use /login to restart.")

        elif state == "WAITING_2FA_CODE":
            # Verifying during login
            stored_secret = get_2fa_status(user_id)
            if entered_code == stored_secret:
                admin_states.pop(user_id, None)
                send_admin_panel(message)
            else:
                bot.reply_to(message, "❌ Invalid code. Please try again or use /login to restart.")
    except Exception as e:
        print(f"Error in verify_2fa: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred. Please try again later.")

def send_admin_panel(message):
    try:
        keyboard = telebot.types.InlineKeyboardMarkup()
        webapp_btn = telebot.types.InlineKeyboardButton(
            text="Open Admin Panel",
            web_app=telebot.types.WebAppInfo(url=f"{WEBAPP_URL}/admin")
        )
        keyboard.add(webapp_btn)
        bot.reply_to(
            message,
            "✅ 2FA verification successful!\n\n"
            "Welcome to the admin panel. Click below to access the management interface:",
            reply_markup=keyboard
        )
    except Exception as e:
        print(f"Error in send_admin_panel: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred while opening admin panel.")

def daily_report():
    try:
        tehran_tz = pytz.timezone('Asia/Tehran')
        now = datetime.now(tehran_tz)
        
        if now.hour == 15:  # 15:00 Tehran time
            total_extracted = db.get_total_extracted()
            remaining_supply = TOTAL_SUPPLY - total_extracted

            report = (
                f"📊 Daily Report\n\n"
                f"Total Extracted: {total_extracted:,} points\n"
                f"Remaining Supply: {remaining_supply:,} points\n"
                f"Progress: {(total_extracted/TOTAL_SUPPLY*100):.2f}%\n\n"
                f"Keep mining and stay in the hunt! 🐺"
            )
            bot.send_message(ACTIVITY_CHANNEL, report)
    except Exception as e:
        print(f"Error in daily_report: {e}")

def schedule_checker():
    while True:
        schedule.run_pending()
        time.sleep(1)

# Initialize database and start bot
if __name__ == "__main__":
    db.init_db()
    schedule.every().hour.at(":00").do(daily_report)
    
    try:
        import threading
        threading.Thread(target=schedule_checker).start()
        
        print("Bot started successfully!")
        bot.infinity_polling()
    except Exception as e:
        print(f"Bot stopped due to error: {e}")
        bot.stop_polling()
