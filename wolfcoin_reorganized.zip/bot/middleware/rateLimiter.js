const rateLimit = require('telegraf-ratelimit');

const rateLimiter = rateLimit({
    window: 1000, // 1 second
    limit: 1,
    onLimitExceeded: (ctx) =>
        ctx.reply(
            '⚠️ Please slow down! You are sending commands too quickly.'
        )
});
