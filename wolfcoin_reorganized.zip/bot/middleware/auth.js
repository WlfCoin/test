const jwt = require('jsonwebtoken');
const User = require('../../backend/models/userModel');

const authenticate = async (ctx, next) => {
    try {
        // Skip authentication for start command
        if (ctx.message && ctx.message.text === '/start') {
            return next();
        }

        const telegramId = ctx.from.id.toString();
        
        // Find or create user
        let user = await User.findOne({ telegramId });
        
        if (!user) {
            return ctx.reply(
                '🚫 Please start the bot first using /start command'
            );
        }

        // Add user to context
        ctx.state.user = user;
        
        return next();
    } catch (error) {
        console.error('Authentication error:', error);
        return ctx.reply(
            '❌ Authentication failed. Please try again or contact support.'
        );
    }
};
