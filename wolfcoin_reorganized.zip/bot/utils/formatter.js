const formatPoints = (points) => {
    if (points >= 1e9) {
        return `${(points / 1e9).toFixed(2)}B`;
    }
    if (points >= 1e6) {
        return `${(points / 1e6).toFixed(2)}M`;
    }
    if (points >= 1e3) {
        return `${(points / 1e3).toFixed(2)}K`;
    }
    return points.toFixed(2);
};

const formatDuration = (ms) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
        return `${days}d ${hours % 24}h`;
    }
    if (hours > 0) {
        return `${hours}h ${minutes % 60}m`;
    }
    if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
};

const formatMiningStatus = (miner) => {
    const status = miner.status === 'MINING' ? '⛏️ Mining' : '💤 Idle';
    const rate = `⚡ Rate: ${miner.rate.toFixed(2)} points/hour`;
    const points = `💰 Points: ${formatPoints(miner.accumulatedPoints)}`;
    const total = `🏦 Total: ${formatPoints(miner.totalPoints)}`;
    const offline = `⏰ Offline Mining: ${formatDuration(miner.offlineDuration)}`;

    return `
Status: ${status}
${rate}
${points}
${total}
${offline}
    `.trim();
};

const formatBoostInfo = (boost) => {
    const type = boost.type === 'MINING_RATE' ? 
        '⚡ Mining Rate' : '⏰ Offline Duration';
    const level = `📊 Level ${boost.level}`;
    const effect = boost.type === 'MINING_RATE' ?
        `Rate: +${boost.rateIncrease.toFixed(2)} points/hour` :
        `Duration: +${formatDuration(boost.offlineDuration)}`;
    const cost = `💰 Cost: ${formatPoints(boost.cost.points)} points or ${boost.cost.ton} TON`;

    return `
${type}
${level}
${effect}
${cost}
    `.trim();
};

const formatTaskInfo = (task) => {
    const type = {
        'COMMUNITY': '👥 Community',
        'PARTNER': '🤝 Partner',
        'ACADEMY': '📚 Academy'
    }[task.type];

    const platform = {
        'TELEGRAM': '📱 Telegram',
        'TWITTER': '🐦 Twitter',
        'YOUTUBE': '▶️ YouTube',
        'INSTAGRAM': '📸 Instagram'
    }[task.subType];

    return `
${type} - ${platform}
${task.title}
${task.description}
💰 Reward: ${task.points} points
🔗 Link: ${task.link}
    `.trim();
};

const formatBonusInfo = (bonus) => {
    const streak = `🔥 Streak: ${bonus.streakDays} days`;
    const nextBonus = `🎁 Next Bonus: ${bonus.nextBonus} points`;
    const canClaim = bonus.canClaim ? 
        '✅ Ready to claim!' : 
        `⏳ Next claim in: ${formatDuration(bonus.timeUntilNextClaim)}`;

    return `
${streak}
${nextBonus}
${canClaim}
    `.trim();
};

module.exports = {
    formatPoints,
    formatDuration,
    formatMiningStatus,
    formatBoostInfo,
    formatTaskInfo,
    formatBonusInfo
};
