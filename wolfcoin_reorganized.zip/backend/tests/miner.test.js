const { initializeTables, runQuery } = require('../config/db');
const Miner = require('../models/minerModel');
const request = require('supertest');
const app = require('../app');
const { generateToken } = require('../utils/authUtils');

describe('Miner API Tests', () => {
    beforeAll(async () => {
        await initializeTables();
    });

    beforeEach(async () => {
        // Clear miners table before each test
        await runQuery('DELETE FROM miner');
    });

    afterAll(async () => {
        // Clean up database
        await runQuery('DELETE FROM miner');
    });

    const testUser = {
        id: 'test123',
        telegramId: '12345'
    };
    const token = generateToken(testUser);
    const deviceId = 'test-device-123';

    describe('POST /api/miner/start', () => {
        it('should start mining successfully', async () => {
            const res = await request(app)
                .post('/api/miner/start')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.status).toBe('MINING');
            expect(res.body.data.rate).toBe(0.5); // Base rate
        });

        it('should not allow mining with duplicate device ID', async () => {
            // Create a miner with the same device ID but different user
            await Miner.create({
                userId: 'other-user',
                deviceId,
                status: 'IDLE'
            });

            const res = await request(app)
                .post('/api/miner/start')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
        });
    });

    describe('POST /api/miner/stop', () => {
        it('should stop mining and calculate rewards', async () => {
            // Create an active miner
            const miner = await Miner.create({
                userId: testUser.id,
                deviceId,
                status: 'MINING',
                lastMiningTime: new Date(Date.now() - 3600000) // 1 hour ago
            });

            const res = await request(app)
                .post('/api/miner/stop')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.status).toBe('IDLE');
            expect(res.body.data.accumulatedPoints).toBeCloseTo(0.5); // 0.5 points per hour
        });
    });

    describe('POST /api/miner/claim', () => {
        it('should claim accumulated points successfully', async () => {
            // Create a miner with accumulated points
            const miner = await Miner.create({
                userId: testUser.id,
                deviceId,
                status: 'IDLE',
                accumulatedPoints: 10
            });

            const res = await request(app)
                .post('/api/miner/claim')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.claimedPoints).toBe(10);
            expect(res.body.data.totalPoints).toBe(10);
        });

        it('should not allow claiming with no points', async () => {
            await Miner.create({
                userId: testUser.id,
                deviceId,
                status: 'IDLE',
                accumulatedPoints: 0
            });

            const res = await request(app)
                .post('/api/miner/claim')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
        });
    });

    describe('GET /api/miner/status', () => {
        it('should return correct mining status and calculations', async () => {
            // Create a mining session
            const miner = await Miner.create({
                userId: testUser.id,
                deviceId,
                status: 'MINING',
                rate: 0.5,
                lastMiningTime: new Date(Date.now() - 1800000) // 30 minutes ago
            });

            const res = await request(app)
                .get('/api/miner/status')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.status).toBe('MINING');
            expect(res.body.data.rate).toBe(0.5);
            expect(res.body.data.accumulatedPoints).toBeCloseTo(0.25); // 0.5 points/hour * 0.5 hours
        });
    });
});
