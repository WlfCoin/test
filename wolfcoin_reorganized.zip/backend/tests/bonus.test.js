const { initializeTables, runQuery } = require('../config/db');
const request = require('supertest');
const app = require('../app');
const Bonus = require('../models/bonusModel');
const Miner = require('../models/minerModel');
const { generateToken } = require('../utils/authUtils');

describe('Bonus API Tests', () => {
    beforeAll(async () => {
        await initializeTables();
    });

    beforeEach(async () => {
        // Clear bonus and miner tables before each test
        await runQuery('DELETE FROM bonus');
        await runQuery('DELETE FROM miner');
    });

    afterAll(async () => {
        // Clean up database
        await runQuery('DELETE FROM bonus');
        await runQuery('DELETE FROM miner');
    });

    const testUser = {
        id: 'test123',
        telegramId: '12345'
    };
    const token = generateToken(testUser);
    const deviceId = 'test-device-123';

    describe('GET /api/bonus/status', () => {
        it('should create and return bonus status for new user', async () => {
            const res = await request(app)
                .get('/api/bonus/status')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.streakDays).toBe(0);
            expect(res.body.data.nextBonus).toBe(1); // Starting bonus
            expect(res.body.data.canClaim).toBe(true);
        });

        it('should return existing bonus status', async () => {
            // Create bonus with streak
            await runQuery('INSERT INTO bonus (userId, streakDays, lastClaimed) VALUES (?, ?, ?)', [testUser.id, 5, new Date(Date.now() - 25 * 60 * 60 * 1000)]);

            const res = await request(app)
                .get('/api/bonus/status')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.streakDays).toBe(5);
            expect(res.body.data.nextBonus).toBe(3.5); // 1 + (5 * 0.5)
            expect(res.body.data.canClaim).toBe(true);
        });
    });

    describe('POST /api/bonus/claim/streak', () => {
        beforeEach(async () => {
            // Create miner for the user
            await runQuery('INSERT INTO miner (userId, deviceId, totalPoints) VALUES (?, ?, ?)', [testUser.id, deviceId, 0]);
        });

        it('should claim first day bonus successfully', async () => {
            const res = await request(app)
                .post('/api/bonus/claim/streak')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.bonusAmount).toBe(1); // First day bonus
            expect(res.body.data.streakDays).toBe(1);
            expect(res.body.data.nextBonus).toBe(1.5); // 1 + (1 * 0.5)

            // Verify points were added to miner
            const miner = await runQuery('SELECT * FROM miner WHERE userId = ?', [testUser.id]);
            expect(miner[0].totalPoints).toBe(1);
        });

        it('should handle streak bonus correctly', async () => {
            // Create bonus with existing streak
            await runQuery('INSERT INTO bonus (userId, streakDays, lastClaimed) VALUES (?, ?, ?)', [testUser.id, 5, new Date(Date.now() - 25 * 60 * 60 * 1000)]);

            const res = await request(app)
                .post('/api/bonus/claim/streak')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.bonusAmount).toBe(3.5); // 1 + (5 * 0.5)
            expect(res.body.data.streakDays).toBe(6);
            expect(res.body.data.nextBonus).toBe(4); // 1 + (6 * 0.5)

            // Verify points were added to miner
            const miner = await runQuery('SELECT * FROM miner WHERE userId = ?', [testUser.id]);
            expect(miner[0].totalPoints).toBe(3.5);
        });

        it('should not allow claiming twice in same day', async () => {
            // Create recently claimed bonus
            await runQuery('INSERT INTO bonus (userId, streakDays, lastClaimed) VALUES (?, ?, ?)', [testUser.id, 1, new Date()]);

            const res = await request(app)
                .post('/api/bonus/claim/streak')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
            expect(res.body.error).toContain('Cannot claim bonus now');
        });

        it('should reset streak after 30 days', async () => {
            // Create bonus with max streak
            await runQuery('INSERT INTO bonus (userId, streakDays, lastClaimed) VALUES (?, ?, ?)', [testUser.id, 30, new Date(Date.now() - 25 * 60 * 60 * 1000)]);

            const res = await request(app)
                .post('/api/bonus/claim/streak')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.streakDays).toBe(1); // Reset to 1
            expect(res.body.data.nextBonus).toBe(1.5); // Reset to base + 0.5
        });
    });

    describe('GET /api/bonus/history', () => {
        it('should return bonus claim history', async () => {
            // Create bonus with history
            await runQuery('INSERT INTO bonus (userId, streakDays, history) VALUES (?, ?, ?)', [testUser.id, 3, JSON.stringify([
                {
                    type: 'STREAK',
                    amount: 1,
                    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000)
                },
                {
                    type: 'STREAK',
                    amount: 1.5,
                    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000)
                }
            ])]);

            const res = await request(app)
                .get('/api/bonus/history')
                .set('Authorization', `Bearer ${token}`);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.history).toHaveLength(2);
            expect(res.body.data.history[0].type).toBe('STREAK');
            expect(res.body.data.history[0].amount).toBe(1.5);
        });

        it('should return empty history for new user', async () => {
            const res = await request(app)
                .get('/api/bonus/history')
                .set('Authorization', `Bearer ${token}`);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.history).toHaveLength(0);
        });
    });
});
