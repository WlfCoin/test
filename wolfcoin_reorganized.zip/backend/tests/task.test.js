const { initializeTables, runQuery } = require('../config/db');
const request = require('supertest');
const app = require('../app');
const Task = require('../models/taskModel');
const Miner = require('../models/minerModel');
const { generateToken } = require('../utils/authUtils');
const { verifySocialMedia } = require('../utils/socialMediaUtils');

// Mock social media verification
jest.mock('../utils/socialMediaUtils');

describe('Task API Tests', () => {
    beforeAll(async () => {
        await initializeTables();
    });

    beforeEach(async () => {
        // Clear tasks and miners tables before each test
        await runQuery('DELETE FROM task');
        await runQuery('DELETE FROM miner');
        jest.clearAllMocks();
    });

    afterAll(async () => {
        // Clean up database
        await runQuery('DELETE FROM task');
        await runQuery('DELETE FROM miner');
    });

    const testUser = {
        id: 'test123',
        telegramId: '12345'
    };
    const token = generateToken(testUser);
    const deviceId = 'test-device-123';

    describe('GET /api/task', () => {
        beforeEach(async () => {
            // Create some test tasks
            await runQuery(`
                INSERT INTO task (type, sub_type, title, description, link, points, active, verification_method)
                VALUES ('COMMUNITY', 'TELEGRAM', 'Join Telegram', 'Join our Telegram group', 'https://t.me/test', 2, 1, 'BOT_CHECK')
            `);
            await runQuery(`
                INSERT INTO task (type, sub_type, title, description, link, points, active, verification_method)
                VALUES ('PARTNER', 'TWITTER', 'Follow Twitter', 'Follow our Twitter', 'https://twitter.com/test', 3, 1, 'API_CHECK')
            `);
        });

        it('should return grouped tasks with completion status', async () => {
            const res = await request(app)
                .get('/api/task')
                .set('Authorization', `Bearer ${token}`);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.COMMUNITY).toBeDefined();
            expect(res.body.data.PARTNER).toBeDefined();
            expect(res.body.data.COMMUNITY).toHaveLength(1);
            expect(res.body.data.PARTNER).toHaveLength(1);
            expect(res.body.data.COMMUNITY[0].completed).toBe(false);
        });
    });

    describe('POST /api/task/verify/social', () => {
        let taskId;

        beforeEach(async () => {
            // Create a test task and miner
            await runQuery(`
                INSERT INTO task (type, sub_type, title, description, link, points, active, verification_method)
                VALUES ('COMMUNITY', 'TELEGRAM', 'Join Telegram', 'Join our Telegram group', 'https://t.me/test', 2, 1, 'BOT_CHECK')
            `);
            const task = await runQuery('SELECT * FROM task ORDER BY id DESC LIMIT 1');
            taskId = task[0].id;

            await runQuery(`
                INSERT INTO miner (user_id, device_id, total_points)
                VALUES ('${testUser.id}', '${deviceId}', 0)
            `);

            // Mock successful social media verification
            verifySocialMedia.mockResolvedValue(true);
        });

        it('should verify and complete social media task', async () => {
            const res = await request(app)
                .post('/api/task/verify/social')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    taskId,
                    platform: 'TELEGRAM'
                });

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.points).toBe(2);

            // Verify points were added to miner
            const miner = await runQuery(`SELECT * FROM miner WHERE user_id = '${testUser.id}'`);
            expect(miner[0].total_points).toBe(2);

            // Verify task was marked as completed
            const task = await runQuery(`SELECT * FROM task WHERE id = ${taskId}`);
            expect(task[0].is_completed_by_user).toBe(true);
        });

        it('should not allow completing same task twice', async () => {
            // Complete task first time
            await request(app)
                .post('/api/task/verify/social')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    taskId,
                    platform: 'TELEGRAM'
                });

            // Try to complete again
            const res = await request(app)
                .post('/api/task/verify/social')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    taskId,
                    platform: 'TELEGRAM'
                });

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
            expect(res.body.error).toContain('Task already completed');
        });

        it('should handle failed verification', async () => {
            // Mock failed verification
            verifySocialMedia.mockResolvedValue(false);

            const res = await request(app)
                .post('/api/task/verify/social')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    taskId,
                    platform: 'TELEGRAM'
                });

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
            expect(res.body.error).toContain('Social media verification failed');
        });
    });

    describe('GET /api/task/history', () => {
        beforeEach(async () => {
            // Create tasks with completion history
            await runQuery(`
                INSERT INTO task (type, sub_type, title, description, link, points, active, verification_method, completion_history)
                VALUES ('COMMUNITY', 'TELEGRAM', 'Join Telegram', 'Join our group', 'https://t.me/test', 2, 1, 'BOT_CHECK', '[{"userId": "${testUser.id}", "completedAt": "2022-01-01T00:00:00.000Z", "pointsEarned": 2}]')
            `);
        });

        it('should return user\'s task completion history', async () => {
            const res = await request(app)
                .get('/api/task/history')
                .set('Authorization', `Bearer ${token}`);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.history).toHaveLength(1);
            expect(res.body.data.history[0].type).toBe('COMMUNITY');
            expect(res.body.data.history[0].points).toBe(2);
        });
    });

    describe('POST /api/task/init', () => {
        const adminUser = {
            id: 'admin123',
            telegramId: '54321',
            isAdmin: true
        };
        const adminToken = generateToken(adminUser);

        it('should initialize default tasks for admin', async () => {
            const res = await request(app)
                .post('/api/task/init')
                .set('Authorization', `Bearer ${adminToken}`);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);

            // Verify default tasks were created
            const tasks = await runQuery('SELECT * FROM task');
            expect(tasks.length).toBeGreaterThan(0);
            expect(tasks.some(t => t.type === 'COMMUNITY')).toBe(true);
        });

        it('should not allow non-admin to initialize tasks', async () => {
            const res = await request(app)
                .post('/api/task/init')
                .set('Authorization', `Bearer ${token}`);

            expect(res.status).toBe(403);
            expect(res.body.success).toBe(false);
            expect(res.body.error).toContain('Admin access required');
        });
    });
});
