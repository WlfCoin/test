const { initializeTables, runQuery } = require('../config/db');
const request = require('supertest');
const app = require('../app');
const User = require('../models/userModel');
const Miner = require('../models/minerModel');
const Boost = require('../models/boostModel');

describe('Integration Tests', () => {
    beforeAll(async () => {
        await initializeTables();
    });

    beforeEach(async () => {
        // Clear all tables before each test
        await runQuery('DELETE FROM user');
        await runQuery('DELETE FROM miner');
        await runQuery('DELETE FROM boost');
    });

    afterAll(async () => {
        // Clean up database
        await runQuery('DELETE FROM user');
        await runQuery('DELETE FROM miner');
        await runQuery('DELETE FROM boost');
    });

    describe('Complete User Journey', () => {
        const testUser = {
            id: 'test123',
            telegramId: '12345',
            username: 'testuser'
        };
        const token = 'test-token';
        const deviceId = 'test-device-123';

        it('should handle complete user flow successfully', async () => {
            // 1. User Registration
            const registerRes = await request(app)
                .post('/api/auth/register')
                .send({
                    telegramId: testUser.telegramId,
                    username: testUser.username
                });
            expect(registerRes.status).toBe(200);
            expect(registerRes.body.success).toBe(true);

            // 2. Start Mining
            const startMiningRes = await request(app)
                .post('/api/miner/start')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);
            expect(startMiningRes.status).toBe(200);
            expect(startMiningRes.body.data.status).toBe('MINING');

            // 3. Check Mining Status
            const statusRes = await request(app)
                .get('/api/miner/status')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);
            expect(statusRes.status).toBe(200);
            expect(statusRes.body.data.status).toBe('MINING');

            // 4. Apply Boost
            const boostRes = await request(app)
                .post('/api/boost/apply')
                .set('Authorization', `Bearer ${token}`)
                .send({
                    type: 'MINING_RATE',
                    value: 2,
                    duration: 3600
                });
            expect(boostRes.status).toBe(200);

            // 5. Check Active Boosts
            const activeBoostsRes = await request(app)
                .get('/api/boost/active')
                .set('Authorization', `Bearer ${token}`);
            expect(activeBoostsRes.status).toBe(200);
            expect(activeBoostsRes.body.data.length).toBeGreaterThan(0);

            // 6. Check Updated Mining Rate
            const updatedStatusRes = await request(app)
                .get('/api/miner/status')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);
            expect(updatedStatusRes.status).toBe(200);
            expect(updatedStatusRes.body.data.rate).toBeGreaterThan(0.5);

            // 7. Stop Mining
            const stopMiningRes = await request(app)
                .post('/api/miner/stop')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);
            expect(stopMiningRes.status).toBe(200);
            expect(stopMiningRes.body.data.status).toBe('IDLE');
        });

        it('should handle offline mining correctly', async () => {
            // 1. Apply Offline Duration Boost
            await request(app)
                .post('/api/boost/apply')
                .set('Authorization', `Bearer ${token}`)
                .send({
                    type: 'OFFLINE_DURATION',
                    value: 24,
                    duration: 86400
                });

            // 2. Start Mining
            await request(app)
                .post('/api/miner/start')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            // 3. Simulate offline time
            const miner = await Miner.findOne({ deviceId });
            miner.lastUpdate = new Date(Date.now() - 3600000); // 1 hour ago
            await miner.save();

            // 4. Check Mining Status
            const statusRes = await request(app)
                .get('/api/miner/status')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);
            expect(statusRes.status).toBe(200);
            expect(statusRes.body.data.offlineEarnings).toBeGreaterThan(0);
        });

        it('should handle multiple devices correctly', async () => {
            const devices = ['device1', 'device2', 'device3'];
            
            // Start mining on all devices
            const startPromises = devices.map(deviceId =>
                request(app)
                    .post('/api/miner/start')
                    .set('Authorization', `Bearer ${token}`)
                    .set('X-Device-ID', deviceId)
            );
            
            const results = await Promise.all(startPromises);
            results.forEach(res => {
                expect(res.status).toBe(200);
                expect(res.body.data.status).toBe('MINING');
            });

            // Check status of all devices
            const statusPromises = devices.map(deviceId =>
                request(app)
                    .get('/api/miner/status')
                    .set('Authorization', `Bearer ${token}`)
                    .set('X-Device-ID', deviceId)
            );
            
            const statusResults = await Promise.all(statusPromises);
            statusResults.forEach(res => {
                expect(res.status).toBe(200);
                expect(res.body.data.status).toBe('MINING');
            });
        });
    });
});
