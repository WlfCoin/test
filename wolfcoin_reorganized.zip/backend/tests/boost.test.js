const { initializeTables, runQuery } = require('../config/db');
const Boost = require('../models/boostModel');
const Miner = require('../models/minerModel');
const User = require('../models/userModel');
const cache = require('../utils/cache');
const { generateToken } = require('../utils/authUtils');
const { verifyTonTransaction } = require('../utils/tonUtils');

// Mock TON transaction verification
jest.mock('../utils/tonUtils');

describe('Boost API Tests', () => {
    const testUser = {
        id: 'test123',
        telegramId: '12345'
    };
    const token = generateToken(testUser);
    const deviceId = 'test-device-123';

    beforeAll(async () => {
        await initializeTables();
    });

    beforeEach(async () => {
        // Clear boosts, miners, and users tables before each test
        await runQuery('DELETE FROM boost');
        await runQuery('DELETE FROM miner');
        await runQuery('DELETE FROM user');
        await cache.flush();
        jest.clearAllMocks();
    });

    afterAll(async () => {
        // Clean up database
        await runQuery('DELETE FROM boost');
        await runQuery('DELETE FROM miner');
        await runQuery('DELETE FROM user');
    });

    describe('GET /api/boost/available', () => {
        it('should return available boosts', async () => {
            const res = await request(app)
                .get('/api/boost/available')
                .set('Authorization', `Bearer ${token}`);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.miningRate).toBeDefined();
            expect(res.body.data.offlineDuration).toBeDefined();
            expect(Array.isArray(res.body.data.miningRate)).toBe(true);
            expect(Array.isArray(res.body.data.offlineDuration)).toBe(true);
        });
    });

    describe('POST /api/boost/purchase/points', () => {
        beforeEach(async () => {
            // Create a miner with points
            await Miner.create({
                userId: testUser.id,
                deviceId,
                totalPoints: 1000,
                rate: 0.5
            });
        });

        it('should purchase mining rate boost with points', async () => {
            const res = await request(app)
                .post('/api/boost/purchase/points')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    type: 'MINING_RATE',
                    level: 1
                });

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.boost.type).toBe('MINING_RATE');
            expect(res.body.data.boost.level).toBe(1);

            // Verify miner's points were deducted
            const miner = await Miner.findOne({ userId: testUser.id });
            expect(miner.totalPoints).toBeLessThan(1000);
            expect(miner.rate).toBeGreaterThan(0.5);
        });

        it('should not allow purchase with insufficient points', async () => {
            // Update miner to have 0 points
            await Miner.updateOne(
                { userId: testUser.id },
                { totalPoints: 0 }
            );

            const res = await request(app)
                .post('/api/boost/purchase/points')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    type: 'MINING_RATE',
                    level: 1
                });

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
            expect(res.body.error).toContain('Insufficient points');
        });
    });

    describe('POST /api/boost/purchase/ton', () => {
        beforeEach(async () => {
            // Create a miner
            await Miner.create({
                userId: testUser.id,
                deviceId,
                rate: 0.5
            });

            // Mock successful TON transaction verification
            verifyTonTransaction.mockResolvedValue(true);
        });

        it('should purchase offline duration boost with TON', async () => {
            const res = await request(app)
                .post('/api/boost/purchase/ton')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    type: 'OFFLINE_DURATION',
                    level: 1,
                    transactionHash: 'test-hash-123'
                });

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.boost.type).toBe('OFFLINE_DURATION');
            expect(res.body.data.boost.level).toBe(1);

            // Verify miner's offline duration was increased
            const miner = await Miner.findOne({ userId: testUser.id });
            expect(miner.offlineDuration).toBeGreaterThan(4 * 60 * 60 * 1000);
        });

        it('should not allow purchase with invalid transaction', async () => {
            // Mock failed transaction verification
            verifyTonTransaction.mockResolvedValue(false);

            const res = await request(app)
                .post('/api/boost/purchase/ton')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId)
                .send({
                    type: 'OFFLINE_DURATION',
                    level: 1,
                    transactionHash: 'invalid-hash'
                });

            expect(res.status).toBe(400);
            expect(res.body.success).toBe(false);
            expect(res.body.error).toContain('Invalid transaction');
        });
    });

    describe('GET /api/boost/active', () => {
        it('should return active boosts for user', async () => {
            // Create some active boosts
            await Boost.create([
                {
                    userId: testUser.id,
                    type: 'MINING_RATE',
                    level: 1,
                    active: true
                },
                {
                    userId: testUser.id,
                    type: 'OFFLINE_DURATION',
                    level: 1,
                    active: true
                }
            ]);

            const res = await request(app)
                .get('/api/boost/active')
                .set('Authorization', `Bearer ${token}`)
                .set('X-Device-ID', deviceId);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(res.body.data.boosts).toHaveLength(2);
            expect(res.body.data.boosts[0].active).toBe(true);
            expect(res.body.data.boosts[1].active).toBe(true);
        });
    });

    describe('GET /api/boosts/active/:userId', () => {
        it('should return active boosts for user', async () => {
            // Create test user
            const user = await User.create({
                _id: 'test-user',
                currentMiningRate: 0.5
            });

            // Create active boost
            const boost = await Boost.create({
                userId: user._id,
                type: 'MINING_RATE',
                level: 1,
                rateIncrease: 0.1,
                startTime: new Date(),
                endTime: new Date(Date.now() + 24 * 60 * 60 * 1000)
            });

            const response = await request(app)
                .get(`/api/boosts/active/${user._id}`)
                .expect(200);

            expect(response.body.success).toBe(true);
            expect(response.body.boosts).toHaveLength(1);
            expect(response.body.boosts[0].rateIncrease).toBe(0.1);
        });
    });

    describe('POST /api/boosts/purchase', () => {
        it('should purchase a new boost', async () => {
            const user = await User.create({
                _id: 'test-user',
                currentMiningRate: 0.5,
                points: 100
            });

            const boost = await Boost.create({
                _id: 'test-boost',
                type: 'MINING_RATE',
                level: 1,
                rateIncrease: 0.1,
                cost: { points: 50 }
            });

            const response = await request(app)
                .post('/api/boosts/purchase')
                .send({
                    userId: user._id,
                    boostId: boost._id
                })
                .expect(200);

            expect(response.body.success).toBe(true);
            expect(response.body.userData.rateIncrease).toBe(0.1);

            // Verify user points were deducted
            const updatedUser = await User.findById(user._id);
            expect(updatedUser.points).toBe(50);
        });

        it('should not allow purchase with insufficient points', async () => {
            const user = await User.create({
                _id: 'test-user',
                currentMiningRate: 0.5,
                points: 20
            });

            const boost = await Boost.create({
                _id: 'test-boost',
                type: 'MINING_RATE',
                level: 1,
                rateIncrease: 0.1,
                cost: { points: 50 }
            });

            const response = await request(app)
                .post('/api/boosts/purchase')
                .send({
                    userId: user._id,
                    boostId: boost._id
                })
                .expect(400);

            expect(response.body.success).toBe(false);
            expect(response.body.error).toContain('insufficient');
        });
    });

    describe('Boost Expiration', () => {
        it('should correctly handle boost expiration', async () => {
            const user = await User.create({
                _id: 'test-user',
                currentMiningRate: 0.6
            });

            const boost = await Boost.create({
                userId: user._id,
                type: 'MINING_RATE',
                level: 5,
                rateIncrease: 0.1,
                startTime: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
                endTime: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
            });

            const response = await request(app)
                .post(`/api/boosts/update/${user._id}`)
                .expect(200);

            expect(response.body.success).toBe(true);
            expect(response.body.currentRate).toBe(0.5); // Back to base rate

            const updatedBoost = await Boost.findById(boost._id);
            expect(updatedBoost.active).toBe(false);
        });
    });
});
