const cron = require('node-cron');
const Task = require('../models/taskModel');
const User = require('../models/userModel');
const logger = require('../utils/logger');
const socialVerificationService = require('../services/socialVerificationService');

// Run every 12 hours
cron.schedule('0 */12 * * *', async () => {
    logger.info('Starting membership verification job');
    
    try {
        // Get all users with completed community tasks
        const users = await User.find({
            minerActive: true
        });

        logger.info(`Found ${users.length} active miners to verify`);

        for (const user of users) {
            try {
                const tasks = await Task.find({
                    userId: user._id,
                    type: 'COMMUNITY',
                    status: 'COMPLETED'
                });

                let allVerified = true;
                const violations = [];

                // Check each completed task
                for (const task of tasks) {
                    let isVerified = false;
                    switch (task.platform) {
                        case 'TELEGRAM':
                            isVerified = await socialVerificationService.verifyTelegramMembership(user._id);
                            break;
                        case 'TWITTER':
                            isVerified = await socialVerificationService.verifyTwitterFollow(user._id);
                            break;
                        case 'YOUTUBE':
                            isVerified = await socialVerificationService.verifyYoutubeSubscription(user._id);
                            break;
                        case 'INSTAGRAM':
                            isVerified = await socialVerificationService.verifyInstagramFollow(user._id);
                            break;
                    }

                    if (!isVerified) {
                        allVerified = false;
                        violations.push(task.platform);
                    }
                }

                if (!allVerified) {
                    // Apply penalty
                    const penalty = user.balance * 0.05; // 5% penalty
                    user.balance -= penalty;
                    user.minerActive = false;
                    await user.save();

                    logger.warn(`User ${user._id} violated community rules. Applied penalty: ${penalty}. Violations: ${violations.join(', ')}`);
                }

                // Update last verification time
                await Task.updateMany(
                    { userId: user._id, type: 'COMMUNITY' },
                    { $set: { lastVerified: new Date() } }
                );
            } catch (error) {
                logger.error(`Error processing user ${user._id}:`, error);
            }
        }

        logger.info('Membership verification job completed');
    } catch (error) {
        logger.error('Error in membership verification job:', error);
    }
});
