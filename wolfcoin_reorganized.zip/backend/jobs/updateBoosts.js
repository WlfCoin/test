const cron = require('node-cron');
const Boost = require('../models/boostModel');
const User = require('../models/userModel');
const logger = require('../utils/logger');
const cache = require('../utils/cache');
const notificationService = require('../services/notificationService');

// Warning thresholds in milliseconds
const WARNING_THRESHOLDS = [
    24 * 60 * 60 * 1000, // 24 hours
    6 * 60 * 60 * 1000,  // 6 hours
    1 * 60 * 60 * 1000   // 1 hour
];

// Run every hour
cron.schedule('0 * * * *', async () => {
    logger.info('Starting boost update job');
    
    try {
        // Find expired boosts
        const expiredBoosts = await Boost.find({
            active: true,
            endTime: { $lte: new Date() }
        });

        logger.info(`Found ${expiredBoosts.length} expired boosts`);

        // Process each expired boost
        for (const boost of expiredBoosts) {
            try {
                boost.active = false;
                await boost.save();

                // Send expiration notification
                await notificationService.sendBoostExpired(boost.userId, boost);

                // Update user's mining rate
                const user = await User.findById(boost.userId);
                if (user) {
                    const activeBoosts = await Boost.find({
                        userId: user._id,
                        active: true,
                        type: 'MINING_RATE'
                    });

                    const maxRateBoost = activeBoosts.reduce((max, boost) => 
                        boost.rateIncrease > max ? boost.rateIncrease : max, 0);

                    user.currentMiningRate = 0.5 + maxRateBoost;
                    await user.save();

                    // Clear user cache
                    await cache.del(`user:${user._id}`);
                    await cache.del(`boosts:${user._id}`);

                    logger.info(`Updated rate for user ${user._id} to ${user.currentMiningRate}`);
                }
            } catch (error) {
                logger.error(`Error processing boost ${boost._id}:`, error);
            }
        }

        // Check for boosts that will expire soon
        const now = new Date();
        for (const threshold of WARNING_THRESHOLDS) {
            const warningTime = new Date(now.getTime() + threshold);
            
            const expiringBoosts = await Boost.find({
                active: true,
                endTime: {
                    $gt: now,
                    $lte: warningTime
                },
                lastWarningAt: { 
                    $not: { 
                        $gt: new Date(now.getTime() - threshold) 
                    }
                }
            });

            for (const boost of expiringBoosts) {
                try {
                    const timeRemaining = boost.endTime - now;
                    await notificationService.sendBoostExpirationWarning(
                        boost.userId,
                        boost,
                        timeRemaining
                    );

                    // Update last warning time
                    boost.lastWarningAt = now;
                    await boost.save();

                    logger.info(`Sent expiration warning for boost ${boost._id}`);
                } catch (error) {
                    logger.error(`Error sending warning for boost ${boost._id}:`, error);
                }
            }
        }

        logger.info('Boost update job completed successfully');
    } catch (error) {
        logger.error('Error in boost update job:', error);
    }
});

// Run every minute to update temporary boost timers
cron.schedule('* * * * *', async () => {
    logger.debug('Starting temporary boost timer update');
    
    try {
        const activeTemporaryBoosts = await Boost.find({
            active: true,
            type: 'MINING_RATE',
            level: { $gte: 5 }
        });

        for (const boost of activeTemporaryBoosts) {
            if (boost.isExpired()) {
                boost.active = false;
                await boost.save();
                
                // Send expiration notification
                await notificationService.sendBoostExpired(boost.userId, boost);
                
                // Clear cache
                await cache.del(`user:${boost.userId}`);
                await cache.del(`boosts:${boost.userId}`);
                
                logger.info(`Deactivated expired temporary boost ${boost._id}`);
            }
        }
    } catch (error) {
        logger.error('Error updating temporary boost timers:', error);
    }
});
