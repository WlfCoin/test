const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');
const { protect } = require('../../middleware/authMiddleware');

// Initialize tasks for new user
router.post('/initialize/:userId', protect, taskController.initializeUserTasks);

// Get user tasks
router.get('/:userId', protect, taskController.getUserTasks);

// Handle task click/completion
router.post('/:userId/:taskId/complete', protect, taskController.handleTaskClick);

// Verify membership status
router.get('/:userId/verify-membership', protect, taskController.verifyMembership);

module.exports = router;
