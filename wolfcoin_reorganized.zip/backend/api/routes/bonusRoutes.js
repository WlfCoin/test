const express = require('express');
const router = express.Router();
const { getBonusStatus, collectBonus } = require('../controllers/bonusController');
const { verifyToken } = require('../../middleware/auth');

// هر دو route نیاز به احراز هویت دارند
router.get('/status', verifyToken, getBonusStatus);
router.post('/collect', verifyToken, collectBonus);

module.exports = router;
