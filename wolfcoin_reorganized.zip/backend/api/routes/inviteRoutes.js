const express = require('express');
const router = express.Router();
const { getInvitedFriends, getInviteLink } = require('../controllers/inviteController');
const { authMiddleware } = require('../../middlewares/authMiddleware');

// مسیرها
router.get('/friends', authMiddleware, getInvitedFriends);
router.get('/link', authMiddleware, getInviteLink);

module.exports = router;
