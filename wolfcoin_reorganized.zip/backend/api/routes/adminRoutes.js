const express = require('express');
const router = express.Router();
const Task = require('../../models/taskModel');
const Booster = require('../../models/boosterModel');
const Bonus = require('../../models/bonusModel');
const { protect, admin } = require('../../middleware/authMiddleware');
const logger = require('../../utils/logger');

// Get all tasks by type
router.get('/tasks/:type', protect, admin, async (req, res) => {
    try {
        const tasks = await Task.find({ type: req.params.type.toUpperCase() })
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            tasks
        });
    } catch (error) {
        logger.error('Error fetching tasks:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch tasks'
        });
    }
});

// Get all pending Instagram tasks
router.get('/tasks/instagram/pending', protect, admin, async (req, res) => {
    try {
        const tasks = await Task.find({
            platform: 'INSTAGRAM',
            status: 'WAITING_APPROVAL'
        }).sort({ updatedAt: -1 });

        res.json({
            success: true,
            tasks
        });
    } catch (error) {
        logger.error('Error fetching pending Instagram tasks:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch pending tasks'
        });
    }
});

// Create new task
router.post('/tasks', protect, admin, async (req, res) => {
    try {
        const task = new Task({
            ...req.body,
            active: true
        });
        await task.save();

        res.status(201).json({
            success: true,
            task
        });
    } catch (error) {
        logger.error('Error creating task:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create task'
        });
    }
});

// Update task
router.put('/tasks/:id', protect, admin, async (req, res) => {
    try {
        const task = await Task.findByIdAndUpdate(
            req.params.id,
            { ...req.body },
            { new: true }
        );

        if (!task) {
            return res.status(404).json({
                success: false,
                error: 'Task not found'
            });
        }

        res.json({
            success: true,
            task
        });
    } catch (error) {
        logger.error('Error updating task:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update task'
        });
    }
});

// Delete task
router.delete('/tasks/:id', protect, admin, async (req, res) => {
    try {
        const task = await Task.findByIdAndDelete(req.params.id);

        if (!task) {
            return res.status(404).json({
                success: false,
                error: 'Task not found'
            });
        }

        res.json({
            success: true,
            message: 'Task deleted successfully'
        });
    } catch (error) {
        logger.error('Error deleting task:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete task'
        });
    }
});

// Toggle task status
router.patch('/tasks/:id/status', protect, admin, async (req, res) => {
    try {
        const task = await Task.findByIdAndUpdate(
            req.params.id,
            { active: req.body.active },
            { new: true }
        );

        if (!task) {
            return res.status(404).json({
                success: false,
                error: 'Task not found'
            });
        }

        res.json({
            success: true,
            task
        });
    } catch (error) {
        logger.error('Error updating task status:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update task status'
        });
    }
});

// Get all boosters
router.get('/boosters', protect, admin, async (req, res) => {
    try {
        const boosters = await Booster.find().sort({ createdAt: -1 });
        res.json({
            success: true,
            boosters
        });
    } catch (error) {
        logger.error('Error fetching boosters:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch boosters'
        });
    }
});

// Create new booster
router.post('/boosters', protect, admin, async (req, res) => {
    try {
        const booster = new Booster({
            ...req.body,
            active: true,
            purchaseCount: 0
        });
        await booster.save();

        res.status(201).json({
            success: true,
            booster
        });
    } catch (error) {
        logger.error('Error creating booster:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create booster'
        });
    }
});

// Update booster
router.put('/boosters/:id', protect, admin, async (req, res) => {
    try {
        const booster = await Booster.findByIdAndUpdate(
            req.params.id,
            { ...req.body },
            { new: true }
        );

        if (!booster) {
            return res.status(404).json({
                success: false,
                error: 'Booster not found'
            });
        }

        res.json({
            success: true,
            booster
        });
    } catch (error) {
        logger.error('Error updating booster:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update booster'
        });
    }
});

// Delete booster
router.delete('/boosters/:id', protect, admin, async (req, res) => {
    try {
        const booster = await Booster.findByIdAndDelete(req.params.id);

        if (!booster) {
            return res.status(404).json({
                success: false,
                error: 'Booster not found'
            });
        }

        res.json({
            success: true,
            message: 'Booster deleted successfully'
        });
    } catch (error) {
        logger.error('Error deleting booster:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete booster'
        });
    }
});

// Toggle booster status
router.patch('/boosters/:id/status', protect, admin, async (req, res) => {
    try {
        const booster = await Booster.findByIdAndUpdate(
            req.params.id,
            { active: req.body.active },
            { new: true }
        );

        if (!booster) {
            return res.status(404).json({
                success: false,
                error: 'Booster not found'
            });
        }

        res.json({
            success: true,
            booster
        });
    } catch (error) {
        logger.error('Error updating booster status:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update booster status'
        });
    }
});

// Get all bonuses
router.get('/bonuses', protect, admin, async (req, res) => {
    try {
        const bonuses = await Bonus.find().sort({ createdAt: -1 });
        res.json({
            success: true,
            bonuses
        });
    } catch (error) {
        logger.error('Error fetching bonuses:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch bonuses'
        });
    }
});

// Create new bonus
router.post('/bonuses', protect, admin, async (req, res) => {
    try {
        const bonus = new Bonus({
            ...req.body,
            active: true,
            claimCount: 0
        });
        await bonus.save();

        res.status(201).json({
            success: true,
            bonus
        });
    } catch (error) {
        logger.error('Error creating bonus:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create bonus'
        });
    }
});

// Update bonus
router.put('/bonuses/:id', protect, admin, async (req, res) => {
    try {
        const bonus = await Bonus.findByIdAndUpdate(
            req.params.id,
            { ...req.body },
            { new: true }
        );

        if (!bonus) {
            return res.status(404).json({
                success: false,
                error: 'Bonus not found'
            });
        }

        res.json({
            success: true,
            bonus
        });
    } catch (error) {
        logger.error('Error updating bonus:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update bonus'
        });
    }
});

// Delete bonus
router.delete('/bonuses/:id', protect, admin, async (req, res) => {
    try {
        const bonus = await Bonus.findByIdAndDelete(req.params.id);

        if (!bonus) {
            return res.status(404).json({
                success: false,
                error: 'Bonus not found'
            });
        }

        res.json({
            success: true,
            message: 'Bonus deleted successfully'
        });
    } catch (error) {
        logger.error('Error deleting bonus:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete bonus'
        });
    }
});

// Toggle bonus status
router.patch('/bonuses/:id/status', protect, admin, async (req, res) => {
    try {
        const bonus = await Bonus.findByIdAndUpdate(
            req.params.id,
            { active: req.body.active },
            { new: true }
        );

        if (!bonus) {
            return res.status(404).json({
                success: false,
                error: 'Bonus not found'
            });
        }

        res.json({
            success: true,
            bonus
        });
    } catch (error) {
        logger.error('Error updating bonus status:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update bonus status'
        });
    }
});

module.exports = router;
