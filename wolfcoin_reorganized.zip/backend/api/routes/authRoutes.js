const express = require('express');
const router = express.Router();
const { protect } = require('../../middleware/authMiddleware');
const {
    setup2FA,
    verify2FA,
    validate2FA,
    disable2FA
} = require('../controllers/authController');
const { verifyLoginToken } = require('../controllers/botController');

// Admin Login from Telegram
router.post('/verify-login-token', verifyLoginToken);

// 2FA Routes
router.post('/2fa/setup', protect, setup2FA);
router.post('/2fa/verify', protect, verify2FA);
router.post('/2fa/validate', protect, validate2FA);
router.post('/2fa/disable', protect, disable2FA);

module.exports = router;
