const User = require('../../models/userModel');
const BonusStreak = require('../../models/bonusStreakModel');
const { createError } = require('../../utils/error');

const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;

const getBonusStatus = async (req, res, next) => {
    try {
        const userId = req.user.id;

        // دریافت اطلاعات streak کاربر
        let streak = await BonusStreak.findOne({ userId });
        
        if (!streak) {
            // اگر کاربر جدید است، streak جدید ایجاد می‌کنیم
            streak = await BonusStreak.create({
                userId,
                currentDay: 1,
                lastCollectedAt: null,
                isStreakBroken: false
            });
        }

        // چک کردن اینکه آیا streak شکسته شده
        if (streak.lastCollectedAt) {
            const timeSinceLastCollection = Date.now() - new Date(streak.lastCollectedAt).getTime();
            if (timeSinceLastCollection > MILLISECONDS_PER_DAY) {
                // اگر بیش از 24 ساعت گذشته، streak را ریست می‌کنیم
                streak.currentDay = 1;
                streak.isStreakBroken = true;
                await streak.save();
            }
        }

        // ساخت آرایه 7 روزه با وضعیت‌های مناسب
        const streakDays = Array.from({ length: 7 }, (_, index) => {
            const dayNumber = index + 1;
            let status;
            
            if (dayNumber < streak.currentDay) {
                status = 'collected';
            } else if (dayNumber === streak.currentDay && !streak.isStreakBroken) {
                status = 'active';
            } else {
                status = 'locked';
            }

            return {
                dayNumber,
                points: dayNumber, // هر روز به اندازه شماره روز امتیاز دارد
                status
            };
        });

        res.json({
            success: true,
            streakDays
        });

    } catch (err) {
        next(createError(500, 'Error fetching bonus status'));
    }
};

const collectBonus = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { day } = req.body;

        // دریافت اطلاعات streak کاربر
        const streak = await BonusStreak.findOne({ userId });
        
        if (!streak) {
            return next(createError(400, 'Bonus streak not initialized'));
        }

        // validation checks
        if (day !== streak.currentDay) {
            return next(createError(400, 'Invalid day for collection'));
        }

        if (streak.isStreakBroken) {
            return next(createError(400, 'Streak is broken. Start from day 1'));
        }

        if (streak.lastCollectedAt) {
            const timeSinceLastCollection = Date.now() - new Date(streak.lastCollectedAt).getTime();
            if (timeSinceLastCollection < MILLISECONDS_PER_DAY) {
                return next(createError(400, 'Already collected today\'s bonus'));
            }
        }

        // Transaction برای اطمینان از atomic بودن عملیات
        const session = await BonusStreak.startSession();
        session.startTransaction();

        try {
            // آپدیت streak
            streak.lastCollectedAt = new Date();
            streak.currentDay = Math.min(streak.currentDay + 1, 7);
            await streak.save({ session });

            // اضافه کردن امتیاز به کاربر
            const pointsToAdd = day; // امتیاز برابر با شماره روز
            await User.findByIdAndUpdate(
                userId,
                { $inc: { points: pointsToAdd } },
                { session }
            );

            await session.commitTransaction();
            session.endSession();

            res.json({
                success: true,
                message: `Collected ${pointsToAdd} points for day ${day}`,
                pointsAdded: pointsToAdd
            });

        } catch (err) {
            await session.abortTransaction();
            session.endSession();
            throw err;
        }

    } catch (err) {
        next(createError(500, 'Error collecting bonus'));
    }
};

module.exports = {
    getBonusStatus,
    collectBonus
};
