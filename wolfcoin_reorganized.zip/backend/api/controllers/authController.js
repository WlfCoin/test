const jwt = require('jsonwebtoken');
const speakeasy = require('speakeasy'); 
const qrcode = require('qrcode');
const User = require('../../models/userModel');
const { createError } = require('../../utils/error');

exports.setup2FA = async (req, res, next) => {
    try {
        const secret = speakeasy.generateSecret({ name: 'WolfCoin 2FA' });

        req.user.twoFactorSecret = secret.base32;
        await req.user.save();

        const qrCode = await qrcode.toDataURL(secret.otpauth_url);

        res.json({ success: true, qrCode });
    } catch (error) {
        next(createError(500, 'Error setting up 2FA'));
    }
};

exports.verify2FA = async (req, res, next) => {
    try {
        const { token } = req.body;

        const verified = speakeasy.totp.verify({
            secret: req.user.twoFactorSecret,
            encoding: 'base32',
            token
        });

        if (!verified) {
            return next(createError(400, 'Invalid 2FA token'));
        }

        res.json({ success: true });
    } catch (error) {
        next(createError(500, 'Error verifying 2FA'));
    }
};

exports.validate2FA = async (req, res, next) => {
    try {
        const { token } = req.body;

        const isValid = speakeasy.totp.verify({
            secret: req.user.twoFactorSecret,
            encoding: 'base32',
            token
        });

        if (!isValid) {
            return next(createError(400, 'Invalid 2FA token'));
        }

        const jwtToken = jwt.sign({ id: req.user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.json({ success: true, token: jwtToken });
    } catch (error) {
        next(createError(500, 'Error validating 2FA'));
    }
};

exports.disable2FA = async (req, res, next) => {
    try {
        req.user.twoFactorSecret = null;
        await req.user.save();

        res.json({ success: true });
    } catch (error) {
        next(createError(500, 'Error disabling 2FA'));
    }
};
