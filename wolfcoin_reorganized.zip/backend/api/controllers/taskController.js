const Task = require('../../models/taskModel');
const User = require('../../models/userModel');
const logger = require('../../utils/logger');
const cache = require('../../utils/cache');
const { verifyTelegramMembership, verifyTwitterFollow, verifyYoutubeSubscription } = require('../../services/socialVerificationService');

// Default community tasks
const COMMUNITY_TASKS = [
    {
        platform: 'TELEGRAM',
        link: 'https://t.me/wolfCoin_news',
        points: 2,
        title: 'Join Community',
        description: 'Join our Telegram community channel',
        note: 'Reward will be given after bot verification'
    },
    {
        platform: 'TELEGRAM',
        link: 'https://t.me/Activityofprojectusers',
        points: 2,
        title: 'Join Activity',
        description: 'Join our Telegram activity channel',
        note: 'Reward will be given after bot verification'
    },
    {
        platform: 'TWITTER',
        link: 'https://x.com/wlfcoinofficial?t=x6TDbhipSMYkU4bWw_dI_g&s=09',
        points: 2,
        title: 'Join X (Twitter)',
        description: 'Follow us on X (Twitter)',
        note: 'Twitter account access required'
    },
    {
        platform: 'YOUTUBE',
        link: 'https://youtube.com/@wolfcoinofficial?si=XnwRU0MH_DY9hFFc',
        points: 2,
        title: 'Join YouTube',
        description: 'Subscribe to our YouTube channel',
        note: 'YouTube account access required'
    },
    {
        platform: 'INSTAGRAM',
        link: 'https://www.instagram.com/wolfcoin.official/profilecard/?igsh=MWRpa2p1ZmU4OGVzMg==7',
        points: 2,
        title: 'Join Instagram',
        description: 'Follow us on Instagram',
        note: 'Instagram username verification required'
    }
];

// Initialize tasks for new user
exports.initializeUserTasks = async (userId) => {
    try {
        const existingTasks = await Task.find({ userId });
        if (existingTasks.length > 0) {
            return;
        }

        const tasks = COMMUNITY_TASKS.map(task => ({
            userId,
            type: 'COMMUNITY',
            ...task
        }));

        await Task.insertMany(tasks);
        logger.info(`Initialized tasks for user ${userId}`);
    } catch (error) {
        logger.error(`Error initializing tasks for user ${userId}:`, error);
        throw error;
    }
};

// Get user tasks
exports.getUserTasks = async (req, res) => {
    const { userId } = req.params;
    const { type = 'COMMUNITY' } = req.query;
    
    try {
        const cacheKey = `tasks:${userId}:${type}`;
        const cachedTasks = await cache.get(cacheKey);
        
        if (cachedTasks) {
            return res.status(200).json({
                success: true,
                tasks: cachedTasks,
                fromCache: true
            });
        }

        const tasks = await Task.find({ userId, type });
        
        // Cache for 5 minutes
        await cache.set(cacheKey, tasks, 300);

        res.status(200).json({
            success: true,
            tasks
        });
    } catch (error) {
        logger.error(`Error getting tasks for user ${userId}:`, error);
        res.status(500).json({ success: false, error: 'Server error.' });
    }
};

// Handle task click
exports.handleTaskClick = async (req, res) => {
    const { userId, taskId } = req.params;
    const { instagramUsername } = req.body;
    
    try {
        const task = await Task.findOne({ _id: taskId, userId });
        if (!task) {
            return res.status(404).json({ success: false, error: 'Task not found.' });
        }

        if (task.isCompleted()) {
            return res.status(400).json({ success: false, error: 'Task already completed.' });
        }

        if (task.isFirstClick()) {
            task.status = 'CLICKED_ONCE';
            await task.save();
            
            return res.status(200).json({
                success: true,
                message: 'You are not following it yet',
                status: 'CLICKED_ONCE'
            });
        }

        // Handle Instagram separately
        if (task.platform === 'INSTAGRAM') {
            if (!instagramUsername) {
                return res.status(400).json({
                    success: false,
                    error: 'Instagram username is required'
                });
            }

            task.instagramUsername = instagramUsername;
            task.status = 'WAITING_APPROVAL';
            await task.save();

            return res.status(200).json({
                success: true,
                message: 'Instagram verification pending admin approval',
                status: 'WAITING_APPROVAL'
            });
        }

        // Verify other social media follows
        let isVerified = false;
        switch (task.platform) {
            case 'TELEGRAM':
                isVerified = await verifyTelegramMembership(userId);
                break;
            case 'TWITTER':
                isVerified = await verifyTwitterFollow(userId);
                break;
            case 'YOUTUBE':
                isVerified = await verifyYoutubeSubscription(userId);
                break;
        }

        if (!isVerified) {
            return res.status(400).json({
                success: false,
                error: 'Verification failed. Please make sure you are following/subscribed.'
            });
        }

        // Complete task and award points
        await task.updateStatus('COMPLETED');
        
        const user = await User.findById(userId);
        user.points += task.points;
        await user.save();

        // Clear cache
        await cache.del(`tasks:${userId}:${task.type}`);
        await cache.del(`user:${userId}`);

        logger.info(`Task ${taskId} completed by user ${userId}`);
        res.status(200).json({
            success: true,
            message: 'Task completed successfully',
            pointsAwarded: task.points
        });
    } catch (error) {
        logger.error(`Error handling task click: ${error.message}`, { error });
        res.status(500).json({ success: false, error: 'Server error.' });
    }
};

// Admin: Review Instagram task
exports.reviewInstagramTask = async (req, res) => {
    const { taskId } = req.params;
    const { approved, note } = req.body;

    try {
        const task = await Task.findById(taskId);
        if (!task) {
            return res.status(404).json({ success: false, error: 'Task not found.' });
        }

        if (task.platform !== 'INSTAGRAM' || !task.isWaitingApproval()) {
            return res.status(400).json({
                success: false,
                error: 'Invalid task or task not waiting for approval'
            });
        }

        if (approved) {
            await task.updateStatus('COMPLETED', note);
            
            const user = await User.findById(task.userId);
            user.points += task.points;
            await user.save();

            logger.info(`Instagram task ${taskId} approved by admin`);
        } else {
            await task.updateStatus('REJECTED', note);
            logger.info(`Instagram task ${taskId} rejected by admin`);
        }

        // Clear cache
        await cache.del(`tasks:${task.userId}:${task.type}`);
        await cache.del(`user:${task.userId}`);

        res.status(200).json({
            success: true,
            message: approved ? 'Task approved and points awarded' : 'Task rejected',
            status: task.status
        });
    } catch (error) {
        logger.error(`Error reviewing Instagram task: ${error.message}`, { error });
        res.status(500).json({ success: false, error: 'Server error.' });
    }
};

// Verify community membership
exports.verifyMembership = async (req, res) => {
    const { userId } = req.params;
    
    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found.' });
        }

        // Check both community and activity channels
        const [communityMember, activityMember] = await Promise.all([
            verifyTelegramMembership(user.telegramId, 'wolfCoin_news'),
            verifyTelegramMembership(user.telegramId, 'Activityofprojectusers')
        ]);

        const isMember = communityMember && activityMember;

        if (!isMember) {
            // Stop miner
            await User.findByIdAndUpdate(userId, { 
                $set: { 
                    minerActive: false,
                    lastPenaltyDate: new Date()
                },
                $inc: { 
                    balance: -(user.balance * 0.05) // 5% penalty
                }
            });

            logger.warn(`User ${userId} penalized for leaving channels`);
            
            return res.status(200).json({ 
                success: true, 
                isMember: false,
                message: 'User left required channels. Penalty applied.'
            });
        }

        res.status(200).json({ 
            success: true, 
            isMember: true
        });
    } catch (error) {
        logger.error(`Error verifying membership for user ${userId}:`, error);
        res.status(500).json({ success: false, error: 'Failed to verify membership.' });
    }
};
