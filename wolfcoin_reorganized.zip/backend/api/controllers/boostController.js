const Boost = require('../../models/boostModel');
const Transaction = require('../../models/transactionModel');
const User = require('../../models/userModel');
const { validateTransaction, verifyTonTransaction } = require('../../services/paymentService');
const logger = require('../../utils/logger');
const cache = require('../../utils/cache');
const { createError } = require('../../utils/error');
const { runQuery } = require('../../config/db');

const CACHE_TTL = 60 * 5; // 5 minutes cache

// خرید بوستر
exports.purchaseBoost = async (req, res) => {
    const { userId, type, level, transactionHash } = req.body;

    try {
        logger.info(`Attempting to purchase boost: type=${type}, level=${level} for user: ${userId}`);

        // بررسی امکان خرید این سطح
        const canPurchase = await Boost.canPurchaseLevel(userId, type, level);
        if (!canPurchase) {
            logger.warn(`User ${userId} attempted to purchase level ${level} without previous level`);
            return res.status(400).json({ 
                success: false, 
                error: 'You must activate the previous level first.' 
            });
        }

        // دریافت اطلاعات بوست
        const boosts = type === 'MINING_RATE' ? 
            Boost.getMiningRateBoosts() : 
            Boost.getOfflineDurationBoosts();
        
        const boostInfo = boosts[level - 1];
        if (!boostInfo) {
            return res.status(400).json({ 
                success: false, 
                error: 'Invalid boost level.' 
            });
        }

        // بررسی موجودی و نوع پرداخت
        const user = await User.findByUserId(userId);
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                error: 'User not found.' 
            });
        }

        if (boostInfo.cost.points) {
            if (user.points < boostInfo.cost.points) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Insufficient points.' 
                });
            }
            user.points -= boostInfo.cost.points;
        } else if (boostInfo.cost.ton) {
            // اعتبارسنجی تراکنش تون‌کوین
            if (!transactionHash) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Transaction hash is required for TON payments.' 
                });
            }

            const isValid = await verifyTonTransaction(transactionHash, boostInfo.cost.ton);
            if (!isValid) {
                logger.warn(`Invalid TON transaction: ${transactionHash}`);
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid TON transaction.' 
                });
            }
        }

        // ایجاد بوست جدید
        const boost = new Boost({
            userId,
            type,
            level,
            rateIncrease: boostInfo.rate || 1,
            cost: boostInfo.cost,
            offlineDuration: boostInfo.duration || user.offlineDuration,
            tonTransactionHash: transactionHash
        });

        // ایجاد تراکنش
        const transaction = new Transaction({
            userId,
            type: 'boost_purchase',
            amount: boostInfo.cost.points || boostInfo.cost.ton,
            currency: boostInfo.cost.points ? 'points' : 'ton',
            status: 'completed',
            metadata: {
                boostType: type,
                level,
                transactionHash
            }
        });

        // ذخیره همه تغییرات در یک تراکنش
        try {
            await runQuery('BEGIN TRANSACTION');

            await boost.save();
            await transaction.save();
            await user.save();

            await runQuery('COMMIT');
        } catch (error) {
            await runQuery('ROLLBACK');
            throw createError('Transaction failed', 500);
        }

        // پاک کردن کش
        await cache.del(`user:${userId}`);
        await cache.del(`boosts:${userId}`);

        logger.info(`Boost purchase completed for user: ${userId}`);
        res.status(200).json({
            success: true,
            boost,
            transaction
        });
    } catch (error) {
        logger.error(`Error purchasing boost: ${error.message}`, { error });
        res.status(error.status || 500).json({ 
            success: false, 
            error: error.message || 'Server error.' 
        });
    }
};

// دریافت آمار بوست‌ها
exports.getBoostStats = async (req, res) => {
    const { userId } = req.params;
    const { startDate, endDate } = req.query;
    
    try {
        const cacheKey = `boost-stats:${userId}:${startDate}:${endDate}`;
        const cachedStats = await cache.get(cacheKey);
        
        if (cachedStats) {
            return res.status(200).json({
                success: true,
                stats: cachedStats,
                fromCache: true
            });
        }

        let query = 'SELECT * FROM boost WHERE userId = ?';
        const params = [userId];

        if (startDate && endDate) {
            query += ' AND startTime >= ? AND startTime <= ?';
            params.push(startDate, endDate);
        }

        const boosts = await runQuery(query, params);
        
        const stats = {
            totalBoosts: boosts.length,
            activeBoosts: boosts.filter(b => b.active).length,
            expiredBoosts: boosts.filter(b => !b.active).length,
            byType: {
                MINING_RATE: boosts.filter(b => b.type === 'MINING_RATE').length,
                OFFLINE_DURATION: boosts.filter(b => b.type === 'OFFLINE_DURATION').length
            },
            totalSpent: {
                points: boosts.reduce((sum, b) => sum + (JSON.parse(b.cost).points || 0), 0),
                ton: boosts.reduce((sum, b) => sum + (JSON.parse(b.cost).ton || 0), 0)
            },
            averageBoostDuration: boosts.reduce((sum, b) => {
                return sum + (new Date(b.endTime) - new Date(b.startTime));
            }, 0) / (boosts.length || 1),
            mostUsedLevel: Object.entries(
                boosts.reduce((acc, b) => {
                    acc[b.level] = (acc[b.level] || 0) + 1;
                    return acc;
                }, {})
            ).sort((a, b) => b[1] - a[1])[0]?.[0],
            currentLevels: {
                MINING_RATE: Math.max(...boosts
                    .filter(b => b.type === 'MINING_RATE' && b.active)
                    .map(b => b.level), 0),
                OFFLINE_DURATION: Math.max(...boosts
                    .filter(b => b.type === 'OFFLINE_DURATION' && b.active)
                    .map(b => b.level), 0)
            }
        };

        await cache.set(cacheKey, stats, CACHE_TTL);

        logger.info(`Generated boost stats for user: ${userId}`);
        res.status(200).json({
            success: true,
            stats
        });
    } catch (error) {
        logger.error(`Error generating boost stats: ${error.message}`, { error });
        res.status(500).json({ 
            success: false, 
            error: 'Error generating boost stats.' 
        });
    }
};

// دریافت تاریخچه بوست‌ها
exports.getBoostHistory = async (req, res) => {
    const { userId } = req.params;
    const { page = 1, limit = 10 } = req.query;
    
    try {
        const offset = (page - 1) * limit;
        
        const countQuery = 'SELECT COUNT(*) as total FROM boost WHERE userId = ?';
        const totalCount = await runQuery(countQuery, [userId]);
        
        const historyQuery = `
            SELECT * FROM boost 
            WHERE userId = ? 
            ORDER BY createdAt DESC 
            LIMIT ? OFFSET ?
        `;
        const boosts = await runQuery(historyQuery, [userId, limit, offset]);
        
        const totalPages = Math.ceil(totalCount[0].total / limit);
        
        res.status(200).json({
            success: true,
            history: boosts,
            pagination: {
                currentPage: page,
                totalPages,
                totalItems: totalCount[0].total,
                hasNextPage: page < totalPages,
                hasPrevPage: page > 1
            }
        });
    } catch (error) {
        logger.error(`Error fetching boost history: ${error.message}`, { error });
        res.status(500).json({ 
            success: false, 
            error: 'Error fetching boost history.' 
        });
    }
};
