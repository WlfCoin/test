const jwt = require('jsonwebtoken');
const User = require('../../models/userModel');

// @desc    Verify login token from Telegram bot
// @route   POST /api/auth/verify-login-token
// @access  Public
const verifyLoginToken = async (req, res) => {
    try {
        const { token } = req.body;

        if (!token) {
            return res.status(400).json({ 
                success: false, 
                message: 'No token provided' 
            });
        }

        // Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Get user
        const user = await User.findById(decoded.id);

        if (!user) {
            return res.status(404).json({ 
                success: false, 
                message: 'User not found' 
            });
        }

        // Create session token
        const sessionToken = jwt.sign(
            { id: user._id },
            process.env.JWT_SECRET,
            { expiresIn: '30d' }
        );

        res.status(200).json({
            success: true,
            token: sessionToken,
            user: {
                id: user._id,
                username: user.username,
                email: user.email,
                isAdmin: user.isAdmin,
                telegramId: user.telegramId
            }
        });

    } catch (error) {
        console.error('Error in verifyLoginToken:', error);
        res.status(401).json({ 
            success: false, 
            message: 'Invalid or expired token' 
        });
    }
};

module.exports = {
    verifyLoginToken
};
