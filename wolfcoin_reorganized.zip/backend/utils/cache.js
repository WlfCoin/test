const Redis = require('ioredis');
const logger = require('./logger');

class CacheService {
    constructor() {
        this.redis = new Redis({
            host: process.env.REDIS_HOST || '66.29.133.146',
            port: process.env.REDIS_PORT || 6379,
            password: process.env.REDIS_PASSWORD,
            retryStrategy: (times) => {
                const delay = Math.min(times * 50, 2000);
                return delay;
            },
            maxRetriesPerRequest: 3
        });

        this.redis.on('error', (err) => {
            logger.error('Redis error:', err);
        });

        this.redis.on('connect', () => {
            logger.info('Connected to Redis');
        });

        // Default TTL values (in seconds)
        this.TTL = {
            SHORT: 60,          // 1 minute
            MEDIUM: 300,        // 5 minutes
            LONG: 3600,         // 1 hour
            VERY_LONG: 86400    // 24 hours
        };

        // Prefix for different types of data
        this.PREFIX = {
            USER: 'user:',
            BOOST: 'boost:',
            STATS: 'stats:',
            HISTORY: 'history:'
        };
    }

    _getKey(type, id, ...args) {
        return [this.PREFIX[type], id, ...args].join(':');
    }

    async get(key) {
        try {
            const value = await this.redis.get(key);
            return value ? JSON.parse(value) : null;
        } catch (error) {
            logger.error(`Cache get error for key ${key}:`, error);
            return null;
        }
    }

    async set(key, value, ttl = this.TTL.MEDIUM) {
        try {
            const stringValue = JSON.stringify(value);
            await this.redis.setex(key, ttl, stringValue);
            return true;
        } catch (error) {
            logger.error(`Cache set error for key ${key}:`, error);
            return false;
        }
    }

    async del(key) {
        try {
            await this.redis.del(key);
            return true;
        } catch (error) {
            logger.error(`Cache delete error for key ${key}:`, error);
            return false;
        }
    }

    async mget(keys) {
        try {
            const values = await this.redis.mget(keys);
            return values.map(v => v ? JSON.parse(v) : null);
        } catch (error) {
            logger.error(`Cache mget error:`, error);
            return keys.map(() => null);
        }
    }

    async mset(keyValues, ttl = this.TTL.MEDIUM) {
        try {
            const pipeline = this.redis.pipeline();
            
            for (const [key, value] of Object.entries(keyValues)) {
                pipeline.setex(key, ttl, JSON.stringify(value));
            }
            
            await pipeline.exec();
            return true;
        } catch (error) {
            logger.error(`Cache mset error:`, error);
            return false;
        }
    }

    async flush() {
        try {
            await this.redis.flushall();
            return true;
        } catch (error) {
            logger.error('Cache flush error:', error);
            return false;
        }
    }

    // Specialized methods for boost-related caching
    async getBoostStats(userId, startDate, endDate) {
        return this.get(
            this._getKey('STATS', userId, startDate || 'all', endDate || 'all')
        );
    }

    async setBoostStats(userId, stats, startDate, endDate) {
        return this.set(
            this._getKey('STATS', userId, startDate || 'all', endDate || 'all'),
            stats,
            this.TTL.MEDIUM
        );
    }

    async getBoostHistory(userId, page, limit, type) {
        return this.get(
            this._getKey('HISTORY', userId, page, limit, type || 'all')
        );
    }

    async setBoostHistory(userId, history, page, limit, type) {
        return this.set(
            this._getKey('HISTORY', userId, page, limit, type || 'all'),
            history,
            this.TTL.SHORT
        );
    }

    async invalidateUserCache(userId) {
        const pipeline = this.redis.pipeline();
        
        // Get all keys for this user
        const userKeys = await this.redis.keys(`*:${userId}:*`);
        
        // Delete all found keys
        if (userKeys.length > 0) {
            pipeline.del(...userKeys);
        }
        
        await pipeline.exec();
    }

    // Cache warming methods
    async warmBoostCache(userId) {
        try {
            const [stats, history] = await Promise.all([
                // Get fresh stats
                Boost.aggregate([
                    { $match: { userId } },
                    {
                        $group: {
                            _id: null,
                            totalBoosts: { $sum: 1 },
                            activeBoosts: {
                                $sum: { $cond: ['$active', 1, 0] }
                            },
                            totalPointsSpent: {
                                $sum: '$cost.points'
                            },
                            totalTonSpent: {
                                $sum: '$cost.ton'
                            }
                        }
                    }
                ]),
                // Get fresh history
                Boost.find({ userId })
                    .sort({ startTime: -1 })
                    .limit(10)
                    .lean()
            ]);

            // Cache the results
            await Promise.all([
                this.setBoostStats(userId, stats[0]),
                this.setBoostHistory(userId, { boosts: history }, 1, 10)
            ]);

            return true;
        } catch (error) {
            logger.error(`Error warming cache for user ${userId}:`, error);
            return false;
        }
    }
}

module.exports = new CacheService();
