module.exports = {
    // Total available points (120 billion)
    TOTAL_POINTS_SUPPLY: 120_000_000_000,
    
    // Initial bonus for new users
    NEW_USER_BONUS: 10,
    
    // Telegram channel ID for activity reports
    ACTIVITY_CHANNEL_ID: process.env.TELEGRAM_ACTIVITY_CHANNEL_ID,
    
    // UTC times for daily tasks
    DAILY_RESET_TIME: '23:59:59',
    DAILY_REPORT_TIME: '12:00:00',
    
    // Redis keys
    REDIS_KEYS: {
        TOTAL_MINTED_POINTS: 'total_minted_points',
        DAILY_MINTED_POINTS: 'daily_minted_points',
        DAILY_NEW_USERS: 'daily_new_users'
    }
};
