// backend/config/db.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
require('dotenv').config();

const dbPath = path.resolve(__dirname, '../database/wolfcoin.db');
let db;

const connectDB = async () => {
    try {
        db = new sqlite3.Database(dbPath, (err) => {
            if (err) {
                console.error('Error connecting to SQLite database:', err);
                process.exit(1);
            }
            console.log('Connected to SQLite database successfully');
            initializeTables();
        });
    } catch (error) {
        console.error("Database connection failed:", error.message);
        process.exit(1);
    }
};

function initializeTables() {
    db.serialize(() => {
        // Create invites table
        db.run(`CREATE TABLE IF NOT EXISTS invites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inviter TEXT NOT NULL,
            invitee TEXT NOT NULL UNIQUE,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(inviter, invitee)
        )`);

        // Create bonus table
        db.run(`CREATE TABLE IF NOT EXISTS bonus (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId TEXT NOT NULL,
            streakDays INTEGER DEFAULT 0,
            lastClaimed DATETIME,
            nextBonus REAL DEFAULT 1.0,
            resetDate DATETIME,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Create bonus_history table
        db.run(`CREATE TABLE IF NOT EXISTS bonus_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bonusId INTEGER,
            type TEXT CHECK(type IN ('DAILY', 'STREAK')),
            amount REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (bonusId) REFERENCES bonus(id)
        )`);

        // Create booster table
        db.run(`CREATE TABLE IF NOT EXISTS booster (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId TEXT NOT NULL,
            multiplier REAL DEFAULT 1.0,
            duration INTEGER NOT NULL,
            startTime DATETIME,
            endTime DATETIME,
            active BOOLEAN DEFAULT 0,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Create bonus_streak table
        db.run(`CREATE TABLE IF NOT EXISTS bonus_streak (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId TEXT NOT NULL,
            currentStreak INTEGER DEFAULT 0,
            lastClaimDate DATETIME,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Create bot_user table
        db.run(`CREATE TABLE IF NOT EXISTS bot_user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discordId TEXT NOT NULL UNIQUE,
            username TEXT,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);
    });
}

// Helper functions for database operations
function runQuery(query, params = []) {
    return new Promise((resolve, reject) => {
        db.run(query, params, function(err) {
            if (err) reject(err);
            else resolve(this);
        });
    });
}

function getAll(query, params = []) {
    return new Promise((resolve, reject) => {
        db.all(query, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

function get(query, params = []) {
    return new Promise((resolve, reject) => {
        db.get(query, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

module.exports = {
    connectDB,
    db,
    runQuery,
    getAll,
    get
};
