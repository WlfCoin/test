module.exports = {
    telegramAppId: "APP_ID_WolfCoin",
    telegramAppHash: "APP_HASH_WolfCoin",
    proxyList: [],
    botToken: "7680841779:AAEtnUxqSxhmL3X3c_d2OiRL0lOBnOFZrE0", // توکن ربات شما
    adminId: "5375624171", // آیدی عددی ادمین
    walletAddress: "UQDdllvTeXTYE_2mq9R9hsEn_M1W4gACpoaumZtbLoIyrrYh" // آدرس کیف پول
};
