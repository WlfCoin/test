const express = require('express');
const cors = require('cors');
const logger = require('./utils/logger');
const { initializeTables } = require('./config/db');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Security Headers
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    next();
});

// Routes
app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/tasks', require('./routes/taskRoutes'));
app.use('/api/bonus', require('./routes/bonusRoutes'));
app.use('/api/boosts', require('./routes/boostRoutes'));
app.use('/api/invites', require('./routes/inviteRoutes'));
app.use('/api/auth', require('./api/routes/authRoutes'));
app.use('/api/admin', require('./api/routes/adminRoutes'));

// Error handling middleware
app.use((err, req, res, next) => {
    logger.error(err.stack);
    res.status(500).send('Something broke!');
});

// Initialize database tables
initializeTables()
    .then(() => {
        logger.info('Database tables initialized successfully');
        const PORT = process.env.PORT || 3000;
        app.listen(PORT, () => {
            logger.info(`Server running on port ${PORT}`);
        });
    })
    .catch(error => {
        logger.error('Error initializing database tables:', error);
        process.exit(1);
    });

module.exports = app;
