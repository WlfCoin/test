const { runQuery } = require('../config/db');
const logger = require('../utils/logger');

class Boost {
    constructor(data) {
        this.userId = data.userId;
        this.type = data.type;
        this.level = data.level;
        this.rateIncrease = data.rateIncrease;
        this.cost = data.cost;
        this.tonTransactionHash = data.tonTransactionHash;
        this.offlineDuration = data.offlineDuration;
        this.startTime = data.startTime || new Date();
        this.endTime = data.endTime;
        this.active = data.active !== false;
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }

    // Save boost to database
    async save() {
        try {
            // Validate required fields
            if (!this.userId || !this.type || !this.level || !this.rateIncrease || !this.offlineDuration) {
                throw new Error('Missing required fields');
            }

            // Validate type
            if (!['MINING_RATE', 'OFFLINE_DURATION'].includes(this.type)) {
                throw new Error('Invalid boost type');
            }

            // Validate level
            if (this.level < 1 || this.level > 7) {
                throw new Error('Invalid boost level');
            }

            // Set endTime if not set
            if (!this.endTime) {
                if (this.type === 'MINING_RATE' && this.level >= 5) {
                    const boosts = Boost.getMiningRateBoosts();
                    const boost = boosts[this.level - 1];
                    this.endTime = new Date(this.startTime.getTime() + boost.duration);
                } else {
                    // Default duration for point-based boosts
                    this.endTime = new Date(this.startTime.getTime() + (7 * 24 * 60 * 60 * 1000)); // 7 days
                }
            }

            // Validate endTime
            if (this.endTime <= this.startTime) {
                throw new Error('End time must be after start time');
            }

            const query = `
                INSERT INTO boost (
                    userId, type, level, rateIncrease, cost, tonTransactionHash,
                    offlineDuration, startTime, endTime, active, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            const result = await runQuery(query, [
                this.userId,
                this.type,
                this.level,
                this.rateIncrease,
                JSON.stringify(this.cost),
                this.tonTransactionHash,
                this.offlineDuration,
                this.startTime.toISOString(),
                this.endTime.toISOString(),
                this.active ? 1 : 0,
                this.createdAt.toISOString(),
                this.updatedAt.toISOString()
            ]);

            this.id = result.lastID;
            return this;
        } catch (error) {
            logger.error('Error saving boost:', error);
            throw error;
        }
    }

    // Check if boost is expired
    isExpired() {
        return Date.now() >= this.endTime;
    }

    // Calculate remaining time
    getRemainingTime() {
        if (this.isExpired()) return 0;
        return this.endTime - Date.now();
    }

    // Static method to find boost by ID
    static async findById(id) {
        try {
            const result = await runQuery('SELECT * FROM boost WHERE id = ?', [id]);
            if (!result || !result.length) return null;
            
            const boostData = result[0];
            boostData.cost = JSON.parse(boostData.cost);
            boostData.active = !!boostData.active;
            return new Boost(boostData);
        } catch (error) {
            logger.error('Error finding boost by ID:', error);
            throw error;
        }
    }

    // Static method to find boosts by user ID
    static async findByUserId(userId) {
        try {
            const result = await runQuery('SELECT * FROM boost WHERE userId = ?', [userId]);
            return result.map(boostData => {
                boostData.cost = JSON.parse(boostData.cost);
                boostData.active = !!boostData.active;
                return new Boost(boostData);
            });
        } catch (error) {
            logger.error('Error finding boosts by user ID:', error);
            throw error;
        }
    }

    // Static method to check if user can purchase this level
    static async canPurchaseLevel(userId, type, level) {
        if (level === 1) return true;

        try {
            const query = `
                SELECT * FROM boost 
                WHERE userId = ? AND type = ? AND level = ? AND active = 1
            `;
            const result = await runQuery(query, [userId, type, level - 1]);
            return result.length > 0;
        } catch (error) {
            logger.error('Error checking purchase eligibility:', error);
            throw error;
        }
    }

    // Static method to get mining rate boosts
    static getMiningRateBoosts() {
        return [
            { level: 1, cost: { points: 4 }, rate: 0.6 },
            { level: 2, cost: { points: 8 }, rate: 0.7 },
            { level: 3, cost: { points: 16 }, rate: 0.8 },
            { level: 4, cost: { points: 32 }, rate: 0.9 },
            { level: 5, cost: { ton: 0.1 }, rate: 1.0, duration: 24 * 60 * 60 * 1000 },
            { level: 6, cost: { ton: 0.7 }, rate: 1.0, duration: 7 * 24 * 60 * 60 * 1000 },
            { level: 7, cost: { ton: 2.0 }, rate: 1.0, duration: 30 * 24 * 60 * 60 * 1000 }
        ];
    }

    // Static method to get offline duration boosts
    static getOfflineDurationBoosts() {
        return [
            { level: 1, cost: { points: 8 }, duration: 6 * 60 * 60 * 1000 },
            { level: 2, cost: { points: 16 }, duration: 8 * 60 * 60 * 1000 },
            { level: 3, cost: { points: 32 }, duration: 10 * 60 * 60 * 1000 },
            { level: 4, cost: { points: 64 }, duration: 12 * 60 * 60 * 1000 },
            { level: 5, cost: { ton: 0.25 }, duration: 18 * 60 * 60 * 1000 },
            { level: 6, cost: { ton: 0.5 }, duration: 24 * 60 * 60 * 1000 }
        ];
    }
}

module.exports = Boost;
