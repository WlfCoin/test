const { db, runQuery, getAll, get } = require('../config/db');

class Transaction {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.type = data.type;
        this.amount = data.amount;
        this.description = data.description;
        this.status = data.status || 'PENDING';
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByUserId(userId) {
        const rows = await getAll('SELECT * FROM transaction WHERE userId = ?', [userId]);
        return rows.map(row => new Transaction(row));
    }

    static async findByType(type) {
        const rows = await getAll('SELECT * FROM transaction WHERE type = ?', [type]);
        return rows.map(row => new Transaction(row));
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE transaction 
                SET userId = ?, 
                    type = ?,
                    amount = ?,
                    description = ?,
                    status = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.userId, this.type, this.amount,
                 this.description, this.status, now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO transaction (
                    userId, type, amount, description,
                    status, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [this.userId, this.type, this.amount,
                 this.description, this.status, now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    async complete() {
        this.status = 'COMPLETED';
        return await this.save();
    }

    async fail() {
        this.status = 'FAILED';
        return await this.save();
    }
}

module.exports = Transaction;
