const { db, runQuery, get } = require('../config/db');

class BotUser {
    constructor(data) {
        this.id = data.id;
        this.discordId = data.discordId;
        this.username = data.username;
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByDiscordId(discordId) {
        const row = await get('SELECT * FROM bot_user WHERE discordId = ?', [discordId]);
        return row ? new BotUser(row) : null;
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE bot_user 
                SET discordId = ?, 
                    username = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.discordId, this.username, now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO bot_user (
                    discordId, username, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?)`,
                [this.discordId, this.username, now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }
}

module.exports = BotUser;
