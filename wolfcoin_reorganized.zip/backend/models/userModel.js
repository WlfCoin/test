const { db, runQuery, getAll, get } = require('../config/db');

class User {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.username = data.username;
        this.email = data.email;
        this.password = data.password;
        this.telegramId = data.telegramId;
        this.isAdmin = data.isAdmin;
        this.twoFactorSecret = data.twoFactorSecret;
        this.twoFactorEnabled = data.twoFactorEnabled;
        this.points = data.points || 10;
        this.toncoin = data.toncoin || 0;
        this.createdAt = data.createdAt;
    }

    static async findByUserId(userId) {
        const row = await get('SELECT * FROM user WHERE userId = ?', [userId]);
        return row ? new User(row) : null;
    }

    static async findByUsername(username) {
        const row = await get('SELECT * FROM user WHERE username = ?', [username]);
        return row ? new User(row) : null;
    }

    static async findByEmail(email) {
        const row = await get('SELECT * FROM user WHERE email = ?', [email]);
        return row ? new User(row) : null;
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE user 
                SET userId = ?, 
                    username = ?,
                    email = ?,
                    password = ?,
                    telegramId = ?,
                    isAdmin = ?,
                    twoFactorSecret = ?,
                    twoFactorEnabled = ?,
                    points = ?,
                    toncoin = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.userId, this.username, this.email,
                 this.password, this.telegramId, this.isAdmin,
                 this.twoFactorSecret, this.twoFactorEnabled,
                 this.points, this.toncoin,
                 now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO user (
                    userId, username, email,
                    password, telegramId, isAdmin,
                    twoFactorSecret, twoFactorEnabled,
                    points, toncoin,
                    createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [this.userId, this.username, this.email,
                 this.password, this.telegramId, this.isAdmin,
                 this.twoFactorSecret, this.twoFactorEnabled,
                 this.points, this.toncoin,
                 now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    async addPoints(points) {
        this.points += points;
        return await this.save();
    }

    async addToncoin(toncoin) {
        this.toncoin += toncoin;
        return await this.save();
    }
}

module.exports = User;
