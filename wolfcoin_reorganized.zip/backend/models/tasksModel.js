const { runQuery } = require('../config/db');
const logger = require('../utils/logger');

class Tasks {
    constructor(data) {
        this.id = data.id;
        this.taskId = data.taskId;
        this.name = data.name;
        this.reward = data.reward;
        this.completedUsers = data.completedUsers ? JSON.parse(data.completedUsers) : [];
        this.createdAt = data.createdAt ? new Date(data.createdAt) : new Date();
        this.updatedAt = data.updatedAt ? new Date(data.updatedAt) : new Date();
    }

    // Save task to database
    async save() {
        try {
            // Validate required fields
            if (!this.taskId || !this.name || !this.reward) {
                throw new Error('Missing required fields');
            }

            const now = new Date().toISOString();
            this.updatedAt = now;

            if (this.id) {
                // Update
                await runQuery(
                    `UPDATE tasks SET
                        taskId = ?, name = ?, reward = ?,
                        completedUsers = ?, updatedAt = ?
                    WHERE id = ?`,
                    [
                        this.taskId, this.name, this.reward,
                        JSON.stringify(this.completedUsers), now,
                        this.id
                    ]
                );
            } else {
                // Insert
                const result = await runQuery(
                    `INSERT INTO tasks (
                        taskId, name, reward, completedUsers,
                        createdAt, updatedAt
                    ) VALUES (?, ?, ?, ?, ?, ?)`,
                    [
                        this.taskId, this.name, this.reward,
                        JSON.stringify(this.completedUsers),
                        now, now
                    ]
                );
                this.id = result.lastID;
            }

            return this;
        } catch (error) {
            logger.error('Error saving task:', error);
            throw error;
        }
    }

    // Add completed user
    async addCompletedUser(userId) {
        if (!this.completedUsers.includes(userId)) {
            this.completedUsers.push(userId);
            await this.save();
            return true;
        }
        return false;
    }

    // Remove completed user
    async removeCompletedUser(userId) {
        const index = this.completedUsers.indexOf(userId);
        if (index > -1) {
            this.completedUsers.splice(index, 1);
            await this.save();
            return true;
        }
        return false;
    }

    // Check if user has completed task
    hasCompleted(userId) {
        return this.completedUsers.includes(userId);
    }

    // Static method to find task by ID
    static async findById(id) {
        try {
            const result = await runQuery('SELECT * FROM tasks WHERE id = ?', [id]);
            return result.length ? new Tasks(result[0]) : null;
        } catch (error) {
            logger.error('Error finding task by ID:', error);
            throw error;
        }
    }

    // Static method to find task by taskId
    static async findByTaskId(taskId) {
        try {
            const result = await runQuery('SELECT * FROM tasks WHERE taskId = ?', [taskId]);
            return result.length ? new Tasks(result[0]) : null;
        } catch (error) {
            logger.error('Error finding task by taskId:', error);
            throw error;
        }
    }

    // Static method to find all tasks
    static async findAll() {
        try {
            const result = await runQuery('SELECT * FROM tasks');
            return result.map(row => new Tasks(row));
        } catch (error) {
            logger.error('Error finding all tasks:', error);
            throw error;
        }
    }

    // Static method to find tasks by user completion
    static async findByUserCompletion(userId, completed = true) {
        try {
            const result = await runQuery('SELECT * FROM tasks');
            return result
                .map(row => new Tasks(row))
                .filter(task => task.hasCompleted(userId) === completed);
        } catch (error) {
            logger.error('Error finding tasks by user completion:', error);
            throw error;
        }
    }
}

module.exports = Tasks;
