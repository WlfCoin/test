const { runQuery } = require('../config/db');

class InviteModel {
    constructor(data) {
        this.id = data.id;
        this.inviter = data.inviter;
        this.invitee = data.invitee;
        this.createdAt = data.createdAt ? new Date(data.createdAt) : new Date();
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            await runQuery(
                `UPDATE invites 
                SET inviter = ?, invitee = ?
                WHERE id = ?`,
                [this.inviter, this.invitee, this.id]
            );
        } else {
            const result = await runQuery(
                `INSERT INTO invites (inviter, invitee, createdAt) 
                VALUES (?, ?, ?)`,
                [this.inviter, this.invitee, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    static async findById(id) {
        const result = await runQuery('SELECT * FROM invites WHERE id = ?', [id]);
        return result.length ? new InviteModel(result[0]) : null;
    }

    static async findByInviter(inviter) {
        const result = await runQuery('SELECT * FROM invites WHERE inviter = ?', [inviter]);
        return result.map(row => new InviteModel(row));
    }

    static async findByInvitee(invitee) {
        const result = await runQuery('SELECT * FROM invites WHERE invitee = ?', [invitee]);
        return result.map(row => new InviteModel(row));
    }
}

module.exports = InviteModel;
