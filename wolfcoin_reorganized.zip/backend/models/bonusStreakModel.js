const { db, runQuery, get } = require('../config/db');

class BonusStreak {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.currentDay = data.currentDay || 1;
        this.lastCollectedAt = data.lastCollectedAt;
        this.isStreakBroken = data.isStreakBroken;
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByUserId(userId) {
        const row = await get('SELECT * FROM bonus_streak WHERE userId = ?', [userId]);
        return row ? new BonusStreak(row) : null;
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE bonus_streak 
                SET userId = ?, 
                    currentDay = ?, 
                    lastCollectedAt = ?,
                    isStreakBroken = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.userId, this.currentDay, this.lastCollectedAt, this.isStreakBroken, now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO bonus_streak (
                    userId, currentDay, lastCollectedAt, 
                    isStreakBroken, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?)`,
                [this.userId, this.currentDay, this.lastCollectedAt, this.isStreakBroken, now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    // اگر streak شکسته شده باشد، روز بعدی را به 1 برمی‌گرداند
    async preSave() {
        if (this.isStreakBroken) {
            this.currentDay = 1;
        }
    }
}

module.exports = BonusStreak;
