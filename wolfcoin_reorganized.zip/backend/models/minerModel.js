const { runQuery } = require('../config/db');
const logger = require('../utils/logger');

class Miner {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.deviceId = data.deviceId;
        this.rate = data.rate || 0.5; // Base rate: 0.5 points per hour
        this.accumulatedPoints = data.accumulatedPoints || 0;
        this.totalPoints = data.totalPoints || 0;
        this.lastMiningTime = data.lastMiningTime ? new Date(data.lastMiningTime) : new Date();
        this.lastClaimTime = data.lastClaimTime ? new Date(data.lastClaimTime) : new Date();
        this.status = data.status || 'IDLE';
        this.offlineDuration = data.offlineDuration || 4 * 60 * 60 * 1000; // 4 hours in milliseconds
        this.miningHistory = data.miningHistory ? JSON.parse(data.miningHistory) : [];
        this.activeBoosts = data.activeBoosts ? JSON.parse(data.activeBoosts) : [];
        this.createdAt = data.createdAt ? new Date(data.createdAt) : new Date();
        this.updatedAt = data.updatedAt ? new Date(data.updatedAt) : new Date();
    }

    // Save miner to database
    async save() {
        try {
            // Validate required fields
            if (!this.userId || !this.deviceId) {
                throw new Error('Missing required fields');
            }

            // Validate numeric fields
            if (!Number.isFinite(this.rate) || this.rate < 0.1) {
                throw new Error('Invalid mining rate');
            }
            if (!Number.isFinite(this.accumulatedPoints) || this.accumulatedPoints < 0) {
                throw new Error('Invalid accumulated points');
            }
            if (!Number.isFinite(this.totalPoints) || this.totalPoints < 0) {
                throw new Error('Invalid total points');
            }

            // Validate offline duration
            if (this.offlineDuration < 4 * 60 * 60 * 1000 || this.offlineDuration > 24 * 60 * 60 * 1000) {
                throw new Error('Invalid offline duration');
            }

            // Validate status
            if (!['IDLE', 'MINING', 'CLAIMING'].includes(this.status)) {
                throw new Error('Invalid status');
            }

            const now = new Date().toISOString();
            this.updatedAt = now;

            if (this.id) {
                // Update
                await runQuery(
                    `UPDATE miner SET
                        userId = ?, deviceId = ?, rate = ?, accumulatedPoints = ?,
                        totalPoints = ?, lastMiningTime = ?, lastClaimTime = ?,
                        status = ?, offlineDuration = ?, miningHistory = ?,
                        activeBoosts = ?, updatedAt = ?
                    WHERE id = ?`,
                    [
                        this.userId, this.deviceId, this.rate, this.accumulatedPoints,
                        this.totalPoints, this.lastMiningTime.toISOString(), this.lastClaimTime.toISOString(),
                        this.status, this.offlineDuration, JSON.stringify(this.miningHistory),
                        JSON.stringify(this.activeBoosts), now, this.id
                    ]
                );
            } else {
                // Insert
                const result = await runQuery(
                    `INSERT INTO miner (
                        userId, deviceId, rate, accumulatedPoints, totalPoints,
                        lastMiningTime, lastClaimTime, status, offlineDuration,
                        miningHistory, activeBoosts, createdAt, updatedAt
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        this.userId, this.deviceId, this.rate, this.accumulatedPoints,
                        this.totalPoints, this.lastMiningTime.toISOString(), this.lastClaimTime.toISOString(),
                        this.status, this.offlineDuration, JSON.stringify(this.miningHistory),
                        JSON.stringify(this.activeBoosts), now, now
                    ]
                );
                this.id = result.lastID;
            }

            return this;
        } catch (error) {
            logger.error('Error saving miner:', error);
            throw error;
        }
    }

    // Calculate earned points
    calculateEarnedPoints() {
        const now = new Date();
        const duration = Math.min(
            now - this.lastMiningTime,
            this.offlineDuration
        );
        
        if (duration <= 0) return 0;
        
        // Convert duration from milliseconds to hours and calculate points
        const hours = duration / (1000 * 60 * 60);
        return this.rate * hours;
    }

    // Start mining
    async startMining() {
        if (this.status === 'MINING') {
            throw new Error('Miner is already mining');
        }
        
        this.status = 'MINING';
        this.lastMiningTime = new Date();
        return this.save();
    }

    // Stop mining and calculate rewards
    async stopMining() {
        if (this.status !== 'MINING') {
            throw new Error('Miner is not currently mining');
        }
        
        const earnedPoints = this.calculateEarnedPoints();
        const now = new Date();
        
        // Add to mining history
        this.miningHistory.push({
            startTime: this.lastMiningTime.toISOString(),
            endTime: now.toISOString(),
            pointsEarned: earnedPoints,
            rate: this.rate
        });
        
        this.accumulatedPoints += earnedPoints;
        this.status = 'IDLE';
        this.lastMiningTime = now;
        
        return this.save();
    }

    // Claim rewards
    async claimRewards() {
        if (this.status === 'CLAIMING') {
            throw new Error('Already processing a claim');
        }
        
        if (this.accumulatedPoints <= 0) {
            throw new Error('No points available to claim');
        }
        
        this.status = 'CLAIMING';
        const pointsToClaim = this.accumulatedPoints;
        this.totalPoints += pointsToClaim;
        this.accumulatedPoints = 0;
        this.lastClaimTime = new Date();
        
        await this.save();
        this.status = 'IDLE';
        await this.save();
        
        return pointsToClaim;
    }

    // Static method to find miner by ID
    static async findById(id) {
        try {
            const result = await runQuery('SELECT * FROM miner WHERE id = ?', [id]);
            return result.length ? new Miner(result[0]) : null;
        } catch (error) {
            logger.error('Error finding miner by ID:', error);
            throw error;
        }
    }

    // Static method to find miner by user ID
    static async findByUserId(userId) {
        try {
            const result = await runQuery('SELECT * FROM miner WHERE userId = ?', [userId]);
            return result.length ? new Miner(result[0]) : null;
        } catch (error) {
            logger.error('Error finding miner by user ID:', error);
            throw error;
        }
    }

    // Static method to find miner by device ID
    static async findByDeviceId(deviceId) {
        try {
            const result = await runQuery('SELECT * FROM miner WHERE deviceId = ?', [deviceId]);
            return result.length ? new Miner(result[0]) : null;
        } catch (error) {
            logger.error('Error finding miner by device ID:', error);
            throw error;
        }
    }

    // Static method to find miner by user ID and device ID
    static async findByUserAndDevice(userId, deviceId) {
        try {
            const result = await runQuery(
                'SELECT * FROM miner WHERE userId = ? AND deviceId = ?',
                [userId, deviceId]
            );
            return result.length ? new Miner(result[0]) : null;
        } catch (error) {
            logger.error('Error finding miner by user and device:', error);
            throw error;
        }
    }
}

module.exports = Miner;
