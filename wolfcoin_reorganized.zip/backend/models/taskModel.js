const { db, runQuery, getAll, get } = require('../config/db');

class Task {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.type = data.type;
        this.status = data.status || 'PENDING';
        this.platform = data.platform;
        this.points = data.points || 0;
        this.link = data.link;
        this.instagramUsername = data.instagramUsername;
        this.adminNote = data.adminNote;
        this.verificationCount = data.verificationCount || 0;
        this.lastVerified = data.lastVerified;
        this.completedAt = data.completedAt;
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByUserId(userId) {
        const rows = await getAll('SELECT * FROM task WHERE userId = ?', [userId]);
        return rows.map(row => new Task(row));
    }

    static async findPendingByUserId(userId) {
        const rows = await getAll(
            'SELECT * FROM task WHERE userId = ? AND status = ?',
            [userId, 'PENDING']
        );
        return rows.map(row => new Task(row));
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE task 
                SET userId = ?, 
                    type = ?,
                    status = ?,
                    platform = ?,
                    points = ?,
                    link = ?,
                    instagramUsername = ?,
                    adminNote = ?,
                    verificationCount = ?,
                    lastVerified = ?,
                    completedAt = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.userId, this.type, this.status, this.platform,
                 this.points, this.link, this.instagramUsername,
                 this.adminNote, this.verificationCount, this.lastVerified,
                 this.completedAt, now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO task (
                    userId, type, status, platform,
                    points, link, instagramUsername,
                    adminNote, verificationCount, lastVerified,
                    completedAt, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [this.userId, this.type, this.status, this.platform,
                 this.points, this.link, this.instagramUsername,
                 this.adminNote, this.verificationCount, this.lastVerified,
                 this.completedAt, now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    async complete() {
        this.status = 'COMPLETED';
        this.completedAt = new Date().toISOString();
        return await this.save();
    }

    async fail() {
        this.status = 'FAILED';
        return await this.save();
    }

    isExpired() {
        if (!this.expiresAt) return false;
        return new Date() > new Date(this.expiresAt);
    }

    isFirstClick() {
        return this.status === 'PENDING';
    }

    isCompleted() {
        return this.status === 'COMPLETED';
    }

    isWaitingApproval() {
        return this.status === 'WAITING_APPROVAL';
    }

    async updateStatus(newStatus, note = null) {
        this.status = newStatus;
        if (note) {
            this.adminNote = note;
        }
        if (newStatus === 'COMPLETED') {
            this.completedAt = new Date().toISOString();
        }
        await this.save();
    }
}

module.exports = Task;
