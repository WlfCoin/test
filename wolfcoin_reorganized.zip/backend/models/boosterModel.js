const { db, runQuery, getAll, get } = require('../config/db');

class Booster {
    constructor(data) {
        this.id = data.id;
        this.name = data.name;
        this.description = data.description;
        this.multiplier = data.multiplier || 1.0;
        this.duration = data.duration;
        this.price = data.price;
        this.currency = data.currency;
        this.type = data.type;
        this.active = data.active || false;
        this.maxPurchases = data.maxPurchases;
        this.purchaseCount = data.purchaseCount;
        this.startDate = data.startDate;
        this.endDate = data.endDate;
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByUserId(userId) {
        const row = await get('SELECT * FROM booster WHERE userId = ? AND active = 1', [userId]);
        return row ? new Booster(row) : null;
    }

    static async findAllActiveByUserId(userId) {
        const rows = await getAll('SELECT * FROM booster WHERE userId = ? AND active = 1', [userId]);
        return rows.map(row => new Booster(row));
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE booster 
                SET name = ?, 
                    description = ?, 
                    multiplier = ?, 
                    duration = ?,
                    price = ?,
                    currency = ?,
                    type = ?,
                    active = ?,
                    maxPurchases = ?,
                    purchaseCount = ?,
                    startDate = ?,
                    endDate = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.name, this.description, this.multiplier, this.duration,
                 this.price, this.currency, this.type, this.active ? 1 : 0,
                 this.maxPurchases, this.purchaseCount, this.startDate, this.endDate,
                 now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO booster (
                    name, description, multiplier, duration,
                    price, currency, type, active,
                    maxPurchases, purchaseCount, startDate, endDate,
                    createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [this.name, this.description, this.multiplier, this.duration,
                 this.price, this.currency, this.type, this.active ? 1 : 0,
                 this.maxPurchases, this.purchaseCount, this.startDate, this.endDate,
                 now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    async activate() {
        const now = new Date();
        this.startDate = now;
        this.endDate = new Date(now.getTime() + this.duration * 60 * 60 * 1000); // duration in hours
        this.active = true;
        return await this.save();
    }

    async deactivate() {
        this.active = false;
        return await this.save();
    }

    isExpired() {
        if (!this.endDate) return false;
        return new Date() > new Date(this.endDate);
    }

    getRemainingTime() {
        if (!this.endDate || !this.active) return 0;
        const now = new Date();
        const end = new Date(this.endDate);
        const diff = end - now;
        return Math.max(0, diff);
    }
}

module.exports = Booster;
