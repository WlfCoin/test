const { db, runQuery, getAll, get } = require('../config/db');

class Bonus {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.streakDays = data.streakDays || 0;
        this.lastClaimed = data.lastClaimed;
        this.nextBonus = data.nextBonus || 1.0;
        this.resetDate = data.resetDate;
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByUserId(userId) {
        const row = await get('SELECT * FROM bonus WHERE userId = ?', [userId]);
        return row ? new Bonus(row) : null;
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE bonus 
                SET userId = ?, 
                    streakDays = ?, 
                    lastClaimed = ?, 
                    nextBonus = ?, 
                    resetDate = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.userId, this.streakDays, this.lastClaimed, 
                 this.nextBonus, this.resetDate, now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO bonus (
                    userId, streakDays, lastClaimed, 
                    nextBonus, resetDate, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [this.userId, this.streakDays, this.lastClaimed, 
                 this.nextBonus, this.resetDate, now, now]
            );
            this.id = result.lastID;
        }

        // Handle streak logic
        if (this.lastClaimed) {
            const now = new Date();
            const lastClaimDate = new Date(this.lastClaimed);
            const timeDiff = now - lastClaimDate;
            
            // If more than 28 hours have passed, reset streak
            if (timeDiff > 28 * 60 * 60 * 1000) {
                this.streakDays = 0;
                this.nextBonus = 1.0;
                await this.save();
            } 
            // If within valid time (20-28 hours), increment streak
            else if (timeDiff >= 20 * 60 * 60 * 1000) {
                this.streakDays += 1;
                
                // Reset after 30 days
                if (this.streakDays > 30) {
                    this.streakDays = 1;
                }
                
                // Calculate next day's bonus
                this.nextBonus = this.calculateStreakBonus();
                await this.save();
            }
        }

        return this;
    }

    async addToHistory(type, amount) {
        const now = new Date().toISOString();
        await runQuery(
            `INSERT INTO bonus_history (
                bonusId, type, amount, timestamp
            ) VALUES (?, ?, ?, ?)`,
            [this.id, type, amount, now]
        );
    }

    async getHistory() {
        return await getAll(
            'SELECT * FROM bonus_history WHERE bonusId = ? ORDER BY timestamp DESC',
            [this.id]
        );
    }

    canClaimStreak() {
        if (!this.lastClaimed) return true;

        const now = new Date();
        const lastClaimDate = new Date(this.lastClaimed);
        const timeDiff = now - lastClaimDate;
        const daysDiff = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

        // Can claim if it's been between 20-28 hours since last claim
        return daysDiff === 1 || (timeDiff >= 20 * 60 * 60 * 1000 && timeDiff <= 28 * 60 * 60 * 1000);
    }

    calculateStreakBonus() {
        return this.streakDays * 0.5 + 1.0; // Base 1.0 + 0.5 per streak day
    }
}

module.exports = Bonus;
