const { db, runQuery, getAll, get } = require('../config/db');

class BotTask {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.type = data.type;
        this.status = data.status || 'PENDING';
        this.points = data.points || 0;
        this.completedAt = data.completedAt;
        this.createdAt = data.createdAt;
        this.updatedAt = data.updatedAt;
    }

    static async findByUserId(userId) {
        const rows = await getAll('SELECT * FROM bot_task WHERE userId = ?', [userId]);
        return rows.map(row => new BotTask(row));
    }

    static async findPendingByUserId(userId) {
        const rows = await getAll(
            'SELECT * FROM bot_task WHERE userId = ? AND status = ?',
            [userId, 'PENDING']
        );
        return rows.map(row => new BotTask(row));
    }

    async save() {
        const now = new Date().toISOString();
        if (this.id) {
            // Update
            await runQuery(
                `UPDATE bot_task 
                SET userId = ?, 
                    type = ?,
                    status = ?,
                    points = ?,
                    completedAt = ?,
                    updatedAt = ?
                WHERE id = ?`,
                [this.userId, this.type, this.status,
                 this.points, this.completedAt, now, this.id]
            );
        } else {
            // Insert
            const result = await runQuery(
                `INSERT INTO bot_task (
                    userId, type, status,
                    points, completedAt, createdAt, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [this.userId, this.type, this.status,
                 this.points, this.completedAt, now, now]
            );
            this.id = result.lastID;
        }
        return this;
    }

    async complete() {
        this.status = 'COMPLETED';
        this.completedAt = new Date().toISOString();
        return await this.save();
    }

    async fail() {
        this.status = 'FAILED';
        return await this.save();
    }

    isPending() {
        return this.status === 'PENDING';
    }

    isCompleted() {
        return this.status === 'COMPLETED';
    }
}

module.exports = BotTask;
