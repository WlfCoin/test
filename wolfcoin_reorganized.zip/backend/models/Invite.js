const { runQuery } = require('../config/db');
const logger = require('../utils/logger');

class Invite {
    constructor(data) {
        this.id = data.id;
        this.userId = data.userId;
        this.telegramId = data.telegramId;
        this.mainChannelLink = data.mainChannelLink;
        this.activityChannelLink = data.activityChannelLink;
        this.invitedUsers = data.invitedUsers ? 
            (typeof data.invitedUsers === 'string' ? JSON.parse(data.invitedUsers) : data.invitedUsers) 
            : [];
        this.totalPoints = data.totalPoints || 0;
        this.createdAt = data.createdAt ? new Date(data.createdAt) : new Date();
        this.updatedAt = data.updatedAt ? new Date(data.updatedAt) : new Date();
    }

    // Validate invite data
    validate() {
        if (!this.userId) throw new Error('Missing required field: userId');
        if (!this.telegramId) throw new Error('Missing required field: telegramId');
        if (!this.mainChannelLink) throw new Error('Missing required field: mainChannelLink');
        if (!this.activityChannelLink) throw new Error('Missing required field: activityChannelLink');
        
        // Validate invitedUsers structure
        if (this.invitedUsers.some(user => !user.telegramId || !user.channel)) {
            throw new Error('Invalid invitedUsers data structure');
        }
    }

    static async findByUserId(userId) {
        try {
            const result = await runQuery('SELECT * FROM invite WHERE userId = ?', [userId]);
            return result.length ? new Invite(result[0]) : null;
        } catch (error) {
            logger.error('Error finding invite by user ID:', error);
            throw error;
        }
    }

    static async findByTelegramId(telegramId) {
        try {
            const result = await runQuery('SELECT * FROM invite WHERE telegramId = ?', [telegramId]);
            return result.length ? new Invite(result[0]) : null;
        } catch (error) {
            logger.error('Error finding invite by telegram ID:', error);
            throw error;
        }
    }

    static async findByMainChannelLink(mainChannelLink) {
        try {
            const result = await runQuery('SELECT * FROM invite WHERE mainChannelLink = ?', [mainChannelLink]);
            return result.length ? new Invite(result[0]) : null;
        } catch (error) {
            logger.error('Error finding invite by main channel link:', error);
            throw error;
        }
    }

    static async findByActivityChannelLink(activityChannelLink) {
        try {
            const result = await runQuery('SELECT * FROM invite WHERE activityChannelLink = ?', [activityChannelLink]);
            return result.length ? new Invite(result[0]) : null;
        } catch (error) {
            logger.error('Error finding invite by activity channel link:', error);
            throw error;
        }
    }

    async save() {
        try {
            // Validate data before saving
            this.validate();

            const now = new Date().toISOString();
            this.updatedAt = now;

            if (this.id) {
                // Update
                await runQuery(
                    `UPDATE invite 
                    SET userId = ?, 
                        telegramId = ?,
                        mainChannelLink = ?,
                        activityChannelLink = ?,
                        invitedUsers = ?,
                        totalPoints = ?,
                        updatedAt = ?
                    WHERE id = ?`,
                    [
                        this.userId, this.telegramId, this.mainChannelLink,
                        this.activityChannelLink, JSON.stringify(this.invitedUsers),
                        this.totalPoints, now, this.id
                    ]
                );
            } else {
                // Insert
                const result = await runQuery(
                    `INSERT INTO invite (
                        userId, telegramId, mainChannelLink,
                        activityChannelLink, invitedUsers, totalPoints,
                        createdAt, updatedAt
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        this.userId, this.telegramId, this.mainChannelLink,
                        this.activityChannelLink, JSON.stringify(this.invitedUsers),
                        this.totalPoints, now, now
                    ]
                );
                this.id = result.lastID;
            }
            return this;
        } catch (error) {
            logger.error('Error saving invite:', error);
            throw error;
        }
    }

    async addInvitedUser(telegramId, username, channel) {
        try {
            if (!telegramId || !username || !channel) {
                throw new Error('Missing required fields for invited user');
            }

            const existingUser = this.invitedUsers.find(user => 
                user.telegramId === telegramId && user.channel === channel
            );
            
            if (existingUser) {
                throw new Error('User already invited to this channel');
            }

            this.invitedUsers.push({
                telegramId,
                username,
                channel,
                pointsAwarded: false,
                invitedAt: new Date().toISOString()
            });

            await this.save();
            return true;
        } catch (error) {
            logger.error('Error adding invited user:', error);
            throw error;
        }
    }

    async calculatePoints() {
        try {
            let pointsToAdd = 0;
            const unprocessedInvites = this.invitedUsers.filter(user => !user.pointsAwarded);
            
            // گروه‌بندی کاربران بر اساس telegramId
            const userGroups = {};
            unprocessedInvites.forEach(invite => {
                if (!userGroups[invite.telegramId]) {
                    userGroups[invite.telegramId] = [];
                }
                userGroups[invite.telegramId].push(invite);
            });

            // محاسبه امتیاز برای هر کاربر
            Object.values(userGroups).forEach(userInvites => {
                // اگر کاربر در هر دو کانال عضو شده باشد
                if (userInvites.length === 2) {
                    pointsToAdd += 2; // 2 امتیاز برای عضویت در هر دو کانال
                    userInvites.forEach(invite => {
                        const userIndex = this.invitedUsers.findIndex(user => 
                            user.telegramId === invite.telegramId && 
                            user.channel === invite.channel
                        );
                        if (userIndex !== -1) {
                            this.invitedUsers[userIndex].pointsAwarded = true;
                            this.invitedUsers[userIndex].awardedAt = new Date().toISOString();
                        }
                    });
                }
            });

            if (pointsToAdd > 0) {
                this.totalPoints += pointsToAdd;
                await this.save();
            }

            return pointsToAdd;
        } catch (error) {
            logger.error('Error calculating points:', error);
            throw error;
        }
    }

    // Static method to get total invites by user
    static async getTotalInvitesByUser(userId) {
        try {
            const invite = await this.findByUserId(userId);
            return invite ? invite.invitedUsers.length : 0;
        } catch (error) {
            logger.error('Error getting total invites:', error);
            throw error;
        }
    }

    // Static method to get total points by user
    static async getTotalPointsByUser(userId) {
        try {
            const invite = await this.findByUserId(userId);
            return invite ? invite.totalPoints : 0;
        } catch (error) {
            logger.error('Error getting total points:', error);
            throw error;
        }
    }

    // Static method to get user's invite statistics
    static async getInviteStats(userId) {
        try {
            const invite = await this.findByUserId(userId);
            if (!invite) return null;

            const totalInvites = invite.invitedUsers.length;
            const completedInvites = invite.invitedUsers.filter(user => user.pointsAwarded).length;
            const pendingInvites = totalInvites - completedInvites;
            const totalPoints = invite.totalPoints;

            return {
                totalInvites,
                completedInvites,
                pendingInvites,
                totalPoints,
                lastUpdated: invite.updatedAt
            };
        } catch (error) {
            logger.error('Error getting invite stats:', error);
            throw error;
        }
    }

    // Static method to get top inviters
    static async getTopInviters(limit = 10) {
        try {
            const result = await runQuery('SELECT * FROM invite ORDER BY totalPoints DESC LIMIT ?', [limit]);
            return result.map(row => ({
                userId: row.userId,
                telegramId: row.telegramId,
                totalInvites: JSON.parse(row.invitedUsers).length,
                totalPoints: row.totalPoints
            }));
        } catch (error) {
            logger.error('Error getting top inviters:', error);
            throw error;
        }
    }
}

module.exports = Invite;
