const cron = require('node-cron');
const PointsService = require('./pointsService');
const { DAILY_RESET_TIME, DAILY_REPORT_TIME } = require('../config/constants');

// ریست روزانه در 23:59:59 UTC
cron.schedule(DAILY_RESET_TIME, async () => {
    try {
        await PointsService.dailyReset();
    } catch (error) {
        console.error('Daily reset failed:', error);
    }
}, {
    timezone: 'UTC'
});

// گزارش روزانه در 12:00:00 UTC
cron.schedule(DAILY_REPORT_TIME, async () => {
    try {
        await PointsService.generateDailyReport();
    } catch (error) {
        console.error('Daily report failed:', error);
    }
}, {
    timezone: 'UTC'
});
