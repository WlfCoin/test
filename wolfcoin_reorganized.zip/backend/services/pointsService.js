const Redis = require('../config/redis');
const User = require('../models/userModel');
const telegram = require('../utils/telegram');
const { 
    TOTAL_POINTS_SUPPLY,
    REDIS_KEYS,
    ACTIVITY_CHANNEL_ID
} = require('../config/constants');

class PointsService {
    // مدیریت امتیازات جدید
    static async mintPoints(userId, amount) {
        const totalMinted = await Redis.incrby(REDIS_KEYS.TOTAL_MINTED_POINTS, amount);
        await Redis.incrby(REDIS_KEYS.DAILY_MINTED_POINTS, amount);

        // چک کردن محدودیت کل امتیازات
        if (totalMinted > TOTAL_POINTS_SUPPLY) {
            throw new Error('Total points supply exceeded');
        }

        // اضافه کردن امتیاز به کاربر
        await User.findByIdAndUpdate(userId, { $inc: { points: amount } });
    }

    // ریست کردن روزانه
    static async dailyReset() {
        // ذخیره آمار روز قبل
        const dailyMinted = await Redis.get(REDIS_KEYS.DAILY_MINTED_POINTS);
        const dailyNewUsers = await Redis.get(REDIS_KEYS.DAILY_NEW_USERS);
        
        // ریست کانترهای روزانه
        await Redis.set(REDIS_KEYS.DAILY_MINTED_POINTS, 0);
        await Redis.set(REDIS_KEYS.DAILY_NEW_USERS, 0);

        return { dailyMinted, dailyNewUsers };
    }

    // گزارش روزانه
    static async generateDailyReport() {
        const totalMinted = await Redis.get(REDIS_KEYS.TOTAL_MINTED_POINTS) || 0;
        const dailyMinted = await Redis.get(REDIS_KEYS.DAILY_MINTED_POINTS) || 0;
        const dailyNewUsers = await Redis.get(REDIS_KEYS.DAILY_NEW_USERS) || 0;
        const totalUsers = await User.countDocuments();
        const remainingPoints = TOTAL_POINTS_SUPPLY - totalMinted;

        const report = `📊 Daily Report\n\n` +
            `🎯 Today's Minted Points: ${dailyMinted.toLocaleString()}\n` +
            `💰 Remaining Points: ${remainingPoints.toLocaleString()}\n` +
            `👥 New Users Today: ${dailyNewUsers}\n` +
            `👥 Total Users: ${totalUsers.toLocaleString()}`;

        // ارسال به کانال تلگرام
        await telegram.sendMessage(ACTIVITY_CHANNEL_ID, report);
    }

    // ثبت کاربر جدید
    static async trackNewUser() {
        await Redis.incr(REDIS_KEYS.DAILY_NEW_USERS);
    }
}

module.exports = PointsService;
