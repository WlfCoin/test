const axios = require('axios');
const logger = require('../utils/logger');
const cache = require('../utils/cache');

const CACHE_TTL = 60 * 60; // 1 hour

class SocialVerificationService {
    constructor() {
        this.telegram = {
            botToken: process.env.TELEGRAM_BOT_TOKEN,
            channelId: process.env.TELEGRAM_CHANNEL_ID
        };
        
        this.twitter = {
            apiKey: process.env.TWITTER_API_KEY,
            apiSecret: process.env.TWITTER_API_SECRET,
            accountId: process.env.TWITTER_ACCOUNT_ID
        };
        
        this.youtube = {
            apiKey: process.env.YOUTUBE_API_KEY,
            channelId: process.env.YOUTUBE_CHANNEL_ID
        };
        
        this.instagram = {
            accessToken: process.env.INSTAGRAM_ACCESS_TOKEN,
            accountId: process.env.INSTAGRAM_ACCOUNT_ID
        };
    }

    async verifyTelegramMembership(userId) {
        try {
            const cacheKey = `telegram:member:${userId}`;
            const cached = await cache.get(cacheKey);
            if (cached !== null) {
                return cached;
            }

            const response = await axios.get(
                `https://api.telegram.org/bot${this.telegram.botToken}/getChatMember`,
                {
                    params: {
                        chat_id: this.telegram.channelId,
                        user_id: userId
                    }
                }
            );

            const isMember = ['member', 'administrator', 'creator'].includes(
                response.data.result.status
            );

            await cache.set(cacheKey, isMember, CACHE_TTL);
            return isMember;
        } catch (error) {
            logger.error(`Error verifying Telegram membership for ${userId}:`, error);
            return false;
        }
    }

    async verifyTwitterFollow(userId) {
        try {
            const cacheKey = `twitter:follow:${userId}`;
            const cached = await cache.get(cacheKey);
            if (cached !== null) {
                return cached;
            }

            // Twitter API v2 endpoint for checking follows
            const response = await axios.get(
                `https://api.twitter.com/2/users/${userId}/following/${this.twitter.accountId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${this.twitter.apiKey}`
                    }
                }
            );

            const isFollowing = response.data.data !== null;
            await cache.set(cacheKey, isFollowing, CACHE_TTL);
            return isFollowing;
        } catch (error) {
            logger.error(`Error verifying Twitter follow for ${userId}:`, error);
            return false;
        }
    }

    async verifyYoutubeSubscription(userId) {
        try {
            const cacheKey = `youtube:sub:${userId}`;
            const cached = await cache.get(cacheKey);
            if (cached !== null) {
                return cached;
            }

            const response = await axios.get(
                `https://www.googleapis.com/youtube/v3/subscriptions`,
                {
                    params: {
                        part: 'snippet',
                        forChannelId: this.youtube.channelId,
                        channelId: userId,
                        key: this.youtube.apiKey
                    }
                }
            );

            const isSubscribed = response.data.items.length > 0;
            await cache.set(cacheKey, isSubscribed, CACHE_TTL);
            return isSubscribed;
        } catch (error) {
            logger.error(`Error verifying YouTube subscription for ${userId}:`, error);
            return false;
        }
    }

    async verifyInstagramFollow(userId) {
        try {
            const cacheKey = `instagram:follow:${userId}`;
            const cached = await cache.get(cacheKey);
            if (cached !== null) {
                return cached;
            }

            // Instagram Graph API endpoint for checking follows
            const response = await axios.get(
                `https://graph.instagram.com/${this.instagram.accountId}/followers`,
                {
                    params: {
                        access_token: this.instagram.accessToken,
                        user_id: userId
                    }
                }
            );

            const isFollowing = response.data.data.some(
                follower => follower.id === userId
            );
            
            await cache.set(cacheKey, isFollowing, CACHE_TTL);
            return isFollowing;
        } catch (error) {
            logger.error(`Error verifying Instagram follow for ${userId}:`, error);
            return false;
        }
    }
}

module.exports = new SocialVerificationService();
