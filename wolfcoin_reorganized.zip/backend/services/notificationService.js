const WebSocket = require('ws');
const logger = require('../utils/logger');

class NotificationService {
    constructor() {
        this.clients = new Map(); // userId -> WebSocket
        this.init();
    }

    init() {
        this.wss = new WebSocket.Server({ port: process.env.WS_PORT || 8080 });
        
        this.wss.on('connection', (ws, req) => {
            const userId = this.getUserIdFromRequest(req);
            if (!userId) {
                ws.close();
                return;
            }

            this.clients.set(userId, ws);
            logger.info(`Client connected: ${userId}`);

            ws.on('close', () => {
                this.clients.delete(userId);
                logger.info(`Client disconnected: ${userId}`);
            });

            ws.on('error', (error) => {
                logger.error(`WebSocket error for ${userId}:`, error);
                this.clients.delete(userId);
            });
        });

        logger.info('WebSocket server initialized');
    }

    getUserIdFromRequest(req) {
        // Extract userId from query parameters or headers
        const params = new URLSearchParams(req.url.split('?')[1]);
        return params.get('userId');
    }

    async sendNotification(userId, notification) {
        try {
            const ws = this.clients.get(userId);
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify(notification));
                logger.info(`Notification sent to user ${userId}:`, notification);
                return true;
            }
            return false;
        } catch (error) {
            logger.error(`Error sending notification to ${userId}:`, error);
            return false;
        }
    }

    async sendBoostExpirationWarning(userId, boost, timeRemaining) {
        const notification = {
            type: 'BOOST_EXPIRATION_WARNING',
            title: 'Boost Expiring Soon',
            message: `Your ${boost.type} boost will expire in ${Math.round(timeRemaining / (60 * 60 * 1000))} hours`,
            boostId: boost._id,
            boostType: boost.type,
            timeRemaining
        };

        return this.sendNotification(userId, notification);
    }

    async sendBoostExpired(userId, boost) {
        const notification = {
            type: 'BOOST_EXPIRED',
            title: 'Boost Expired',
            message: `Your ${boost.type} boost has expired`,
            boostId: boost._id,
            boostType: boost.type
        };

        return this.sendNotification(userId, notification);
    }

    async sendBoostPurchased(userId, boost) {
        const notification = {
            type: 'BOOST_PURCHASED',
            title: 'Boost Purchased',
            message: `Your ${boost.type} boost is now active`,
            boostId: boost._id,
            boostType: boost.type,
            duration: boost.endTime - boost.startTime
        };

        return this.sendNotification(userId, notification);
    }
}

module.exports = new NotificationService();
