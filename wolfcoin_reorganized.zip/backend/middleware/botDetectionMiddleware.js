const UAParser = require('ua-parser-js');
const { redisClient } = require('./rateLimitMiddleware');

const SUSPICIOUS_PATTERNS = {
    userAgent: [
        /bot/i,
        /crawler/i,
        /spider/i,
        /headless/i,
        /selenium/i,
        /puppeteer/i,
        /phantom/i
    ],
    headers: [
        'x-forwarded-for',
        'forwarded',
        'x-real-ip',
        'x-originating-ip',
        'cf-connecting-ip'
    ]
};

const botDetection = async (req, res, next) => {
    try {
        const score = await calculateBotScore(req);
        
        // Store the score for monitoring
        await redisClient.hset(
            `bot_scores:${req.ip}`,
            'score',
            score,
            'timestamp',
            Date.now()
        );
        
        // If score is too high, block the request
        if (score >= 0.7) {
            return res.status(403).json({
                success: false,
                error: 'Automated access detected'
            });
        }

        next();
    } catch (error) {
        console.error('Bot detection error:', error);
        // In case of error, let the request through but log it
        next();
    }
};

const calculateBotScore = async (req) => {
    let score = 0;
    
    // 1. Check User-Agent
    const ua = new UAParser(req.headers['user-agent']);
    const userAgent = ua.getResult();
    
    // Check for suspicious user agent patterns
    if (SUSPICIOUS_PATTERNS.userAgent.some(pattern => 
        pattern.test(req.headers['user-agent'])
    )) {
        score += 0.3;
    }
    
    // Check for missing or suspicious browser info
    if (!userAgent.browser.name || !userAgent.os.name) {
        score += 0.2;
    }
    
    // 2. Check Headers
    const suspiciousHeaders = SUSPICIOUS_PATTERNS.headers
        .filter(header => req.headers[header])
        .length;
    score += suspiciousHeaders * 0.1;
    
    // 3. Check Request Timing
    const key = `request_timing:${req.ip}`;
    const lastRequest = await redisClient.get(key);
    
    if (lastRequest) {
        const timeDiff = Date.now() - parseInt(lastRequest);
        
        // If requests are too frequent (less than 100ms apart)
        if (timeDiff < 100) {
            score += 0.2;
        }
    }
    
    // Update last request time
    await redisClient.set(key, Date.now(), 'EX', 3600);
    
    // 4. Check Request Pattern
    const patternKey = `request_pattern:${req.ip}`;
    const pattern = await redisClient.lrange(patternKey, 0, 9);
    
    // Add current endpoint to pattern
    await redisClient.lpush(patternKey, req.path);
    await redisClient.ltrim(patternKey, 0, 9);
    
    // Check for repetitive patterns
    if (pattern.length >= 5) {
        const isRepetitive = pattern.every((path, i, arr) => 
            i === 0 || path === arr[i - 1]
        );
        if (isRepetitive) {
            score += 0.2;
        }
    }
    
    // 5. Device Fingerprint Check
    const deviceId = req.headers['x-device-id'];
    if (!deviceId) {
        score += 0.1;
    } else {
        const deviceKey = `device:${deviceId}`;
        const knownDevice = await redisClient.get(deviceKey);
        
        if (!knownDevice) {
            // New device, store it with current IP
            await redisClient.set(deviceKey, req.ip, 'EX', 86400 * 30); // 30 days
        } else if (knownDevice !== req.ip) {
            // Device ID being used from different IP
            score += 0.2;
        }
    }
    
    return Math.min(score, 1);
};

// Monitor and report suspicious activity
const monitorSuspiciousActivity = async () => {
    try {
        const suspiciousIPs = await redisClient.keys('bot_scores:*');
        
        for (const key of suspiciousIPs) {
            const score = await redisClient.hget(key, 'score');
            const timestamp = await redisClient.hget(key, 'timestamp');
            
            if (score >= 0.5) {
                console.warn(`Suspicious activity detected:`, {
                    ip: key.split(':')[1],
                    score,
                    timestamp: new Date(parseInt(timestamp))
                });
                
                // You can implement additional actions here:
                // - Send notifications
                // - Add to blacklist
                // - Increase monitoring
            }
        }
    } catch (error) {
        console.error('Error monitoring suspicious activity:', error);
    }
};

// Run monitoring every 5 minutes
setInterval(monitorSuspiciousActivity, 5 * 60 * 1000);

module.exports = { botDetection };
