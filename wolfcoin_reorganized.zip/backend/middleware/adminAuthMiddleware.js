const jwt = require('jsonwebtoken');
const User = require('../models/userModel');
const logger = require('../utils/logger');

const adminAuth = async (req, res, next) => {
    try {
        // 1. Check if token exists in headers
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({
                success: false,
                error: 'No token provided'
            });
        }

        // 2. Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'User not found'
            });
        }

        // 3. Check if user is admin and has 2FA enabled
        if (!user.isAdmin || !user.twoFactorEnabled) {
            logger.warn(`Unauthorized admin access attempt by user: ${user._id}`);
            return res.status(403).json({
                success: false,
                error: 'Access denied'
            });
        }

        // 4. Check if 2FA token is valid
        const twoFactorToken = req.headers['x-2fa-token'];
        if (!twoFactorToken || !user.verify2FAToken(twoFactorToken)) {
            logger.warn(`Invalid 2FA attempt for admin: ${user._id}`);
            return res.status(403).json({
                success: false,
                error: 'Invalid 2FA token'
            });
        }

        // 5. Check IP whitelist
        const clientIP = req.ip;
        const whitelistedIPs = process.env.ADMIN_IP_WHITELIST?.split(',') || [];
        if (!whitelistedIPs.includes(clientIP)) {
            logger.warn(`Admin access attempt from unauthorized IP: ${clientIP}`);
            return res.status(403).json({
                success: false,
                error: 'IP not whitelisted'
            });
        }

        // 6. Add rate limiting for failed attempts
        if (user.failedLoginAttempts >= 5) {
            const lastAttempt = new Date(user.lastFailedLogin);
            const lockoutPeriod = 30 * 60 * 1000; // 30 minutes
            if (Date.now() - lastAttempt < lockoutPeriod) {
                return res.status(403).json({
                    success: false,
                    error: 'Account temporarily locked. Try again later.'
                });
            } else {
                // Reset failed attempts after lockout period
                user.failedLoginAttempts = 0;
                await user.save();
            }
        }

        // 7. Log successful access
        logger.info(`Admin access granted to user: ${user._id}`);
        
        // Add user to request object
        req.user = user;
        next();
    } catch (error) {
        logger.error('Admin authentication error:', error);
        return res.status(401).json({
            success: false,
            error: 'Invalid token'
        });
    }
};

module.exports = adminAuth;
