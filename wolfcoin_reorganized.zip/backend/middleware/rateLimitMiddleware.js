const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const Redis = require('ioredis');

// Create Redis client
const redisClient = new Redis({
    host: process.env.REDIS_HOST || '66.29.133.146',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD,
    enableOfflineQueue: false
});

// Global rate limiter
const globalLimiter = rateLimit({
    store: new RedisStore({
        sendCommand: (...args) => redisClient.call(...args)
    }),
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: process.env.MAX_REQUESTS_PER_IP || 100,
    message: {
        success: false,
        error: 'Too many requests, please try again later'
    },
    standardHeaders: true,
    legacyHeaders: false
});

// Mining-specific rate limiter (more strict)
const miningLimiter = rateLimit({
    store: new RedisStore({
        sendCommand: (...args) => redisClient.call(...args)
    }),
    windowMs: 5 * 60 * 1000, // 5 minutes
    max: 10, // 10 requests per 5 minutes
    message: {
        success: false,
        error: 'Mining requests are limited, please wait'
    }
});

// Task verification rate limiter
const taskLimiter = rateLimit({
    store: new RedisStore({
        sendCommand: (...args) => redisClient.call(...args)
    }),
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 20, // 20 task verifications per hour
    message: {
        success: false,
        error: 'Task verification requests are limited, please try again later'
    }
});

// Bonus claim rate limiter
const bonusLimiter = rateLimit({
    store: new RedisStore({
        sendCommand: (...args) => redisClient.call(...args)
    }),
    windowMs: 24 * 60 * 60 * 1000, // 24 hours
    max: 1, // 1 bonus claim per day
    message: {
        success: false,
        error: 'Bonus can only be claimed once per day'
    }
});

module.exports = {
    globalLimiter,
    miningLimiter,
    taskLimiter,
    bonusLimiter,
    redisClient
};
