const Miner = require('../models/minerModel');

const validateDeviceId = async (req, res, next) => {
    try {
        const deviceId = req.headers['x-device-id'];
        if (!deviceId) {
            return res.status(400).json({
                success: false,
                error: 'Device ID is required'
            });
        }

        // Check if device ID is already in use by another user
        const existingMiner = await Miner.findOne({
            deviceId,
            userId: { $ne: req.user.id }
        });

        if (existingMiner) {
            return res.status(400).json({
                success: false,
                error: 'Device is already registered to another user'
            });
        }

        // Add device ID to request
        req.deviceId = deviceId;
        next();
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Server error in device validation'
        });
    }
};

module.exports = { validateDeviceId };
