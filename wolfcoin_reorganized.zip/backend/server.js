console.log('Environment Variables:', process.env);
console.log("Server is starting...");
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const logger = require('./utils/logger');
const { connectDB } = require('./config/db');
const redisClient = require('./config/redis');
const path = require('path');
const fs = require('fs');

const authRoutes = require('./api/routes/authRoutes');
const boostRoutes = require('./api/routes/boostRoutes');
const homeRoutes = require('./api/routes/homeRoutes');
const tasksRoutes = require('./api/routes/tasksRoutes');
const inviteRoutes = require('./api/routes/inviteRoutes');
const bonusRoutes = require('./api/routes/bonusRoutes');
const userRoutes = require('./api/routes/userRoutes');
const paymentRoutes = require('./api/routes/payment');

const app = express();
const PORT = process.env.BACKEND_PORT || 3000;
const HOST = '66.29.133.146';

const startServer = async () => {
    try {
        await connectDB();

        // Redis Test
        redisClient.set('test_key', 'test_value')
            .then(() => redisClient.get('test_key'))
            .then((value) => {
                console.log('Redis test value:', value);
            })
            .catch((err) => {
                console.error('Redis test error:', err);
            });

        app.listen(PORT, HOST, (err) => {
            if (err) {
                console.error(`Error occurred while starting server: ${err.message}`);
            } else {
                console.log(`Server is running at http://${HOST}:${PORT}`);
            }
        });

        app.use(cors());
        app.use(express.json());

        app.use((req, res, next) => {
            console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
            next();
        });

        app.use('/api/auth', authRoutes);
        app.use('/api/boost', boostRoutes);
        app.use('/api/home', homeRoutes);
        app.use('/api/tasks', tasksRoutes);
        app.use('/api/invite', inviteRoutes);
        app.use('/api/bonus', bonusRoutes);
        app.use('/api/user', userRoutes);
        app.use('/api/payment', paymentRoutes);

        app.get('/api/test', (req, res) => {
            res.json({ message: 'API is working!' });
        });

        app.get('/api/db-test', async (req, res) => {
            try {
                await runQuery('SELECT 1');
                res.json({ message: 'SQLite database is connected and responding.' });
            } catch (error) {
                res.status(500).json({ error: 'SQLite database is not responding.' });
            }
        });

        const buildPath = path.join(__dirname, '../frontend/build');
        app.use(express.static(buildPath));

        app.get('*', (req, res) => {
            res.sendFile(path.join(buildPath, 'index.html'));
        });

        const logFilePath = path.join(__dirname, 'logs', 'error.log');
        const logDir = path.join(__dirname, 'logs');
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir);
        }
        app.use((err, req, res, next) => {
            fs.appendFile(logFilePath, `[${new Date().toISOString()}] ${err.message}\n`, (writeErr) => {
                if (writeErr) {
                    console.error('Failed to write to log file:', writeErr.message);
                }
            });
            console.error('Error:', err.message);
            res.status(500).json({ error: 'Internal server error' });
        });

        process.on('uncaughtException', (err) => {
            console.error('Uncaught Exception:', err);
        });

        process.on('unhandledRejection', (reason, promise) => {
            console.error('Unhandled Rejection at:', promise, 'reason:', reason);
        });

    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

startServer();
