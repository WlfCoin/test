globals: {
  window: "readonly",
  document: "readonly",
  console: "readonly",
  alert: "readonly",
  fetch: "readonly",
  setInterval: "readonly",
  clearInterval: "readonly",
  localStorage: "readonly",
  sessionStorage: "readonly",
  self: "readonly",
  importScripts: "readonly",
  workbox: "readonly",
  CURRENT_USER_ID: "readonly",
  setTimeout: "readonly",
  BigInt: "readonly", // اضافه کردن BigInt
  SharedArrayBuffer: "readonly", // اضافه کردن SharedArrayBuffer
},
