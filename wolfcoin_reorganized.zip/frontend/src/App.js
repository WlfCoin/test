import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import AdminDashboard from './pages/AdminDashboard';
import AdminTaskManagement from './pages/AdminTaskManagement';
import AdminBoosterManagement from './pages/AdminBoosterManagement';
import AdminBonusManagement from './pages/AdminBonusManagement';
import Login2FA from './pages/Login2FA';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import Bonus from './pages/Bonus';
import Tasks from './pages/Tasks';
import Boost from './pages/Boost';
import Wallet from './pages/Wallet';
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme';

// Protected Route Component
const ProtectedAdminRoute = ({ children }) => {
    const { isAuthenticated, isAdmin, is2FAVerified } = useSelector(state => state.auth);
    
    if (!isAuthenticated || !isAdmin) {
        return <Navigate to="/login" />;
    }
    
    if (!is2FAVerified) {
        return <Navigate to="/admin/2fa" />;
    }
    
    return children;
};

const App = () => {
    return (
        <ThemeProvider theme={theme}>
            <Router>
                <Routes>
                    {/* Public Routes */}
                    <Route path="/" element={<Home />} />
                    <Route path="/bonus" element={<Bonus />} />
                    <Route path="/tasks" element={<Tasks />} />
                    <Route path="/boost" element={<Boost />} />
                    <Route path="/wallet" element={<Wallet />} />
                    
                    {/* Admin Routes */}
                    <Route path="/admin/2fa" element={<Login2FA />} />
                    <Route 
                        path="/admin"
                        element={
                            <ProtectedAdminRoute>
                                <AdminDashboard />
                            </ProtectedAdminRoute>
                        }
                    />
                    <Route 
                        path="/admin/tasks/:type"
                        element={
                            <ProtectedAdminRoute>
                                <AdminTaskManagement />
                            </ProtectedAdminRoute>
                        }
                    />
                    <Route 
                        path="/admin/boosters"
                        element={
                            <ProtectedAdminRoute>
                                <AdminBoosterManagement />
                            </ProtectedAdminRoute>
                        }
                    />
                    <Route 
                        path="/admin/bonus"
                        element={
                            <ProtectedAdminRoute>
                                <AdminBonusManagement />
                            </ProtectedAdminRoute>
                        }
                    />
                </Routes>
                <Navigation />
            </Router>
        </ThemeProvider>
    );
};

export default App;
