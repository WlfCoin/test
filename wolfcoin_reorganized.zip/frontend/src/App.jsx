import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Tasks from "./pages/Tasks";
import Invite from "./pages/Invite";
import Boost from "./pages/Boost";
import Wallet from "./pages/Wallet";
import Footer from "./components/Footer";
import "./styles/App.css";

function App() {
  return (
    <Router>
      <div className="app">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/team" element={<Invite />} />
          <Route path="/boost" element={<Boost />} />
          <Route path="/wallet" element={<Wallet />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
