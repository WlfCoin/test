import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async thunks
export const fetchTasks = createAsyncThunk(
    'tasks/fetchTasks',
    async ({ userId, type }) => {
        const response = await axios.get(`/api/tasks/${userId}?type=${type}`);
        return response.data.tasks;
    }
);

export const completeTask = createAsyncThunk(
    'tasks/completeTask',
    async ({ userId, taskId }) => {
        const response = await axios.post(`/api/tasks/${userId}/${taskId}/complete`);
        return response.data;
    }
);

const taskSlice = createSlice({
    name: 'tasks',
    initialState: {
        tasks: [],
        loading: false,
        error: null
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            // Fetch tasks
            .addCase(fetchTasks.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchTasks.fulfilled, (state, action) => {
                state.loading = false;
                state.tasks = action.payload;
            })
            .addCase(fetchTasks.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            })
            // Complete task
            .addCase(completeTask.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(completeTask.fulfilled, (state, action) => {
                state.loading = false;
                const { taskId, status } = action.payload;
                const task = state.tasks.find(t => t._id === taskId);
                if (task) {
                    task.status = status;
                }
            })
            .addCase(completeTask.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            });
    }
});

export default taskSlice.reducer;
