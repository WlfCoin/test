import { configureStore } from '@reduxjs/toolkit';
import minerReducer from './minerSlice';
import boostReducer from './boostSlice';
import taskReducer from './taskSlice';
import authReducer from './authSlice';

export const store = configureStore({
    reducer: {
        auth: authReducer,
        miner: minerReducer,
        boost: boostReducer,
        tasks: taskReducer
    },
});

export default store;
