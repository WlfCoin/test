import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    status: 'hunt', // hunt, mining, claim
    timeLeft: null,
    rate: 0.5, // Base rate: 0.5 points per hour
    accumulatedPoints: 0,
    currentPoints: 0, // Points being earned in current session
    lastUpdate: null,
    duration: 4 * 60 * 60, // 4 hours in seconds
};

export const minerSlice = createSlice({
    name: 'miner',
    initialState,
    reducers: {
        startMining: (state) => {
            state.status = 'mining';
            state.timeLeft = state.duration;
            state.lastUpdate = Date.now();
            state.currentPoints = 0;
        },
        updateTimer: (state) => {
            if (state.status === 'mining' && state.timeLeft > 0) {
                const now = Date.now();
                const elapsed = Math.floor((now - state.lastUpdate) / 1000);
                state.timeLeft = Math.max(0, state.timeLeft - elapsed);
                state.currentPoints = (state.rate / 3600) * elapsed;
                state.lastUpdate = now;

                if (state.timeLeft === 0) {
                    state.status = 'claim';
                }
            }
        },
        claimRewards: (state) => {
            state.accumulatedPoints += state.currentPoints;
            state.currentPoints = 0;
            state.status = 'hunt';
            state.timeLeft = null;
        },
        setRate: (state, action) => {
            state.rate = action.payload;
        },
        setDuration: (state, action) => {
            state.duration = action.payload;
        },
        restoreState: (state, action) => {
            return { ...state, ...action.payload };
        }
    }
});

export const { 
    startMining, 
    updateTimer, 
    claimRewards, 
    setRate, 
    setDuration,
    restoreState 
} = minerSlice.actions;

export default minerSlice.reducer;
