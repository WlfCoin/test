import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    userId: null,
    isAuthenticated: false,
    loading: false,
    error: null
};

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        setUser: (state, action) => {
            state.userId = action.payload;
            state.isAuthenticated = true;
        },
        logout: (state) => {
            state.userId = null;
            state.isAuthenticated = false;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        }
    }
});

export const { setUser, logout, setLoading, setError } = authSlice.actions;
export default authSlice.reducer;
