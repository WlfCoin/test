import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    miningRate: {
        current: 0.5,
        permanent: [
            { id: 1, cost: 4, rate: 0.6, type: 'points' },
            { id: 2, cost: 8, rate: 0.7, type: 'points' },
            { id: 3, cost: 16, rate: 0.8, type: 'points' },
            { id: 4, cost: 32, rate: 0.9, type: 'points' }
        ],
        temporary: [
            { id: 5, cost: 0.1, rate: 1.0, duration: 1, type: 'toncoin' },
            { id: 6, cost: 0.7, rate: 1.0, duration: 7, type: 'toncoin' },
            { id: 7, cost: 2.5, rate: 1.0, duration: 30, type: 'toncoin' }
        ]
    },
    offlineTime: {
        current: 4,
        upgrades: [
            { id: 1, cost: 8, hours: 6, type: 'points' },
            { id: 2, cost: 16, hours: 8, type: 'points' },
            { id: 3, cost: 32, hours: 10, type: 'points' },
            { id: 4, cost: 64, hours: 12, type: 'points' },
            { id: 5, cost: 0.25, hours: 18, type: 'toncoin' },
            { id: 6, cost: 0.5, hours: 24, type: 'toncoin' }
        ]
    }
};

const boostSlice = createSlice({
    name: 'boost',
    initialState,
    reducers: {
        updateMiningRate: (state, action) => {
            state.miningRate.current = action.payload;
        },
        updateOfflineTime: (state, action) => {
            state.offlineTime.current = action.payload;
        }
    }
});

export const { updateMiningRate, updateOfflineTime } = boostSlice.actions;
export default boostSlice.reducer;
