/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */
/* eslint-disable no-undef */
/* eslint-disable no-constant-condition */

'use strict';

const base64 = require('base64-js');
const ieee754 = require('ieee754');
const customInspectSymbol =
  (typeof Symbol === 'function' && typeof Symbol['for'] === 'function')
    ? Symbol['for']('nodejs.util.inspect.custom')
    : null;

// Fallback for environments not supporting BigInt or SharedArrayBuffer
if (typeof BigInt === 'undefined') {
    globalThis.BigInt = function () {
        throw new Error('BigInt is not supported in this environment.');
    };
}

if (typeof SharedArrayBuffer === 'undefined') {
    globalThis.SharedArrayBuffer = function () {
        throw new Error('SharedArrayBuffer is not supported in this environment.');
    };
}

exports.Buffer = Buffer;
exports.SlowBuffer = SlowBuffer;
exports.INSPECT_MAX_BYTES = 50;

const K_MAX_LENGTH = 0x7fffffff;
exports.kMaxLength = K_MAX_LENGTH;

// Rest of the file remains unchanged...
// Ensure no further BigInt or SharedArrayBuffer usage without checks
