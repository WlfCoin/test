import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import WolfBackground from './WolfBackground';
import Footer from './Footer';
import Bonus from '../pages/Bonus';
import Tasks from '../pages/Tasks';
import Boost from '../pages/Boost';
import Home from '../pages/Home';
import Invite from '../pages/Invite';
import { minerService } from '../services/minerService';
import { startMining, updateTimer, claimRewards, restoreState } from '../store/minerSlice';
import '../styles/App.css';
import '../styles/Common.css';

const App = () => {
  const dispatch = useDispatch();

  // State for Telegram username
  const [telegramUsername, setTelegramUsername] = useState('@defaultUser');

  // Redux state selectors
  const { status, rate, timeLeft, accumulatedPoints, currentPoints } = useSelector((state) => state.miner);

  // Fetch Telegram username
  useEffect(() => {
    const username = window.Telegram?.WebApp?.initDataUnsafe?.user?.username;
    if (username) {
      setTelegramUsername('@' + username);
    }
  }, []);

  // Initialize miner state from server
  const initializeMiner = async () => {
    try {
      const minerStatus = await minerService.getMinerStatus();
      dispatch(restoreState(minerStatus));
    } catch (error) {
      console.error('Failed to initialize miner:', error);
    }
  };

  // UseEffect for initializing miner state
  useEffect(() => {
    initializeMiner();
  }, [dispatch]);

  // UseEffect for mining timer
  useEffect(() => {
    if (status === 'mining') {
      const timer = setInterval(() => {
        dispatch(updateTimer());
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [status, dispatch]);

  const handleMiningButton = async () => {
    try {
      if (status === 'hunt') {
        await minerService.startMining();
        dispatch(startMining());
      } else if (status === 'claim') {
        await minerService.claimRewards();
        dispatch(claimRewards());
      }
    } catch (error) {
      console.error('Mining operation failed:', error);
    }
  };

  const formatTime = (seconds) => {
    if (!seconds) return '00:00:00';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return String(hours).padStart(2, '0') + ':' +
           String(minutes).padStart(2, '0') + ':' +
           String(secs).padStart(2, '0');
  };

  return (
    <div className="app">
      <div className="stats">
        <div className="stat-box">
          <div className="stat-label">Mining Rate</div>
          <div className="stat-value">{rate}/hour</div>
        </div>
        <div className="stat-box">
          <div className="stat-label">Current Earnings</div>
          <div className="stat-value">
            {status === 'mining' ?
              (accumulatedPoints + currentPoints).toFixed(2) :
              accumulatedPoints.toFixed(2)
            }
          </div>
        </div>
      </div>

      <div className="mining-circle" onClick={handleMiningButton}>
        {status === 'mining' ? (
          <div className="timer">{formatTime(timeLeft)}</div>
        ) : (
          <div className="mining-text">{status?.toUpperCase()}</div>
        )}
      </div>

      <div className="telegram-username">{telegramUsername}</div>
    </div>
  );
};

const MainApp = () => {
  return (
    <>
      <WolfBackground />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/bonus" element={<Bonus />} />
        <Route path="/tasks" element={<Tasks />} />
        <Route path="/team" element={<Invite />} />
        <Route path="/boost" element={<Boost />} />
      </Routes>
      <Footer />
    </>
  );
};

export default MainApp;
