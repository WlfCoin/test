import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import '../../styles/Profile.css';

const Profile = () => {
    const [profile, setProfile] = useState({
        username: '',
        balance: 0,
        totalEarned: 0,
        referralCount: 0,
        referralEarnings: 0,
        devices: [],
        achievements: []
    });
    const [referralLink, setReferralLink] = useState('');
    const [loading, setLoading] = useState(true);
    const [withdrawAmount, setWithdrawAmount] = useState('');
    const [showQR, setShowQR] = useState(false);

    useEffect(() => {
        fetchProfile();
        fetchReferralLink();
    }, []);

    const fetchProfile = async () => {
        try {
            const response = await api.get('/user/profile');
            setProfile(response.data.data);
        } catch (error) {
            console.error('Error fetching profile:', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchReferralLink = async () => {
        try {
            const response = await api.get('/user/referral-link');
            setReferralLink(response.data.data.link);
        } catch (error) {
            console.error('Error fetching referral link:', error);
        }
    };

    const copyReferralLink = () => {
        navigator.clipboard.writeText(referralLink);
        window.Telegram.WebApp.showPopup({
            title: 'Success',
            message: 'Referral link copied to clipboard!',
            buttons: [{type: 'ok'}]
        });
    };

    const handleWithdraw = async () => {
        if (!withdrawAmount || withdrawAmount <= 0) return;

        try {
            setLoading(true);
            const response = await api.post('/user/withdraw', {
                amount: parseFloat(withdrawAmount)
            });

            if (response.data.success) {
                window.Telegram.WebApp.showPopup({
                    title: 'Success',
                    message: 'Withdrawal request submitted successfully!',
                    buttons: [{type: 'ok'}]
                });
                fetchProfile();
                setWithdrawAmount('');
            }
        } catch (error) {
            window.Telegram.WebApp.showPopup({
                title: 'Error',
                message: error.response?.data?.message || 'Failed to process withdrawal',
                buttons: [{type: 'ok'}]
            });
        } finally {
            setLoading(false);
        }
    };

    const toggleQRCode = () => {
        setShowQR(!showQR);
    };

    if (loading) {
        return <div className="loading-spinner">Loading...</div>;
    }

    return (
        <div className="profile-page">
            <div className="profile-header">
                <div className="profile-info">
                    <h1>{profile.username}</h1>
                    <p className="user-id">ID: {profile.telegramId}</p>
                </div>
            </div>

            <div className="balance-card">
                <div className="balance-info">
                    <h2>Balance</h2>
                    <p className="balance-amount">{profile.balance.toFixed(2)} WOLF</p>
                </div>
                <div className="withdraw-section">
                    <input
                        type="number"
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        placeholder="Amount to withdraw"
                        className="withdraw-input"
                    />
                    <button 
                        className={`withdraw-button ${loading ? 'loading' : ''}`}
                        onClick={handleWithdraw}
                        disabled={loading || !withdrawAmount}
                    >
                        Withdraw
                    </button>
                </div>
            </div>

            <div className="stats-grid">
                <div className="stat-card">
                    <h3>Total Earned</h3>
                    <p>{profile.totalEarned.toFixed(2)} WOLF</p>
                </div>
                <div className="stat-card">
                    <h3>Referrals</h3>
                    <p>{profile.referralCount}</p>
                </div>
                <div className="stat-card">
                    <h3>Referral Earnings</h3>
                    <p>{profile.referralEarnings.toFixed(2)} WOLF</p>
                </div>
            </div>

            <div className="referral-section">
                <h2>Referral Program</h2>
                <p className="referral-info">
                    Earn 2 WOLF for each new user you invite!
                </p>
                <div className="referral-link-container">
                    <input 
                        type="text" 
                        value={referralLink} 
                        readOnly 
                        className="referral-link"
                    />
                    <button className="copy-button" onClick={copyReferralLink}>
                        Copy
                    </button>
                </div>
            </div>

            {profile.devices.length > 0 && (
                <div className="devices-section">
                    <h2>Active Devices</h2>
                    <div className="devices-list">
                        {profile.devices.map((device, index) => (
                            <div key={index} className="device-card">
                                <div className="device-info">
                                    <h3>Device {index + 1}</h3>
                                    <p className="device-status">
                                        Status: <span className={device.status.toLowerCase()}>
                                            {device.status}
                                        </span>
                                    </p>
                                </div>
                                <p className="mining-rate">
                                    {device.miningRate.toFixed(2)}/hour
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {profile.achievements.length > 0 && (
                <div className="achievements-section">
                    <h2>Achievements</h2>
                    <div className="achievements-grid">
                        {profile.achievements.map((achievement, index) => (
                            <div 
                                key={index} 
                                className={`achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}`}
                            >
                                <div className="achievement-icon">{achievement.icon}</div>
                                <div className="achievement-info">
                                    <h3>{achievement.name}</h3>
                                    <p>{achievement.description}</p>
                                    {achievement.progress && (
                                        <div className="progress-bar">
                                            <div 
                                                className="progress" 
                                                style={{width: `${(achievement.progress.current / achievement.progress.total) * 100}%`}}
                                            />
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {showQR && (
                <div className="qr-overlay" onClick={toggleQRCode}>
                    <div className="qr-container" onClick={e => e.stopPropagation()}>
                        <img src={profile.qrCode} alt="Wallet QR Code" />
                        <p>Scan to send WOLF tokens</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Profile;
