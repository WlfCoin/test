import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../utils/api';
import { useTimer } from '../../hooks/useTimer';
import '../../styles/Mining.css';

const Mining = () => {
    const [miningStatus, setMiningStatus] = useState({
        status: 'IDLE',
        rate: 0,
        earnings: 0,
        offlineEarnings: 0,
        username: ''
    });
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const { remainingTime, isActive, startTimer, formatTime } = useTimer();

    useEffect(() => {
        fetchMiningStatus();
        const interval = setInterval(fetchMiningStatus, 5000);
        return () => clearInterval(interval);
    }, []);

    const fetchMiningStatus = async () => {
        try {
            const response = await api.get('/miner/status');
            setMiningStatus(response.data.data);
        } catch (error) {
            console.error('Error fetching mining status:', error);
        }
    };

    const toggleMining = async () => {
        setLoading(true);
        try {
            const endpoint = miningStatus.status === 'MINING' ? '/miner/stop' : '/miner/start';
            const response = await api.post(endpoint);
            setMiningStatus(response.data.data);
        } catch (error) {
            console.error('Error toggling mining:', error);
        }
        setLoading(false);
    };

    const handleClick = async () => {
        if (remainingTime <= 0) {
            try {
                await claimRewards();
                startTimer();
            } catch (error) {
                console.error('Failed to claim rewards:', error);
            }
        }
    };

    return (
        <div className="mining-page">
            <div className="mining-header">
                <h1>Mining</h1>
                <div style={{ color: 'white', marginTop: '1rem', fontSize: '1rem' }}>
                    {miningStatus.username || 'User123'}
                </div>
                <button 
                    className={`toggle-button ${miningStatus.status === 'MINING' ? 'active' : ''} ${loading ? 'loading' : ''}`}
                    onClick={toggleMining}
                    disabled={loading}
                >
                    {miningStatus.status === 'MINING' ? 'Stop Mining' : 'Start Mining'}
                </button>
            </div>

            <div className="mining-stats">
                <div className="stat-card">
                    <h3>Mining Rate</h3>
                    <p className="stat-value">{miningStatus.rate.toFixed(2)}/hour</p>
                </div>

                <div className="stat-card">
                    <h3>Current Earnings</h3>
                    <p className="stat-value">{miningStatus.earnings.toFixed(2)}</p>
                </div>

                {miningStatus.offlineEarnings > 0 && (
                    <div className="stat-card offline-earnings">
                        <h3>Offline Earnings</h3>
                        <p className="stat-value">{miningStatus.offlineEarnings.toFixed(2)}</p>
                        <button 
                            className="collect-button"
                            onClick={() => navigate('/profile')}
                        >
                            Collect
                        </button>
                    </div>
                )}
            </div>

            <div className="boost-banner" onClick={() => navigate('/boosts')}>
                <h3>Boost Your Mining</h3>
                <p>Get up to 5x mining rate!</p>
            </div>

            <div className="mining-container">
                <div 
                    className="mining-circle" 
                    onClick={handleClick}
                    style={{ cursor: remainingTime <= 0 ? 'pointer' : 'default' }}
                >
                    <div className="timer">
                        {remainingTime > 0 ? formatTime(remainingTime) : "Claim"}
                    </div>
                </div>
                <div className="telegram-username">@{window.telegramUsername || 'username'}</div>
            </div>
        </div>
    );
};

export default Mining;
