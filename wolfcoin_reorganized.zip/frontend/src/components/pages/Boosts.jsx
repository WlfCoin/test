import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import '../../styles/Boosts.css';

const Boosts = () => {
    const [availableBoosts, setAvailableBoosts] = useState({
        miningRate: [],
        offlineDuration: []
    });
    const [activeBoosts, setActiveBoosts] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchBoosts();
    }, []);

    const fetchBoosts = async () => {
        try {
            const [availableRes, activeRes] = await Promise.all([
                api.get('/boost/available'),
                api.get('/boost/active')
            ]);
            setAvailableBoosts(availableRes.data.data);
            setActiveBoosts(activeRes.data.data);
        } catch (error) {
            console.error('Error fetching boosts:', error);
        }
    };

    const applyBoost = async (type, value, duration) => {
        setLoading(true);
        try {
            await api.post('/boost/apply', {
                type,
                value,
                duration
            });
            await fetchBoosts();
        } catch (error) {
            console.error('Error applying boost:', error);
        }
        setLoading(false);
    };

    return (
        <div className="boosts-page">
            <h1>Boosts</h1>

            <section className="active-boosts">
                <h2>Active Boosts</h2>
                <div className="boost-grid">
                    {activeBoosts.map((boost, index) => (
                        <div key={index} className="boost-card active">
                            <div className="boost-icon">
                                {boost.type === 'MINING_RATE' ? '⚡' : '⏰'}
                            </div>
                            <div className="boost-info">
                                <h3>{boost.type === 'MINING_RATE' ? 'Mining Rate' : 'Offline Duration'}</h3>
                                <p>{boost.type === 'MINING_RATE' ? `${boost.value}x` : `${boost.value}h`}</p>
                                <div className="time-remaining">
                                    {Math.ceil(boost.remainingTime / 3600)}h remaining
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            <section className="available-boosts">
                <h2>Mining Rate Boosts</h2>
                <div className="boost-grid">
                    {availableBoosts.miningRate.map((boost, index) => (
                        <div key={index} className="boost-card">
                            <div className="boost-icon">⚡</div>
                            <div className="boost-info">
                                <h3>{boost.value}x Mining Rate</h3>
                                <p>{boost.duration / 3600}h Duration</p>
                                <button
                                    className={`apply-button ${loading ? 'loading' : ''}`}
                                    onClick={() => applyBoost('MINING_RATE', boost.value, boost.duration)}
                                    disabled={loading}
                                >
                                    {boost.price} TON
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                <h2>Offline Duration Boosts</h2>
                <div className="boost-grid">
                    {availableBoosts.offlineDuration.map((boost, index) => (
                        <div key={index} className="boost-card">
                            <div className="boost-icon">⏰</div>
                            <div className="boost-info">
                                <h3>{boost.value}h Offline Mining</h3>
                                <p>{boost.duration / 3600}h Duration</p>
                                <button
                                    className={`apply-button ${loading ? 'loading' : ''}`}
                                    onClick={() => applyBoost('OFFLINE_DURATION', boost.value, boost.duration)}
                                    disabled={loading}
                                >
                                    {boost.price} TON
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};

export default Boosts;
