import React from 'react';
import '../styles/WolfBackground.css';

const WolfBackground = () => {
  return (
    <div className="wolf-container">
    </div>
  );
};

export default WolfBackground;
