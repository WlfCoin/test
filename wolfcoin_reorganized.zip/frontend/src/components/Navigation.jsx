import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../styles/Navigation.css';

const Navigation = () => {
    const location = useLocation();

    return (
        <nav className="navigation">
            <Link to="/bonus" className={`nav-button ${location.pathname === '/bonus' ? 'active' : ''}`}>
                <i className="fas fa-gift"></i>
                <span>Bonus</span>
            </Link>

            <Link to="/tasks" className={`nav-button ${location.pathname === '/tasks' ? 'active' : ''}`}>
                <i className="fas fa-clipboard-list"></i>
                <span>Tasks</span>
            </Link>

            <Link to="/" className={`nav-button ${location.pathname === '/' ? 'active' : ''}`}>
                <i className="fas fa-home"></i>
                <span>Home</span>
            </Link>

            <Link to="/boost" className={`nav-button ${location.pathname === '/boost' ? 'active' : ''}`}>
                <i className="fas fa-rocket"></i>
                <span>Boost</span>
            </Link>

            <Link to="/wallet" className={`nav-button ${location.pathname === '/wallet' ? 'active' : ''}`}>
                <i className="fas fa-wallet"></i>
                <span>Wallet</span>
            </Link>
        </nav>
    );
};

export default Navigation;
