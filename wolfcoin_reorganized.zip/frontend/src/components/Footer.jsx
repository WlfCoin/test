import React from 'react';
import { Box, IconButton, Typography } from '@mui/material';
import { 
    Groups, 
    AssignmentTurnedIn, 
    Home,
    Rocket
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import '../styles/Footer.css';

const Footer = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const isActive = (path) => {
        if (path === '/') {
            return location.pathname === '/';
        }
        return location.pathname.startsWith(path);
    };

    const menuItems = [
        { icon: <Groups />, path: '/team', label: 'TEAM' },
        { icon: <AssignmentTurnedIn />, path: '/tasks', label: 'TASKS' },
        { icon: <Home />, path: '/', label: 'HOME' },
        { icon: <Rocket />, path: '/boost', label: 'BOOST' }
    ];

    return (
        <Box className="footer">
            {menuItems.map((item, index) => {
                const active = isActive(item.path);
                return (
                    <Box
                        key={index}
                        onClick={() => navigate(item.path)}
                        className={`footer-item ${active ? 'active' : ''}`}
                    >
                        <IconButton
                            className={`footer-button ${active ? 'active' : ''}`}
                        >
                            {item.icon}
                        </IconButton>
                        <Typography 
                            className={`footer-label ${active ? 'active' : ''}`}
                        >
                            {item.label}
                        </Typography>
                    </Box>
                );
            })}
        </Box>
    );
};

export default Footer;
