import { useState, useEffect } from 'react';

const MINING_DURATION = 4 * 60 * 60; // 4 hours in seconds

export const useTimer = () => {
    const [remainingTime, setRemainingTime] = useState(MINING_DURATION);
    const [isActive, setIsActive] = useState(false);

    useEffect(() => {
        // Restore timer state from localStorage
        const storedTime = localStorage.getItem('remainingTime');
        const lastUpdate = localStorage.getItem('lastUpdate');
        
        if (storedTime && lastUpdate) {
            const elapsed = Math.floor((Date.now() - parseInt(lastUpdate)) / 1000);
            const newRemainingTime = Math.max(0, parseInt(storedTime) - elapsed);
            setRemainingTime(newRemainingTime);
            setIsActive(newRemainingTime > 0);
        }
    }, []);

    useEffect(() => {
        let interval;

        if (isActive && remainingTime > 0) {
            interval = setInterval(() => {
                setRemainingTime(prev => {
                    const newTime = prev - 1;
                    // Save to localStorage
                    localStorage.setItem('remainingTime', newTime.toString());
                    localStorage.setItem('lastUpdate', Date.now().toString());
                    
                    if (newTime <= 0) {
                        setIsActive(false);
                        clearInterval(interval);
                    }
                    return newTime;
                });
            }, 1000);
        }

        return () => clearInterval(interval);
    }, [isActive]);

    const startTimer = () => {
        setRemainingTime(MINING_DURATION);
        setIsActive(true);
        localStorage.setItem('remainingTime', MINING_DURATION.toString());
        localStorage.setItem('lastUpdate', Date.now().toString());
    };

    const formatTime = (seconds) => {
        const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return `${h}:${m}:${s}`;
    };

    return {
        remainingTime,
        isActive,
        startTimer,
        formatTime
    };
};
