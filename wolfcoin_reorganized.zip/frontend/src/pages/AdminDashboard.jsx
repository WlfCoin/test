import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
    Box,
    Grid,
    Paper,
    Typography,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Divider,
    Alert
} from '@mui/material';
import {
    Task,
    Speed,
    People,
    Settings,
    Analytics,
    CardGiftcard,
    Notifications
} from '@mui/icons-material';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
    const navigate = useNavigate();
    const { isAdmin } = useSelector((state) => state.auth);

    const menuItems = [
        {
            title: 'Tasks Management',
            icon: <Task />,
            items: [
                { name: 'Community Tasks', path: '/admin/tasks/community' },
                { name: 'Partner Tasks', path: '/admin/tasks/partner' },
                { name: 'Academy Tasks', path: '/admin/tasks/academy' },
                { name: 'Instagram Verifications', path: '/admin/tasks/instagram' }
            ]
        },
        {
            title: 'Boosters Management',
            icon: <Speed />,
            items: [
                { name: 'Active Boosters', path: '/admin/boosters/active' },
                { name: 'Create Booster', path: '/admin/boosters/create' },
                { name: 'Booster History', path: '/admin/boosters/history' }
            ]
        },
        {
            title: 'User Management',
            icon: <People />,
            items: [
                { name: 'User List', path: '/admin/users' },
                { name: 'User Statistics', path: '/admin/users/stats' },
                { name: 'Banned Users', path: '/admin/users/banned' }
            ]
        },
        {
            title: 'Special Items',
            icon: <CardGiftcard />,
            items: [
                { name: 'Create Item', path: '/admin/items/create' },
                { name: 'Item List', path: '/admin/items' },
                { name: 'Item Statistics', path: '/admin/items/stats' }
            ]
        },
        {
            title: 'Analytics',
            icon: <Analytics />,
            items: [
                { name: 'Mining Statistics', path: '/admin/analytics/mining' },
                { name: 'Task Completion', path: '/admin/analytics/tasks' },
                { name: 'User Activity', path: '/admin/analytics/activity' }
            ]
        },
        {
            title: 'Notifications',
            icon: <Notifications />,
            items: [
                { name: 'Send Notification', path: '/admin/notifications/send' },
                { name: 'Notification History', path: '/admin/notifications/history' }
            ]
        },
        {
            title: 'Settings',
            icon: <Settings />,
            items: [
                { name: 'General Settings', path: '/admin/settings' },
                { name: 'Mining Settings', path: '/admin/settings/mining' },
                { name: 'Security Settings', path: '/admin/settings/security' }
            ]
        }
    ];

    if (!isAdmin) {
        return (
            <Box className="admin-dashboard-container">
                <Alert severity="error">
                    You don't have permission to access this page.
                </Alert>
            </Box>
        );
    }

    return (
        <div className="admin-dashboard-container">
            <Box className="admin-dashboard-header">
                <Typography variant="h4" component="h1">
                    Admin Dashboard
                </Typography>
            </Box>

            <Grid container spacing={3}>
                {menuItems.map((section) => (
                    <Grid item xs={12} md={6} lg={4} key={section.title}>
                        <Paper className="admin-section-paper">
                            <Box className="admin-section-header">
                                <ListItemIcon>{section.icon}</ListItemIcon>
                                <Typography variant="h6">{section.title}</Typography>
                            </Box>
                            <Divider />
                            <List>
                                {section.items.map((item) => (
                                    <ListItem
                                        key={item.path}
                                        button
                                        onClick={() => navigate(item.path)}
                                    >
                                        <ListItemText primary={item.name} />
                                    </ListItem>
                                ))}
                            </List>
                        </Paper>
                    </Grid>
                ))}
            </Grid>
        </div>
    );
};

export default AdminDashboard;
