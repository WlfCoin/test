import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';
import {
    Box,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Alert
} from '@mui/material';
import { Check, Close } from '@mui/icons-material';
import '../styles/AdminTasks.css';

const AdminTasks = () => {
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [selectedTask, setSelectedTask] = useState(null);
    const [openDialog, setOpenDialog] = useState(false);
    const [adminNote, setAdminNote] = useState('');
    const { isAdmin } = useSelector((state) => state.auth);

    const fetchPendingTasks = async () => {
        try {
            setLoading(true);
            const response = await axios.get('/api/admin/tasks/instagram/pending');
            setTasks(response.data.tasks);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to fetch tasks');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isAdmin) {
            fetchPendingTasks();
        }
    }, [isAdmin]);

    const handleReview = (task, approved) => {
        setSelectedTask({ ...task, approved });
        setOpenDialog(true);
    };

    const handleSubmitReview = async () => {
        try {
            setLoading(true);
            await axios.post(`/api/tasks/${selectedTask._id}/review`, {
                approved: selectedTask.approved,
                note: adminNote
            });
            
            setOpenDialog(false);
            setAdminNote('');
            setSelectedTask(null);
            await fetchPendingTasks();
            
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to review task');
        } finally {
            setLoading(false);
        }
    };

    if (!isAdmin) {
        return (
            <Box className="admin-tasks-container">
                <Alert severity="error">
                    You don't have permission to access this page.
                </Alert>
            </Box>
        );
    }

    return (
        <div className="admin-tasks-container">
            <Box className="admin-tasks-header">
                <Typography variant="h4" component="h1">
                    Instagram Tasks Review
                </Typography>
                {error && (
                    <Alert severity="error" onClose={() => setError(null)}>
                        {error}
                    </Alert>
                )}
            </Box>

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>User ID</TableCell>
                            <TableCell>Instagram Username</TableCell>
                            <TableCell>Submission Date</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {tasks.map((task) => (
                            <TableRow key={task._id}>
                                <TableCell>{task.userId}</TableCell>
                                <TableCell>{task.instagramUsername}</TableCell>
                                <TableCell>
                                    {new Date(task.updatedAt).toLocaleString()}
                                </TableCell>
                                <TableCell>
                                    <Button
                                        startIcon={<Check />}
                                        variant="contained"
                                        color="success"
                                        onClick={() => handleReview(task, true)}
                                        disabled={loading}
                                        sx={{ mr: 1 }}
                                    >
                                        Approve
                                    </Button>
                                    <Button
                                        startIcon={<Close />}
                                        variant="contained"
                                        color="error"
                                        onClick={() => handleReview(task, false)}
                                        disabled={loading}
                                    >
                                        Reject
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                        {tasks.length === 0 && (
                            <TableRow>
                                <TableCell colSpan={4} align="center">
                                    No pending Instagram tasks
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>

            <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
                <DialogTitle>
                    {selectedTask?.approved ? 'Approve' : 'Reject'} Task
                </DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Admin Note"
                        type="text"
                        fullWidth
                        multiline
                        rows={3}
                        value={adminNote}
                        onChange={(e) => setAdminNote(e.target.value)}
                        placeholder={selectedTask?.approved 
                            ? "Optional: Add a note for approval"
                            : "Please provide a reason for rejection"}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
                    <Button 
                        onClick={handleSubmitReview}
                        color={selectedTask?.approved ? "success" : "error"}
                        disabled={!selectedTask?.approved && !adminNote}
                    >
                        {selectedTask?.approved ? 'Approve' : 'Reject'}
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
};

export default AdminTasks;
