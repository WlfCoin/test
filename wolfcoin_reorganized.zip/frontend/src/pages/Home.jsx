import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, Fab } from '@mui/material';
import { EmojiEvents } from '@mui/icons-material';
import Footer from '../components/Footer';
import '../styles/Home.css';

// مقادیر پایه
const BASE_MINING_RATE = 0.5; // نرخ استخراج پایه: نیم امتیاز در ساعت
const BASE_OFFLINE_TIME = 4 * 60 * 60; // زمان آفلاین پایه: 4 ساعت به ثانیه

const Home = () => {
    const [isHunting, setIsHunting] = useState(false);
    const [timeLeft, setTimeLeft] = useState(BASE_OFFLINE_TIME);
    const [miningRate, setMiningRate] = useState(BASE_MINING_RATE);
    const [pointsEarned, setPointsEarned] = useState(0);
    const [telegramUsername, setTelegramUsername] = useState('');
    const [isFirstVisit, setIsFirstVisit] = useState(false);
    const [startTime, setStartTime] = useState(null);
    const [userMinerInfo, setUserMinerInfo] = useState({
        miningRate: BASE_MINING_RATE,
        offlineTime: BASE_OFFLINE_TIME,
        currentBalance: 0,
        isCurrentlyMining: false,
        miningStartTime: null,
        activeBoosts: []
    });

    // تابع کمکی برای ذخیره وضعیت در localStorage
    const saveHuntingState = (start, hunting) => {
        if (hunting) {
            localStorage.setItem('huntingStartTime', start.toString());
            localStorage.setItem('isHunting', 'true');
        } else {
            localStorage.removeItem('huntingStartTime');
            localStorage.removeItem('isHunting');
        }
    };

    // دریافت اطلاعات ماینر کاربر
    const fetchUserMinerInfo = async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/user/miner-info`, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });
            const data = await response.json();
            if (response.ok) {
                // اگر کاربر بوست فعال نداشت، از مقادیر پایه استفاده می‌شود
                const minerInfo = {
                    miningRate: data.miningRate || BASE_MINING_RATE,
                    offlineTime: data.offlineTime || BASE_OFFLINE_TIME,
                    currentBalance: data.currentBalance || 0,
                    isCurrentlyMining: data.isCurrentlyMining || false,
                    miningStartTime: data.miningStartTime || null,
                    activeBoosts: data.activeBoosts || []
                };
                
                setUserMinerInfo(minerInfo);
                setMiningRate(minerInfo.miningRate);
                setPointsEarned(minerInfo.currentBalance);
                
                // اگر کاربر در حال ماینینگ بوده، وضعیت رو بازیابی می‌کنیم
                if (minerInfo.isCurrentlyMining && minerInfo.miningStartTime) {
                    const startTimeMs = parseInt(minerInfo.miningStartTime);
                    const remainingTime = calculateRemainingTime(startTimeMs, minerInfo.offlineTime);
                    if (remainingTime > 0) {
                        setTimeLeft(remainingTime);
                        setIsHunting(true);
                        setStartTime(startTimeMs);
                        saveHuntingState(startTimeMs, true);
                    }
                }
            }
        } catch (error) {
            console.error('Error fetching miner info:', error);
        }
    };

    // چک کردن و پردازش اولین ورود
    const checkFirstVisit = async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/user/check-first-visit`, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });
            const data = await response.json();
            
            if (response.ok && data.isFirstVisit) {
                // اعطای 10 امتیاز برای اولین ورود
                const awardResponse = await fetch(`${process.env.REACT_APP_API_URL}/user/award-first-visit`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                if (awardResponse.ok) {
                    const awardData = await awardResponse.json();
                    setPointsEarned(prev => prev + 10);
                    // بروزرسانی اطلاعات ماینر بعد از اعطای پاداش
                    fetchUserMinerInfo();
                }
            }
        } catch (error) {
            console.error('Error checking first visit:', error);
        }
    };

    // محاسبه زمان باقی‌مانده با در نظر گرفتن زمان آفلاین کاربر
    const calculateRemainingTime = (startTimeMs, offlineTime = BASE_OFFLINE_TIME) => {
        const elapsedSeconds = Math.floor((Date.now() - startTimeMs) / 1000);
        return Math.max(0, offlineTime - elapsedSeconds);
    };

    // محاسبه امتیاز کسب شده در پایان ماینینگ
    const calculateEarnedPoints = (startTimeMs, endTimeMs, rate = BASE_MINING_RATE) => {
        const totalHours = (endTimeMs - startTimeMs) / (1000 * 60 * 60);
        return totalHours * rate;
    };

    // آپدیت وضعیت ماینینگ در سرور
    const updateMiningStatus = async (isStarting, startTimeMs = null) => {
        try {
            await fetch(`${process.env.REACT_APP_API_URL}/user/update-mining-status`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    isCurrentlyMining: isStarting,
                    miningStartTime: startTimeMs
                })
            });
        } catch (error) {
            console.error('Error updating mining status:', error);
        }
    };

    // شروع استخراج
    const handleHuntClick = async () => {
        const now = Date.now();
        setStartTime(now);
        setIsHunting(true);
        saveHuntingState(now, true);
        await updateMiningStatus(true, now);
    };

    // پایان استخراج
    const endHunting = async () => {
        saveHuntingState(0, false);
        setTimeLeft(BASE_OFFLINE_TIME);
        setIsHunting(false);
        setStartTime(null);
        await updateMiningStatus(false);
        // بروزرسانی اطلاعات ماینر بعد از پایان استخراج
        await fetchUserMinerInfo();
    };

    // تایمر اصلی
    useEffect(() => {
        let timer;
        if (isHunting && timeLeft > 0 && startTime) {
            // آپدیت فوری زمان باقی‌مانده
            setTimeLeft(calculateRemainingTime(startTime, userMinerInfo.offlineTime));

            timer = setInterval(() => {
                const remainingTime = calculateRemainingTime(startTime, userMinerInfo.offlineTime);
                
                if (remainingTime <= 0) {
                    clearInterval(timer);
                    endHunting();
                } else {
                    setTimeLeft(remainingTime);
                }
            }, 1000);
        }
        return () => {
            if (timer) {
                clearInterval(timer);
            }
        };
    }, [isHunting, startTime, userMinerInfo.offlineTime]);

    const formatTime = (seconds) => {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    // در لود اولیه صفحه
    useEffect(() => {
        const initializeUserData = async () => {
            await checkFirstVisit();  // اول چک می‌کنیم آیا اولین ورود است
            await fetchUserMinerInfo();  // سپس اطلاعات ماینر را دریافت می‌کنیم
        };

        initializeUserData();
    }, []);

    return (
        <div className="home-page">
            <div className="stats-boxes">
                <div className="stat-box mining-rate">
                    <Typography variant="body2" className="stat-label">Mining Rate</Typography>
                    <Typography variant="h6" className="stat-value">{miningRate} WOLF/hr</Typography>
                </div>
                <div className="stat-box points">
                    <Typography variant="body2" className="stat-label">Points Earned</Typography>
                    <Typography variant="h6" className="stat-value">{pointsEarned} pts</Typography>
                </div>
            </div>

            <div className="hunt-container">
                <Button
                    className="hunt-button"
                    onClick={handleHuntClick}
                    disabled={isHunting}
                >
                    <span>
                        {isHunting ? formatTime(timeLeft) : 'HUNT'}
                    </span>
                </Button>
                <Typography className="telegram-username">
                    {telegramUsername}
                </Typography>
            </div>

            <Fab
                color="primary"
                aria-label="bonus"
                className="bonus-floating-button"
                onClick={() => window.location.href = '/bonus'}
            >
                <EmojiEvents />
            </Fab>
            <Footer />
        </div>
    );
};

export default Home;
