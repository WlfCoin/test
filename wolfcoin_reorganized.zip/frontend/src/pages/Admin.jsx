import React, { useState, useEffect } from 'react';
import { Box, Container, Typography, Button, TextField, Grid, Paper, Tabs, Tab, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import axios from 'axios';
import '../styles/Admin.css';

const Admin = () => {
    const [stats, setStats] = useState({
        totalUsers: 0,
        totalPoints: 0,
        activeUsers: 0
    });
    const [selectedUser, setSelectedUser] = useState('');
    const [pointsAmount, setPointsAmount] = useState('');
    const [message, setMessage] = useState('');
    const [tabValue, setTabValue] = useState(0);
    const [tasks, setTasks] = useState([]);
    const [boosters, setBoosters] = useState([]);
    const [openDialog, setOpenDialog] = useState(false);
    const [dialogType, setDialogType] = useState('');
    const [newItem, setNewItem] = useState({
        title: '',
        description: '',
        points: '',
        duration: '',
        multiplier: ''
    });

    useEffect(() => {
        fetchStats();
        fetchTasks();
        fetchBoosters();
    }, []);

    const fetchStats = async () => {
        try {
            const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/admin/stats`);
            setStats(response.data);
        } catch (error) {
            console.error('Error fetching stats:', error);
        }
    };

    const fetchTasks = async () => {
        try {
            const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/admin/tasks`);
            setTasks(response.data);
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    };

    const fetchBoosters = async () => {
        try {
            const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/admin/boosters`);
            setBoosters(response.data);
        } catch (error) {
            console.error('Error fetching boosters:', error);
        }
    };

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
    };

    const handleOpenDialog = (type) => {
        setDialogType(type);
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
        setNewItem({
            title: '',
            description: '',
            points: '',
            duration: '',
            multiplier: ''
        });
    };

    const handleAddItem = async () => {
        try {
            if (dialogType === 'task') {
                await axios.post(`${process.env.REACT_APP_API_URL}/api/admin/tasks`, newItem);
                fetchTasks();
            } else {
                await axios.post(`${process.env.REACT_APP_API_URL}/api/admin/boosters`, newItem);
                fetchBoosters();
            }
            handleCloseDialog();
            setMessage(`${dialogType === 'task' ? 'Task' : 'Booster'} added successfully!`);
        } catch (error) {
            setMessage(error.response?.data?.message || 'Error adding item');
        }
    };

    const handleDeleteItem = async (id, type) => {
        try {
            await axios.delete(`${process.env.REACT_APP_API_URL}/api/admin/${type}/${id}`);
            if (type === 'tasks') {
                fetchTasks();
            } else {
                fetchBoosters();
            }
            setMessage(`${type === 'tasks' ? 'Task' : 'Booster'} deleted successfully!`);
        } catch (error) {
            setMessage(error.response?.data?.message || 'Error deleting item');
        }
    };

    const renderDialog = () => (
        <Dialog open={openDialog} onClose={handleCloseDialog}>
            <DialogTitle>
                Add New {dialogType === 'task' ? 'Task' : 'Booster'}
            </DialogTitle>
            <DialogContent>
                <TextField
                    label="Title"
                    value={newItem.title}
                    onChange={(e) => setNewItem({...newItem, title: e.target.value})}
                    fullWidth
                    margin="normal"
                />
                <TextField
                    label="Description"
                    value={newItem.description}
                    onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                    fullWidth
                    margin="normal"
                    multiline
                    rows={3}
                />
                {dialogType === 'task' ? (
                    <TextField
                        label="Points"
                        type="number"
                        value={newItem.points}
                        onChange={(e) => setNewItem({...newItem, points: e.target.value})}
                        fullWidth
                        margin="normal"
                    />
                ) : (
                    <>
                        <TextField
                            label="Duration (hours)"
                            type="number"
                            value={newItem.duration}
                            onChange={(e) => setNewItem({...newItem, duration: e.target.value})}
                            fullWidth
                            margin="normal"
                        />
                        <TextField
                            label="Multiplier"
                            type="number"
                            value={newItem.multiplier}
                            onChange={(e) => setNewItem({...newItem, multiplier: e.target.value})}
                            fullWidth
                            margin="normal"
                        />
                    </>
                )}
            </DialogContent>
            <DialogActions>
                <Button onClick={handleCloseDialog}>Cancel</Button>
                <Button onClick={handleAddItem} color="primary">Add</Button>
            </DialogActions>
        </Dialog>
    );

    const handleSendPoints = async () => {
        try {
            await axios.post(`${process.env.REACT_APP_API_URL}/api/admin/send-points`, {
                username: selectedUser,
                points: parseInt(pointsAmount)
            });
            setMessage('Points sent successfully!');
            setSelectedUser('');
            setPointsAmount('');
            fetchStats();
        } catch (error) {
            setMessage(error.response?.data?.message || 'Error sending points');
        }
    };

    return (
        <Container className="admin-container">
            <Typography variant="h4" className="admin-title">
                Admin Panel
            </Typography>

            <Grid container spacing={3}>
                {/* Stats Cards */}
                <Grid item xs={12} md={4}>
                    <Paper className="stats-card">
                        <Typography variant="h6">Total Users</Typography>
                        <Typography variant="h4">{stats.totalUsers}</Typography>
                    </Paper>
                </Grid>
                <Grid item xs={12} md={4}>
                    <Paper className="stats-card">
                        <Typography variant="h6">Total Points</Typography>
                        <Typography variant="h4">{stats.totalPoints}</Typography>
                    </Paper>
                </Grid>
                <Grid item xs={12} md={4}>
                    <Paper className="stats-card">
                        <Typography variant="h6">Active Users</Typography>
                        <Typography variant="h4">{stats.activeUsers}</Typography>
                    </Paper>
                </Grid>

                {/* Tabs Section */}
                <Grid item xs={12}>
                    <Paper className="action-card">
                        <Tabs value={tabValue} onChange={handleTabChange} centered>
                            <Tab label="Send Points" />
                            <Tab label="Tasks" />
                            <Tab label="Boosters" />
                        </Tabs>

                        {/* Send Points Tab */}
                        {tabValue === 0 && (
                            <Box className="form-container">
                                <TextField
                                    label="Username or ID"
                                    value={selectedUser}
                                    onChange={(e) => setSelectedUser(e.target.value)}
                                    fullWidth
                                    margin="normal"
                                />
                                <TextField
                                    label="Points Amount"
                                    type="number"
                                    value={pointsAmount}
                                    onChange={(e) => setPointsAmount(e.target.value)}
                                    fullWidth
                                    margin="normal"
                                />
                                <Button
                                    variant="contained"
                                    color="primary"
                                    onClick={handleSendPoints}
                                    disabled={!selectedUser || !pointsAmount}
                                >
                                    Send Points
                                </Button>
                            </Box>
                        )}

                        {/* Tasks Tab */}
                        {tabValue === 1 && (
                            <Box className="items-container">
                                <Button
                                    variant="contained"
                                    color="primary"
                                    onClick={() => handleOpenDialog('task')}
                                    className="add-button"
                                >
                                    Add New Task
                                </Button>
                                <Grid container spacing={2}>
                                    {tasks.map((task) => (
                                        <Grid item xs={12} md={6} key={task._id}>
                                            <Paper className="item-card">
                                                <Typography variant="h6">{task.title}</Typography>
                                                <Typography>{task.description}</Typography>
                                                <Typography>Points: {task.points}</Typography>
                                                <Button
                                                    variant="outlined"
                                                    color="error"
                                                    onClick={() => handleDeleteItem(task._id, 'tasks')}
                                                >
                                                    Delete
                                                </Button>
                                            </Paper>
                                        </Grid>
                                    ))}
                                </Grid>
                            </Box>
                        )}

                        {/* Boosters Tab */}
                        {tabValue === 2 && (
                            <Box className="items-container">
                                <Button
                                    variant="contained"
                                    color="primary"
                                    onClick={() => handleOpenDialog('booster')}
                                    className="add-button"
                                >
                                    Add New Booster
                                </Button>
                                <Grid container spacing={2}>
                                    {boosters.map((booster) => (
                                        <Grid item xs={12} md={6} key={booster._id}>
                                            <Paper className="item-card">
                                                <Typography variant="h6">{booster.title}</Typography>
                                                <Typography>{booster.description}</Typography>
                                                <Typography>Duration: {booster.duration}h</Typography>
                                                <Typography>Multiplier: x{booster.multiplier}</Typography>
                                                <Button
                                                    variant="outlined"
                                                    color="error"
                                                    onClick={() => handleDeleteItem(booster._id, 'boosters')}
                                                >
                                                    Delete
                                                </Button>
                                            </Paper>
                                        </Grid>
                                    ))}
                                </Grid>
                            </Box>
                        )}

                        {message && (
                            <Typography 
                                color={message.includes('Error') ? 'error' : 'success'}
                                className="message"
                            >
                                {message}
                            </Typography>
                        )}
                    </Paper>
                </Grid>
            </Grid>

            {renderDialog()}
        </Container>
    );
};

export default Admin;
