 import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Paper,
    IconButton,
    Snackbar,
    Alert,
    CircularProgress,
    Card,
    CardContent
} from '@mui/material';
import {
    ContentCopy,
    People,
    EmojiEvents
} from '@mui/icons-material';
import '../styles/Invite.css';

// fetch invite data from API
const fetchInviteData = async (setIsLoading) => {
    try {
        setIsLoading(true);
        // Check Telegram WebApp access
        const tg = window.Telegram?.WebApp;
        let userData = {};
        
        if (tg) {
            userData = {
                userId: tg.initDataUnsafe?.user?.id,
                username: tg.initDataUnsafe?.user?.username
            };
        }

        // Get invite link and stats from server
        const response = await fetch(`${process.env.REACT_APP_API_URL}/invite/data`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...userData
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch invite data');
        }

        const data = await response.json();
        return data;
    } catch (err) {
        console.error('Error fetching invite data:', err);
        throw err;
    } finally {
        setIsLoading(false);
    }
};

const Invite = () => {
    const [inviteData, setInviteData] = useState({
        inviteLink: '',
        totalInvites: 0,
        totalPoints: 0,
        recentInvites: []
    });
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notification, setNotification] = useState({
        open: false,
        message: '',
        type: 'info'
    });

    useEffect(() => {
        const loadInviteData = async () => {
            try {
                const data = await fetchInviteData(setIsLoading);
                if (data) {
                    setInviteData(data);
                    setError(null);
                }
            } catch (err) {
                setError('Failed to load invite data. Please try again later.');
            }
        };

        loadInviteData();
        
        // Update every 1 minute only if in Telegram
        const interval = window.Telegram?.WebApp ? 
            setInterval(loadInviteData, 60 * 1000) : null;
        
        return () => interval && clearInterval(interval);
    }, []);

    // Copy invite link
    const handleCopyLink = async () => {
        try {
            await navigator.clipboard.writeText(inviteData.inviteLink);
            setNotification({
                open: true,
                message: 'Invite link copied!',
                type: 'success'
            });
        } catch (err) {
            setNotification({
                open: true,
                message: 'Failed to copy invite link',
                type: 'error'
            });
        }
    };

    const handleCloseNotification = () => {
        setNotification(prev => ({ ...prev, open: false }));
    };

    if (error) {
        return (
            <Box className="invite-error">
                <Alert severity="error">{error}</Alert>
            </Box>
        );
    }

    return (
        <div className="invite-page">
            {isLoading && (
                <Box className="invite-loading-overlay">
                    <CircularProgress />
                </Box>
            )}
            
            <Typography variant="h5" className="invite-header">
                Call the wolves, expand your pack, get a bigger share of the prey
            </Typography>

            {/* Invite Link Card */}
            <Card className="invite-card">
                <CardContent>
                    <Typography variant="h6" className="card-title">
                        Your Unique Invite Link
                    </Typography>
                    <Box className="link-box-label">
                        Click to copy your invite link:
                    </Box>
                    <Paper 
                        className="invite-link-container"
                        onClick={handleCopyLink}
                    >
                        <Typography className="invite-link">
                            {inviteData.inviteLink || 'Loading...'}
                        </Typography>
                        <IconButton className="copy-icon">
                            <ContentCopy />
                        </IconButton>
                    </Paper>
                </CardContent>
            </Card>

            {/* Stats Card */}
            <Card className="stats-card">
                <CardContent>
                    <Box className="stats-container">
                        <Box className="stat-item">
                            <People className="stat-icon" />
                            <Typography variant="h6">
                                {inviteData.totalInvites}
                            </Typography>
                            <Typography variant="body2">
                                Total Invites
                            </Typography>
                        </Box>
                        <Box className="stat-item">
                            <EmojiEvents className="stat-icon" />
                            <Typography variant="h6">
                                {inviteData.totalPoints}
                            </Typography>
                            <Typography variant="body2">
                                Points Earned
                            </Typography>
                        </Box>
                    </Box>

                    {/* Recent Invites List */}
                    {inviteData.recentInvites.length > 0 && (
                        <Box className="recent-invites">
                            <Typography variant="subtitle1" gutterBottom>
                                Recent Invites
                            </Typography>
                            {inviteData.recentInvites.map((invite, index) => (
                                <Paper key={index} className="invite-item">
                                    <Box className="invite-item-info">
                                        <Typography>
                                            {invite.username}
                                        </Typography>
                                        <Typography variant="caption" color="textSecondary">
                                            {new Date(invite.joinDate).toLocaleDateString()}
                                        </Typography>
                                    </Box>
                                    <Typography 
                                        variant="caption" 
                                        className={`status-tag ${invite.status}`}
                                    >
                                        {invite.status === 'verified' ? '+2 points' : 'pending'}
                                    </Typography>
                                </Paper>
                            ))}
                        </Box>
                    )}
                </CardContent>
            </Card>

            <Snackbar
                open={notification.open}
                autoHideDuration={3000}
                onClose={handleCloseNotification}
            >
                <Alert 
                    onClose={handleCloseNotification} 
                    severity={notification.type}
                >
                    {notification.message}
                </Alert>
            </Snackbar>
        </div>
    );
};

export default Invite;
