import React, { useState, useEffect } from 'react';
import {
    Box,
    Button,
    Grid,
    Typography,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    IconButton,
    List,
    ListItem,
    ListItemText,
    ListItemSecondaryAction,
    Divider,
    Chip
} from '@mui/material';
import {
    Add as AddIcon,
    Edit as EditIcon,
    Delete as DeleteIcon,
    CheckCircle as ActiveIcon,
    Cancel as InactiveIcon,
    NavigateNext as NextIcon,
    NavigateBefore as PrevIcon
} from '@mui/icons-material';
import axios from 'axios';
import { useSelector } from 'react-redux';
import '../styles/AdminBonusManagement.css';

const AdminBonusManagement = () => {
    const [bonuses, setBonuses] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [openDialog, setOpenDialog] = useState(false);
    const [selectedBonus, setSelectedBonus] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        amount: 0,
        type: 'DAILY',
        currency: 'POINTS',
        requirementType: 'NONE',
        requirementValue: 0,
        repeatable: false,
        cooldown: 24,
        startDate: null,
        endDate: null,
        maxClaims: null
    });
    const [currentWeek, setCurrentWeek] = useState(1);
    const { isAdmin } = useSelector((state) => state.auth);

    const fetchBonuses = async () => {
        try {
            setLoading(true);
            const response = await axios.get('/api/admin/bonuses');
            setBonuses(response.data.bonuses);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to fetch bonuses');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isAdmin) {
            fetchBonuses();
        }
    }, [isAdmin]);

    const handleOpenDialog = (bonus = null) => {
        if (bonus) {
            setSelectedBonus(bonus);
            setFormData({
                name: bonus.name,
                description: bonus.description,
                amount: bonus.amount,
                type: bonus.type,
                currency: bonus.currency,
                requirementType: bonus.requirementType,
                requirementValue: bonus.requirementValue,
                repeatable: bonus.repeatable,
                cooldown: bonus.cooldown,
                startDate: bonus.startDate,
                endDate: bonus.endDate,
                maxClaims: bonus.maxClaims
            });
        } else {
            setSelectedBonus(null);
            setFormData({
                name: '',
                description: '',
                amount: 0,
                type: 'DAILY',
                currency: 'POINTS',
                requirementType: 'NONE',
                requirementValue: 0,
                repeatable: false,
                cooldown: 24,
                startDate: null,
                endDate: null,
                maxClaims: null
            });
        }
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
        setSelectedBonus(null);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            if (selectedBonus) {
                await axios.put(`/api/admin/bonuses/${selectedBonus._id}`, formData);
            } else {
                await axios.post('/api/admin/bonuses', formData);
            }
            setOpenDialog(false);
            await fetchBonuses();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to save bonus');
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete this bonus?')) {
            return;
        }

        try {
            setLoading(true);
            await axios.delete(`/api/admin/bonuses/${id}`);
            await fetchBonuses();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to delete bonus');
        } finally {
            setLoading(false);
        }
    };

    const handleToggleStatus = async (id, currentStatus) => {
        try {
            setLoading(true);
            await axios.patch(`/api/admin/bonuses/${id}/status`, {
                active: !currentStatus
            });
            await fetchBonuses();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to update bonus status');
        } finally {
            setLoading(false);
        }
    };

    const handleNextWeek = () => {
        if (currentWeek < 5) { // مثلا 5 هفته داریم
            setCurrentWeek(prev => prev + 1);
        }
    };

    const handlePrevWeek = () => {
        if (currentWeek > 1) {
            setCurrentWeek(prev => prev - 1);
        }
    };

    if (!isAdmin) {
        return (
            <Box className="admin-bonus-management-container">
                <Typography variant="h4" component="h1">
                    Bonus Management
                </Typography>
                <Alert severity="error">
                    You don't have permission to access this page.
                </Alert>
            </Box>
        );
    }

    return (
        <Box className="admin-bonus-management-container">
            <Box className="week-navigation">
                <IconButton 
                    onClick={handlePrevWeek} 
                    disabled={currentWeek === 1}
                    className="nav-button"
                >
                    <PrevIcon />
                </IconButton>
                <Typography variant="h6" className="week-title">
                    هفته {currentWeek}
                </Typography>
                <IconButton 
                    onClick={handleNextWeek}
                    disabled={currentWeek === 5}
                    className="nav-button"
                >
                    <NextIcon />
                </IconButton>
            </Box>

            <Typography variant="h6" className="page-title">
                مدیریت بونوس‌ها
            </Typography>
            
            <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog()}
                className="add-bonus-button"
                fullWidth
            >
                افزودن بونوس جدید
            </Button>

            <List className="bonus-list">
                {bonuses.map((bonus, index) => (
                    <React.Fragment key={bonus._id}>
                        <ListItem className="bonus-item">
                            <Box className="bonus-content">
                                <Box className="bonus-header">
                                    <Typography variant="subtitle1" className="bonus-name">
                                        {bonus.name}
                                    </Typography>
                                    <Chip
                                        size="small"
                                        label={bonus.active ? 'فعال' : 'غیرفعال'}
                                        color={bonus.active ? 'success' : 'error'}
                                        className="status-chip"
                                    />
                                </Box>
                                
                                <Typography variant="body2" className="bonus-description">
                                    {bonus.description}
                                </Typography>
                                
                                <Typography variant="body2" className="bonus-amount">
                                    مقدار: {bonus.amount} سکه
                                </Typography>
                                
                                <Box className="bonus-actions">
                                    <IconButton
                                        size="small"
                                        onClick={() => handleOpenDialog(bonus)}
                                        className="action-button edit"
                                    >
                                        <EditIcon fontSize="small" />
                                    </IconButton>
                                    
                                    <IconButton
                                        size="small"
                                        onClick={() => handleToggleStatus(bonus._id, bonus.active)}
                                        className={`action-button ${bonus.active ? 'deactivate' : 'activate'}`}
                                    >
                                        {bonus.active ? <InactiveIcon fontSize="small" /> : <ActiveIcon fontSize="small" />}
                                    </IconButton>
                                    
                                    <IconButton
                                        size="small"
                                        onClick={() => handleDelete(bonus._id)}
                                        className="action-button delete"
                                    >
                                        <DeleteIcon fontSize="small" />
                                    </IconButton>
                                </Box>
                            </Box>
                        </ListItem>
                        {index < bonuses.length - 1 && <Divider />}
                    </React.Fragment>
                ))}
            </List>

            <Dialog 
                open={openDialog} 
                onClose={handleCloseDialog}
                fullWidth
                maxWidth="sm"
                className="bonus-dialog"
            >
                <DialogTitle>
                    {selectedBonus ? 'ویرایش بونوس' : 'افزودن بونوس جدید'}
                </DialogTitle>
                <DialogContent>
                    <Box className="dialog-form">
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    label="نام بونوس"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                    fullWidth
                                    required
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    label="مقدار"
                                    type="number"
                                    value={formData.amount}
                                    onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
                                    fullWidth
                                    required
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField
                                    label="توضیحات"
                                    value={formData.description}
                                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                    fullWidth
                                    multiline
                                    rows={2}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <FormControl fullWidth>
                                    <InputLabel>نوع بونوس</InputLabel>
                                    <Select
                                        value={formData.type}
                                        onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                                    >
                                        <MenuItem value="DAILY">روزانه</MenuItem>
                                        <MenuItem value="WEEKLY">هفتگی</MenuItem>
                                        <MenuItem value="MONTHLY">ماهانه</MenuItem>
                                        <MenuItem value="ONE_TIME">یک بار</MenuItem>
                                        <MenuItem value="SPECIAL">ویژه</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={6}>
                                <FormControl fullWidth>
                                    <InputLabel>واحد بونوس</InputLabel>
                                    <Select
                                        value={formData.currency}
                                        onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                                    >
                                        <MenuItem value="POINTS">امتیاز</MenuItem>
                                        <MenuItem value="COINS">سکه</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={6}>
                                <FormControl fullWidth>
                                    <InputLabel>نوع شرط</InputLabel>
                                    <Select
                                        value={formData.requirementType}
                                        onChange={(e) => setFormData({ ...formData, requirementType: e.target.value })}
                                    >
                                        <MenuItem value="NONE">هیچ</MenuItem>
                                        <MenuItem value="MINING_LEVEL">سطح معدن</MenuItem>
                                        <MenuItem value="TOTAL_POINTS">مجموع امتیاز</MenuItem>
                                        <MenuItem value="MINING_TIME">زمان معدن (ساعت)</MenuItem>
                                        <MenuItem value="TASKS_COMPLETED">وظایف انجام شده</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            {formData.requirementType !== 'NONE' && (
                                <Grid item xs={6}>
                                    <TextField
                                        label="مقدار شرط"
                                        type="number"
                                        value={formData.requirementValue}
                                        onChange={(e) => setFormData({ ...formData, requirementValue: parseFloat(e.target.value) })}
                                        fullWidth
                                        inputProps={{ min: 0 }}
                                    />
                                </Grid>
                            )}
                            <Grid item xs={12}>
                                <FormControlLabel
                                    control={
                                        <Switch
                                            checked={formData.repeatable}
                                            onChange={(e) => setFormData({ ...formData, repeatable: e.target.checked })}
                                        />
                                    }
                                    label="تکرارپذیر"
                                />
                            </Grid>
                            {formData.repeatable && (
                                <Grid item xs={6}>
                                    <TextField
                                        label="زمان تکرار (ساعت)"
                                        type="number"
                                        value={formData.cooldown}
                                        onChange={(e) => setFormData({ ...formData, cooldown: parseInt(e.target.value) })}
                                        fullWidth
                                        inputProps={{ min: 1 }}
                                    />
                                </Grid>
                            )}
                            <Grid item xs={6}>
                                <TextField
                                    label="حداکثر دفعات استفاده (اختیاری)"
                                    type="number"
                                    value={formData.maxClaims || ''}
                                    onChange={(e) => setFormData({ ...formData, maxClaims: e.target.value ? parseInt(e.target.value) : null })}
                                    fullWidth
                                    inputProps={{ min: 1 }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <DateTimePicker
                                        label="تاریخ شروع (اختیاری)"
                                        value={formData.startDate}
                                        onChange={(date) => setFormData({ ...formData, startDate: date })}
                                        renderInput={(params) => <TextField {...params} fullWidth />}
                                    />
                                </LocalizationProvider>
                            </Grid>
                            <Grid item xs={6}>
                                <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <DateTimePicker
                                        label="تاریخ پایان (اختیاری)"
                                        value={formData.endDate}
                                        onChange={(date) => setFormData({ ...formData, endDate: date })}
                                        renderInput={(params) => <TextField {...params} fullWidth />}
                                    />
                                </LocalizationProvider>
                            </Grid>
                        </Grid>
                    </Box>
                </DialogContent>
                <DialogActions className="dialog-actions">
                    <Button onClick={handleCloseDialog} color="inherit">
                        انصراف
                    </Button>
                    <Button 
                        onClick={handleSubmit} 
                        variant="contained" 
                        color="primary"
                    >
                        {selectedBonus ? 'ذخیره تغییرات' : 'ایجاد بونوس'}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default AdminBonusManagement;
