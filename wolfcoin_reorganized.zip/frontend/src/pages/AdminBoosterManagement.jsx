import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';
import {
    Box,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Alert,
    MenuItem,
    Select,
    FormControl,
    InputLabel,
    IconButton,
    Grid
} from '@mui/material';
import { Add, Edit, Delete, Check, Close } from '@mui/icons-material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import '../styles/AdminBoosterManagement.css';

const AdminBoosterManagement = () => {
    const [boosters, setBoosters] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [openDialog, setOpenDialog] = useState(false);
    const [selectedBooster, setSelectedBooster] = useState(null);
    const { isAdmin } = useSelector((state) => state.auth);

    const [formData, setFormData] = useState({
        name: '',
        description: '',
        multiplier: 1,
        duration: 24,
        price: 0,
        currency: 'POINTS',
        type: 'MINING_SPEED',
        maxPurchases: null,
        startDate: null,
        endDate: null
    });

    const fetchBoosters = async () => {
        try {
            setLoading(true);
            const response = await axios.get('/api/admin/boosters');
            setBoosters(response.data.boosters);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to fetch boosters');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isAdmin) {
            fetchBoosters();
        }
    }, [isAdmin]);

    const handleCreateBooster = () => {
        setSelectedBooster(null);
        setFormData({
            name: '',
            description: '',
            multiplier: 1,
            duration: 24,
            price: 0,
            currency: 'POINTS',
            type: 'MINING_SPEED',
            maxPurchases: null,
            startDate: null,
            endDate: null
        });
        setOpenDialog(true);
    };

    const handleEditBooster = (booster) => {
        setSelectedBooster(booster);
        setFormData({
            name: booster.name,
            description: booster.description,
            multiplier: booster.multiplier,
            duration: booster.duration,
            price: booster.price,
            currency: booster.currency,
            type: booster.type,
            maxPurchases: booster.maxPurchases,
            startDate: booster.startDate,
            endDate: booster.endDate
        });
        setOpenDialog(true);
    };

    const handleDeleteBooster = async (boosterId) => {
        if (!window.confirm('Are you sure you want to delete this booster?')) {
            return;
        }

        try {
            setLoading(true);
            await axios.delete(`/api/admin/boosters/${boosterId}`);
            await fetchBoosters();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to delete booster');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        try {
            setLoading(true);
            if (selectedBooster) {
                await axios.put(`/api/admin/boosters/${selectedBooster._id}`, formData);
            } else {
                await axios.post('/api/admin/boosters', formData);
            }
            setOpenDialog(false);
            await fetchBoosters();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to save booster');
        } finally {
            setLoading(false);
        }
    };

    const handleToggleStatus = async (boosterId, currentStatus) => {
        try {
            setLoading(true);
            await axios.patch(`/api/admin/boosters/${boosterId}/status`, {
                active: !currentStatus
            });
            await fetchBoosters();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to update booster status');
        } finally {
            setLoading(false);
        }
    };

    if (!isAdmin) {
        return (
            <Box className="admin-booster-management-container">
                <Alert severity="error">
                    You don't have permission to access this page.
                </Alert>
            </Box>
        );
    }

    return (
        <div className="admin-booster-management-container">
            <Box className="admin-booster-management-header">
                <Typography variant="h4" component="h1">
                    Boosters Management
                </Typography>
                {error && (
                    <Alert severity="error" onClose={() => setError(null)}>
                        {error}
                    </Alert>
                )}
                <Button
                    variant="contained"
                    startIcon={<Add />}
                    onClick={handleCreateBooster}
                    className="create-booster-button"
                >
                    Create New Booster
                </Button>
            </Box>

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Name</TableCell>
                            <TableCell>Type</TableCell>
                            <TableCell>Multiplier</TableCell>
                            <TableCell>Duration (h)</TableCell>
                            <TableCell>Price</TableCell>
                            <TableCell>Status</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {boosters.map((booster) => (
                            <TableRow key={booster._id}>
                                <TableCell>{booster.name}</TableCell>
                                <TableCell>{booster.type}</TableCell>
                                <TableCell>x{booster.multiplier}</TableCell>
                                <TableCell>{booster.duration}</TableCell>
                                <TableCell>{booster.price} {booster.currency}</TableCell>
                                <TableCell>
                                    <IconButton
                                        color={booster.active ? "success" : "error"}
                                        onClick={() => handleToggleStatus(booster._id, booster.active)}
                                    >
                                        {booster.active ? <Check /> : <Close />}
                                    </IconButton>
                                </TableCell>
                                <TableCell>
                                    <IconButton
                                        color="primary"
                                        onClick={() => handleEditBooster(booster)}
                                    >
                                        <Edit />
                                    </IconButton>
                                    <IconButton
                                        color="error"
                                        onClick={() => handleDeleteBooster(booster._id)}
                                    >
                                        <Delete />
                                    </IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
                <DialogTitle>
                    {selectedBooster ? 'Edit Booster' : 'Create New Booster'}
                </DialogTitle>
                <DialogContent>
                    <Box className="booster-form">
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField
                                    label="Name"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                    fullWidth
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField
                                    label="Description"
                                    value={formData.description}
                                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                    fullWidth
                                    multiline
                                    rows={3}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    label="Multiplier"
                                    type="number"
                                    value={formData.multiplier}
                                    onChange={(e) => setFormData({ ...formData, multiplier: parseFloat(e.target.value) })}
                                    fullWidth
                                    inputProps={{ min: 1, step: 0.1 }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    label="Duration (hours)"
                                    type="number"
                                    value={formData.duration}
                                    onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) })}
                                    fullWidth
                                    inputProps={{ min: 1 }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    label="Price"
                                    type="number"
                                    value={formData.price}
                                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                                    fullWidth
                                    inputProps={{ min: 0 }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <FormControl fullWidth>
                                    <InputLabel>Currency</InputLabel>
                                    <Select
                                        value={formData.currency}
                                        onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                                    >
                                        <MenuItem value="POINTS">Points</MenuItem>
                                        <MenuItem value="COINS">Coins</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={6}>
                                <FormControl fullWidth>
                                    <InputLabel>Type</InputLabel>
                                    <Select
                                        value={formData.type}
                                        onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                                    >
                                        <MenuItem value="MINING_SPEED">Mining Speed</MenuItem>
                                        <MenuItem value="MINING_POWER">Mining Power</MenuItem>
                                        <MenuItem value="POINTS_MULTIPLIER">Points Multiplier</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    label="Max Purchases (optional)"
                                    type="number"
                                    value={formData.maxPurchases || ''}
                                    onChange={(e) => setFormData({ ...formData, maxPurchases: e.target.value ? parseInt(e.target.value) : null })}
                                    fullWidth
                                    inputProps={{ min: 1 }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <DateTimePicker
                                        label="Start Date (optional)"
                                        value={formData.startDate}
                                        onChange={(date) => setFormData({ ...formData, startDate: date })}
                                        renderInput={(params) => <TextField {...params} fullWidth />}
                                    />
                                </LocalizationProvider>
                            </Grid>
                            <Grid item xs={6}>
                                <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <DateTimePicker
                                        label="End Date (optional)"
                                        value={formData.endDate}
                                        onChange={(date) => setFormData({ ...formData, endDate: date })}
                                        renderInput={(params) => <TextField {...params} fullWidth />}
                                    />
                                </LocalizationProvider>
                            </Grid>
                        </Grid>
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
                    <Button onClick={handleSubmit} variant="contained" color="primary">
                        {selectedBooster ? 'Update' : 'Create'}
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
};

export default AdminBoosterManagement;
