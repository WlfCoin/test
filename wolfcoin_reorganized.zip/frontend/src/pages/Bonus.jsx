import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/Bonus.css';

const Bonus = () => {
    const [streakDays, setStreakDays] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchBonusStatus();
    }, []);

    const fetchBonusStatus = async () => {
        try {
            setLoading(true);
            const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/bonus/status`);
            
            if (response.data.success) {
                setStreakDays(response.data.streakDays);
            } else {
                throw new Error(response.data.message || 'Failed to fetch bonus status');
            }
        } catch (error) {
            console.error('Error fetching bonus status:', error);
            setError('Failed to load bonus data. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleCollectBonus = async (day) => {
        try {
            const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/bonus/collect`, {
                day
            });

            if (response.data.success) {
                // بروزرسانی وضعیت بونوس‌ها بعد از دریافت موفق
                await fetchBonusStatus();
            } else {
                throw new Error(response.data.message || 'Failed to collect bonus');
            }
        } catch (error) {
            console.error('Error collecting bonus:', error);
            setError(error.message || 'Failed to collect bonus. Please try again.');
        }
    };

    if (loading) {
        return (
            <div className="bonus-page">
                <div className="loading">Loading...</div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="bonus-page">
                <div className="error">{error}</div>
            </div>
        );
    }

    return (
        <div className="bonus-page">
            <h1 className="streak-title">Daily Bonus</h1>
            <p className="streak-subtitle">Login daily to earn more points!</p>
            
            <div className="streak-grid">
                {streakDays.map((day) => (
                    <div
                        key={day.dayNumber}
                        className={`streak-cell ${day.status}`}
                        onClick={() => day.status === 'active' && handleCollectBonus(day.dayNumber)}
                    >
                        <div className="day-number">Day {day.dayNumber}</div>
                        <div className="points-amount">{day.points} Points</div>
                        {day.status === 'collected' && (
                            <div className="collected-icon">✓</div>
                        )}
                        {day.status === 'locked' && (
                            <div className="locked-icon">🔒</div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Bonus;
