import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import {
    Box,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Alert,
    MenuItem,
    Select,
    FormControl,
    InputLabel,
    IconButton
} from '@mui/material';
import { Add, Edit, Delete, Check, Close } from '@mui/icons-material';
import '../styles/AdminTaskManagement.css';

const AdminTaskManagement = () => {
    const { taskType } = useParams();
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [openDialog, setOpenDialog] = useState(false);
    const [selectedTask, setSelectedTask] = useState(null);
    const { isAdmin } = useSelector((state) => state.auth);

    const [formData, setFormData] = useState({
        title: '',
        description: '',
        points: 0,
        platform: 'TELEGRAM',
        type: taskType.toUpperCase(),
        link: '',
        requirements: ''
    });

    const fetchTasks = async () => {
        try {
            setLoading(true);
            const response = await axios.get(`/api/admin/tasks/${taskType}`);
            setTasks(response.data.tasks);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to fetch tasks');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isAdmin) {
            fetchTasks();
        }
    }, [isAdmin, taskType]);

    const handleCreateTask = () => {
        setSelectedTask(null);
        setFormData({
            title: '',
            description: '',
            points: 0,
            platform: 'TELEGRAM',
            type: taskType.toUpperCase(),
            link: '',
            requirements: ''
        });
        setOpenDialog(true);
    };

    const handleEditTask = (task) => {
        setSelectedTask(task);
        setFormData({
            title: task.title,
            description: task.description,
            points: task.points,
            platform: task.platform,
            type: task.type,
            link: task.link,
            requirements: task.requirements
        });
        setOpenDialog(true);
    };

    const handleDeleteTask = async (taskId) => {
        if (!window.confirm('Are you sure you want to delete this task?')) {
            return;
        }

        try {
            setLoading(true);
            await axios.delete(`/api/admin/tasks/${taskId}`);
            await fetchTasks();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to delete task');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        try {
            setLoading(true);
            if (selectedTask) {
                await axios.put(`/api/admin/tasks/${selectedTask._id}`, formData);
            } else {
                await axios.post('/api/admin/tasks', formData);
            }
            setOpenDialog(false);
            await fetchTasks();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to save task');
        } finally {
            setLoading(false);
        }
    };

    const handleToggleStatus = async (taskId, currentStatus) => {
        try {
            setLoading(true);
            await axios.patch(`/api/admin/tasks/${taskId}/status`, {
                active: !currentStatus
            });
            await fetchTasks();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to update task status');
        } finally {
            setLoading(false);
        }
    };

    if (!isAdmin) {
        return (
            <Box className="admin-task-management-container">
                <Alert severity="error">
                    You don't have permission to access this page.
                </Alert>
            </Box>
        );
    }

    return (
        <div className="admin-task-management-container">
            <Box className="admin-task-management-header">
                <Typography variant="h4" component="h1">
                    {taskType.charAt(0).toUpperCase() + taskType.slice(1)} Tasks Management
                </Typography>
                {error && (
                    <Alert severity="error" onClose={() => setError(null)}>
                        {error}
                    </Alert>
                )}
                <Button
                    variant="contained"
                    startIcon={<Add />}
                    onClick={handleCreateTask}
                    className="create-task-button"
                >
                    Create New Task
                </Button>
            </Box>

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell>Platform</TableCell>
                            <TableCell>Points</TableCell>
                            <TableCell>Status</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {tasks.map((task) => (
                            <TableRow key={task._id}>
                                <TableCell>{task.title}</TableCell>
                                <TableCell>{task.platform}</TableCell>
                                <TableCell>{task.points}</TableCell>
                                <TableCell>
                                    <IconButton
                                        color={task.active ? "success" : "error"}
                                        onClick={() => handleToggleStatus(task._id, task.active)}
                                    >
                                        {task.active ? <Check /> : <Close />}
                                    </IconButton>
                                </TableCell>
                                <TableCell>
                                    <IconButton
                                        color="primary"
                                        onClick={() => handleEditTask(task)}
                                    >
                                        <Edit />
                                    </IconButton>
                                    <IconButton
                                        color="error"
                                        onClick={() => handleDeleteTask(task._id)}
                                    >
                                        <Delete />
                                    </IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
                <DialogTitle>
                    {selectedTask ? 'Edit Task' : 'Create New Task'}
                </DialogTitle>
                <DialogContent>
                    <Box className="task-form">
                        <TextField
                            label="Title"
                            value={formData.title}
                            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                            fullWidth
                            margin="normal"
                        />
                        <TextField
                            label="Description"
                            value={formData.description}
                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                            fullWidth
                            margin="normal"
                            multiline
                            rows={3}
                        />
                        <TextField
                            label="Points"
                            type="number"
                            value={formData.points}
                            onChange={(e) => setFormData({ ...formData, points: parseInt(e.target.value) })}
                            fullWidth
                            margin="normal"
                        />
                        <FormControl fullWidth margin="normal">
                            <InputLabel>Platform</InputLabel>
                            <Select
                                value={formData.platform}
                                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                            >
                                <MenuItem value="TELEGRAM">Telegram</MenuItem>
                                <MenuItem value="TWITTER">Twitter</MenuItem>
                                <MenuItem value="YOUTUBE">YouTube</MenuItem>
                                <MenuItem value="INSTAGRAM">Instagram</MenuItem>
                            </Select>
                        </FormControl>
                        <TextField
                            label="Link"
                            value={formData.link}
                            onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                            fullWidth
                            margin="normal"
                        />
                        <TextField
                            label="Requirements"
                            value={formData.requirements}
                            onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                            fullWidth
                            margin="normal"
                            multiline
                            rows={2}
                        />
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
                    <Button onClick={handleSubmit} variant="contained" color="primary">
                        {selectedTask ? 'Update' : 'Create'}
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
};

export default AdminTaskManagement;
