import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
    Box,
    Paper,
    TextField,
    Button,
    Typography,
    Alert,
    CircularProgress
} from '@mui/material';
import { verify2FA } from '../store/authSlice';
import QRCode from 'qrcode.react';
import '../styles/Login2FA.css';

const Login2FA = () => {
    const [token, setToken] = useState('');
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);
    const [showQR, setShowQR] = useState(false);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { isAuthenticated, isAdmin, is2FAVerified, user } = useSelector(state => state.auth);

    useEffect(() => {
        if (!isAuthenticated || !isAdmin) {
            navigate('/login');
        }
        if (is2FAVerified) {
            navigate('/admin');
        }
    }, [isAuthenticated, isAdmin, is2FAVerified, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!token) {
            setError('Please enter the 2FA token');
            return;
        }

        try {
            setLoading(true);
            setError(null);
            await dispatch(verify2FA(token)).unwrap();
            navigate('/admin');
        } catch (err) {
            setError(err.message || 'Failed to verify 2FA token');
        } finally {
            setLoading(false);
        }
    };

    const setupNew2FA = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await fetch('/api/auth/2fa/setup', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await response.json();
            if (data.success) {
                setShowQR(true);
            } else {
                setError(data.error);
            }
        } catch (err) {
            setError('Failed to setup 2FA');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box className="login-2fa-container">
            <Paper elevation={3} className="login-2fa-paper">
                <Typography variant="h5" component="h1" gutterBottom>
                    Two-Factor Authentication
                </Typography>
                
                {error && (
                    <Alert severity="error" onClose={() => setError(null)}>
                        {error}
                    </Alert>
                )}

                {!user?.twoFactorEnabled ? (
                    <Box className="setup-2fa-section">
                        <Typography variant="body1" gutterBottom>
                            You need to set up 2FA to access the admin panel
                        </Typography>
                        <Button
                            variant="contained"
                            onClick={setupNew2FA}
                            disabled={loading}
                        >
                            Setup 2FA
                        </Button>
                        {showQR && (
                            <Box className="qr-section">
                                <QRCode value={user?.twoFactorSecret || ''} />
                                <Typography variant="body2">
                                    Scan this QR code with your authenticator app
                                </Typography>
                            </Box>
                        )}
                    </Box>
                ) : (
                    <form onSubmit={handleSubmit} className="login-2fa-form">
                        <TextField
                            label="2FA Token"
                            type="text"
                            value={token}
                            onChange={(e) => setToken(e.target.value)}
                            fullWidth
                            required
                            autoFocus
                            disabled={loading}
                        />
                        <Button
                            type="submit"
                            variant="contained"
                            fullWidth
                            disabled={loading}
                        >
                            {loading ? <CircularProgress size={24} /> : 'Verify'}
                        </Button>
                    </form>
                )}
            </Paper>
        </Box>
    );
};

export default Login2FA;
