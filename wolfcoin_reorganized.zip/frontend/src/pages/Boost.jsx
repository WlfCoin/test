import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { TonConnectButton, TonConnectUIProvider } from '@tonconnect/ui-react';
import { updateMiningRate, updateOfflineTime } from '../store/boostSlice';
import { showNotification } from '../utils/notification';
import '../styles/Boost.css';

const BoostSection = ({ 
    title, 
    items, 
    type, 
    onPurchase, 
    currentLevel,
    userPoints,
    isWalletConnected 
}) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const canPurchaseLevel = (level) => {
        if (level === 1) return true;
        return currentLevel >= level - 1;
    };

    const getButtonState = (item) => {
        if (!canPurchaseLevel(item.level)) {
            return {
                disabled: true,
                text: 'Unlock Previous Level First'
            };
        }

        if (item.cost.points && userPoints < item.cost.points) {
            return {
                disabled: true,
                text: 'Insufficient Points'
            };
        }

        if (item.cost.ton && !isWalletConnected) {
            return {
                disabled: true,
                text: 'Connect TON Wallet'
            };
        }

        return {
            disabled: false,
            text: 'Purchase'
        };
    };

    return (
        <div className="boost-section">
            <div 
                className="boost-header" 
                onClick={() => setIsExpanded(!isExpanded)}
            >
                <h2>{title}</h2>
                <span className={`arrow ${isExpanded ? 'expanded' : ''}`}>▼</span>
            </div>
            {isExpanded && (
                <div className="boost-items">
                    {items.map(item => {
                        const buttonState = getButtonState(item);
                        const isLocked = !canPurchaseLevel(item.level);
                        
                        return (
                            <div key={item.level} className={`boost-item ${isLocked ? 'locked' : ''}`}>
                                <div className="boost-info">
                                    <div className="boost-level">
                                        Level {item.level}
                                        {isLocked && <span className="locked-icon">🔒</span>}
                                    </div>
                                    <div className="boost-rate">
                                        {type === 'MINING_RATE' ? (
                                            <span>Rate: {item.rate}/hour</span>
                                        ) : (
                                            <span>Time: {item.hours} hours</span>
                                        )}
                                    </div>
                                    <div className="boost-cost">
                                        Cost: {item.cost.points ? `${item.cost.points} points` : `${item.cost.ton} TON`}
                                        {type === 'MINING_RATE' && item.duration && (
                                            <span className="duration">
                                                Duration: {Math.floor(item.duration / (24 * 60 * 60 * 1000))} days
                                            </span>
                                        )}
                                    </div>
                                </div>
                                <button 
                                    className={`boost-button ${buttonState.disabled ? 'disabled' : ''}`}
                                    onClick={() => !buttonState.disabled && onPurchase(item)}
                                    disabled={buttonState.disabled}
                                >
                                    {buttonState.text}
                                </button>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

const Boost = () => {
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(false);
    const [stats, setStats] = useState(null);
    const [isWalletConnected, setIsWalletConnected] = useState(false);
    const { points } = useSelector(state => state.user);
    const userId = useSelector(state => state.auth.userId);

    useEffect(() => {
        fetchBoostStats();
    }, [userId]);

    useEffect(() => {
        const checkWalletConnection = async () => {
            const tonConnect = new TonConnectUIProvider();
            setIsWalletConnected(tonConnect.wallet.connected);
        };

        checkWalletConnection();
    }, []);

    const fetchBoostStats = async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/boosts/stats/${userId}`);
            const data = await response.json();
            if (data.success) {
                setStats(data.stats);
            }
        } catch (error) {
            console.error('Error fetching boost stats:', error);
            showNotification('Error fetching boost information', 'error');
        }
    };

    const handlePurchase = async (item) => {
        setLoading(true);
        try {
            let transactionHash = null;

            if (item.cost.ton) {
                if (!isWalletConnected) {
                    showNotification('Please connect your TON wallet first', 'warning');
                    return;
                }

                try {
                    // Send transaction
                    transactionHash = await TonConnectUIProvider.send({
                        to: process.env.REACT_APP_TON_WALLET_ADDRESS,
                        value: (item.cost.ton * 1000000000).toString(), // Convert to nanotons
                    });
                } catch (error) {
                    console.error('Transaction error:', error);
                    showNotification('Transaction failed', 'error');
                    setLoading(false);
                    return;
                }
            }

            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/boosts/purchase`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    userId,
                    type: item.type,
                    level: item.level,
                    transactionHash
                })
            });

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error);
            }

            if (item.type === 'MINING_RATE') {
                dispatch(updateMiningRate(item.rate));
            } else {
                dispatch(updateOfflineTime(item.hours * 60 * 60 * 1000));
            }

            showNotification('Boost purchased successfully!', 'success');
            fetchBoostStats();
        } catch (error) {
            console.error('Error purchasing boost:', error);
            showNotification(error.message || 'Error purchasing boost', 'error');
        } finally {
            setLoading(false);
        }
    };

    const miningRateItems = [
        { level: 1, type: 'MINING_RATE', cost: { points: 4 }, rate: 0.6 },
        { level: 2, type: 'MINING_RATE', cost: { points: 8 }, rate: 0.7 },
        { level: 3, type: 'MINING_RATE', cost: { points: 16 }, rate: 0.8 },
        { level: 4, type: 'MINING_RATE', cost: { points: 32 }, rate: 0.9 },
        { level: 5, type: 'MINING_RATE', cost: { ton: 0.1 }, rate: 1.0, duration: 24 * 60 * 60 * 1000 },
        { level: 6, type: 'MINING_RATE', cost: { ton: 0.7 }, rate: 1.0, duration: 7 * 24 * 60 * 60 * 1000 },
        { level: 7, type: 'MINING_RATE', cost: { ton: 2.0 }, rate: 1.0, duration: 30 * 24 * 60 * 60 * 1000 }
    ];

    const offlineTimeItems = [
        { level: 1, type: 'OFFLINE_DURATION', cost: { points: 8 }, hours: 6 },
        { level: 2, type: 'OFFLINE_DURATION', cost: { points: 16 }, hours: 8 },
        { level: 3, type: 'OFFLINE_DURATION', cost: { points: 32 }, hours: 10 },
        { level: 4, type: 'OFFLINE_DURATION', cost: { points: 64 }, hours: 12 },
        { level: 5, type: 'OFFLINE_DURATION', cost: { ton: 0.5 }, hours: 18 },
        { level: 6, type: 'OFFLINE_DURATION', cost: { ton: 1.0 }, hours: 24 }
    ];

    return (
        <div className="boost-page">
            <div className="boost-header">
                <h1>Boost Your Mining</h1>
                <TonConnectButton />
            </div>
            <div className="announcement-box">
                <h1>Boost Your Mining Power</h1>
                <p>Unlock higher levels to increase your mining efficiency and offline earnings!</p>
                {stats && (
                    <div className="current-stats">
                        <div>Current Mining Level: {stats.currentLevels.MINING_RATE}</div>
                        <div>Current Offline Level: {stats.currentLevels.OFFLINE_DURATION}</div>
                    </div>
                )}
            </div>
            
            <BoostSection 
                title="Mining Rate Boosters" 
                items={miningRateItems} 
                type="MINING_RATE" 
                onPurchase={handlePurchase}
                currentLevel={stats?.currentLevels.MINING_RATE || 0}
                userPoints={points}
                isWalletConnected={isWalletConnected}
            />
            
            <BoostSection 
                title="Offline Time Boosters" 
                items={offlineTimeItems} 
                type="OFFLINE_DURATION" 
                onPurchase={handlePurchase}
                currentLevel={stats?.currentLevels.OFFLINE_DURATION || 0}
                userPoints={points}
                isWalletConnected={isWalletConnected}
            />

            {loading && (
                <div className="loading-overlay">
                    <div className="loading-spinner"></div>
                    <div>Processing your purchase...</div>
                </div>
            )}
        </div>
    );
};

export default Boost;
