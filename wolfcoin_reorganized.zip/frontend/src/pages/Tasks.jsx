import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { 
    Box, 
    Typography, 
    Paper, 
    List, 
    ListItem, 
    ListItemIcon, 
    ListItemText, 
    Button, 
    Alert,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    CircularProgress,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    Snackbar,
    Fab
} from '@mui/material';
import { 
    Telegram,
    YouTube,
    Instagram,
    CheckCircle,
    Schedule,
    Error,
    ArrowForward,
    ExpandMore,
    Twitter,
    Groups, 
    School, 
    Handshake,
    EmojiEvents
} from '@mui/icons-material';
import '../styles/Tasks.css';
import Footer from '../components/Footer';

// Default tasks configuration...
const DEFAULT_TASKS = {
    community: {
        social: [
            {
                _id: 'comm1',
                platform: 'TELEGRAM',
                title: 'Join Community',
                description: 'Join our Telegram community channel',
                points: 2,
                status: 'PENDING',
                link: 'https://t.me/wolfCoin_news',
                type: 'social',
                note: 'Reward will be given after bot verification'
            },
            {
                _id: 'comm2',
                platform: 'TELEGRAM',
                title: 'Join Activity',
                description: 'Join our Telegram activity channel',
                points: 2,
                status: 'PENDING',
                link: 'https://t.me/Activityofprojectusers',
                type: 'social',
                note: 'Reward will be given after bot verification'
            },
            {
                _id: 'comm3',
                platform: 'TWITTER',
                title: 'Join X (Twitter)',
                description: 'Follow us on X (Twitter)',
                points: 2,
                status: 'PENDING',
                link: 'https://x.com/wlfcoinofficial?t=x6TDbhipSMYkU4bWw_dI_g&s=09',
                type: 'social',
                note: 'Twitter account access required'
            },
            {
                _id: 'comm4',
                platform: 'YOUTUBE',
                title: 'Join YouTube',
                description: 'Subscribe to our YouTube channel',
                points: 2,
                status: 'PENDING',
                link: 'https://youtube.com/@wolfcoinofficial?si=XnwRU0MH_DY9hFFc',
                type: 'social',
                note: 'YouTube account access required'
            },
            {
                _id: 'comm5',
                platform: 'INSTAGRAM',
                title: 'Join Instagram',
                description: 'Follow us on Instagram',
                points: 2,
                status: 'PENDING',
                link: 'https://www.instagram.com/wolfcoin.official/profilecard/?igsh=MWRpa2p1ZmU4OGVzMg==7',
                type: 'social',
                note: 'Instagram username verification required'
            }
        ]
    },
    academy: {
        videos: []
    },
    partner: {
        tasks: []
    }
};

// TaskSection component remains the same...
const TaskSection = ({ tasks, onTaskClick, loading }) => {
    const [instagramUsername, setInstagramUsername] = useState('');
    const [openDialog, setOpenDialog] = useState(false);
    const [selectedTask, setSelectedTask] = useState(null);
    const [error, setError] = useState(null);

    const handleInstagramSubmit = async () => {
        if (selectedTask && instagramUsername) {
            try {
                const isValid = await checkInstagramUsername(instagramUsername);
                if (isValid) {
                    onTaskClick(selectedTask, instagramUsername);
                    setOpenDialog(false);
                    setInstagramUsername('');
                    setSelectedTask(null);
                } else {
                    setError('This Instagram username is already registered');
                }
            } catch (err) {
                setError('Failed to verify Instagram username');
            }
        }
    };

    const handleTaskClick = async (task) => {
        if (task.platform === 'INSTAGRAM') {
            setSelectedTask(task);
            setOpenDialog(true);
        } else if (task.platform === 'TWITTER') {
            window.open(task.link, '_blank');
            onTaskClick(task);
        } else if (task.platform === 'YOUTUBE') {
            window.open(task.link, '_blank');
            onTaskClick(task);
        } else {
            window.open(task.link, '_blank');
            onTaskClick(task);
        }
    };

    const getPlatformIcon = (platform) => {
        switch (platform) {
            case 'TELEGRAM':
                return <Telegram />;
            case 'TWITTER':
                return <Twitter />;
            case 'YOUTUBE':
                return <YouTube />;
            case 'INSTAGRAM':
                return <Instagram />;
            default:
                return null;
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'COMPLETED':
                return <CheckCircle color="success" />;
            case 'WAITING_APPROVAL':
                return <Schedule color="warning" />;
            case 'REJECTED':
                return <Error color="error" />;
            default:
                return <ArrowForward />;
        }
    };

    const getStatusMessage = (status) => {
        switch (status) {
            case 'PENDING':
                return 'Start Task';
            case 'CLICKED_ONCE':
                return 'Verify';
            case 'WAITING_APPROVAL':
                return 'Waiting';
            case 'COMPLETED':
                return 'Completed';
            case 'REJECTED':
                return 'Rejected';
            default:
                return '';
        }
    };

    const getButtonColor = (status) => {
        switch (status) {
            case 'COMPLETED':
                return 'success';
            case 'WAITING_APPROVAL':
                return 'warning';
            case 'REJECTED':
                return 'error';
            default:
                return 'primary';
        }
    };

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" p={3}>
                <CircularProgress />
            </Box>
        );
    }

    return (
        <>
            <List>
                {tasks?.map((task) => (
                    <Paper key={task._id} className="task-item" elevation={2}>
                        <ListItem>
                            <ListItemIcon>
                                {getPlatformIcon(task.platform)}
                            </ListItemIcon>
                            <ListItemText
                                primary={task.title}
                                secondary={
                                    <>
                                        <Typography component="span" display="block">
                                            {task.description}
                                        </Typography>
                                        <Typography component="span" display="block" color="primary">
                                            Reward: {task.points} points
                                        </Typography>
                                        {task.note && (
                                            <Typography variant="caption" color="warning.main" display="block">
                                                Note: {task.note}
                                            </Typography>
                                        )}
                                    </>
                                }
                            />
                            <Button
                                variant="contained"
                                color={getButtonColor(task.status)}
                                onClick={() => handleTaskClick(task)}
                                disabled={task.status === 'COMPLETED' || task.status === 'WAITING_APPROVAL'}
                            >
                                {getStatusMessage(task.status)}
                            </Button>
                        </ListItem>
                    </Paper>
                ))}
            </List>

            <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
                <DialogTitle>Verify Instagram Follow</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Instagram Username"
                        type="text"
                        fullWidth
                        variant="outlined"
                        value={instagramUsername}
                        onChange={(e) => setInstagramUsername(e.target.value)}
                        error={!!error}
                        helperText={error}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
                    <Button 
                        onClick={handleInstagramSubmit} 
                        variant="contained" 
                        color="primary"
                        disabled={!instagramUsername}
                    >
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

const Tasks = () => {
    const [tasks, setTasks] = useState(DEFAULT_TASKS);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [expandedSection, setExpandedSection] = useState('');
    const [notification, setNotification] = useState({ open: false, message: '', type: 'info' });

    useEffect(() => {
        const checkMembership = async () => {
            try {
                const response = await fetch(`${process.env.REACT_APP_API_URL}/check-membership`, {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                const data = await response.json();
                
                if (!response.ok) {
                    throw new Error(data.message || 'Failed to check membership');
                }

                if (!data.isMember) {
                    // Stop miner and apply penalty
                    await fetch(`${process.env.REACT_APP_API_URL}/penalize`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    });

                    setNotification({
                        open: true,
                        message: 'You have been removed from channels. 5% penalty applied and miner stopped.',
                        type: 'error'
                    });
                }
            } catch (err) {
                console.error('Membership check failed:', err);
                setNotification({
                    open: true,
                    message: 'Failed to verify channel membership. Please try again later.',
                    type: 'error'
                });
            }
        };

        // Check membership every 12 hours
        checkMembership();
        const membershipInterval = setInterval(checkMembership, 12 * 60 * 60 * 1000);

        return () => {
            clearInterval(membershipInterval);
        };
    }, []);

    const handleTaskClick = async (task, instagramUsername = '') => {
        try {
            setLoading(true);
            // First, check if the task is already completed
            if (task.status === 'COMPLETED') {
                setNotification({
                    open: true,
                    message: 'Task already completed!',
                    type: 'info'
                });
                return;
            }

            // Open link in new tab
            if (task.link) {
                window.open(task.link, '_blank');
            }

            // For tasks that need verification
            if (task.platform === 'TELEGRAM' || task.platform === 'TWITTER' || task.platform === 'YOUTUBE') {
                setNotification({
                    open: true,
                    message: 'Please complete the task in the opened tab and wait for verification.',
                    type: 'info'
                });
            }

            const response = await fetch('/api/complete-task', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    taskId: task._id, 
                    platform: task.platform,
                    instagramUsername 
                })
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'Failed to complete task');
            }
            
            if (data.success) {
                const updatedTasks = { ...tasks };
                const section = task.type === 'video' ? 'academy' : 
                              task.type === 'partner' ? 'partner' : 'community';
                
                const taskList = task.type === 'video' ? updatedTasks.academy.videos :
                               task.type === 'partner' ? updatedTasks.partner.tasks :
                               updatedTasks.community.social;

                const taskIndex = taskList.findIndex(t => t._id === task._id);
                
                if (taskIndex !== -1) {
                    taskList[taskIndex].status = task.platform === 'INSTAGRAM' ? 
                        'WAITING_APPROVAL' : 
                        data.status || 'CLICKED_ONCE';
                    setTasks(updatedTasks);
                }

                setNotification({
                    open: true,
                    message: data.message || 'Task started! Please wait for verification.',
                    type: 'success'
                });
            }
        } catch (err) {
            console.error('Error updating task:', err);
            setNotification({
                open: true,
                message: err.message || 'Failed to start task. Please try again.',
                type: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const handleCloseNotification = () => {
        setNotification({ ...notification, open: false });
    };

    if (error) {
        return (
            <Box p={3}>
                <Alert severity="error">{error}</Alert>
            </Box>
        );
    }

    return (
        <div className="tasks-page">
            <div className="announcement-box">
                Alpha wolf, complete your tasks faster, the hunt will begin soon, hurry up so that you have a bigger share
            </div>
            <Box p={2} className="tasks-container">
                {/* Community Section */}
                <Accordion 
                    expanded={expandedSection === 'community'} 
                    onChange={() => setExpandedSection(expandedSection === 'community' ? '' : 'community')}
                >
                    <AccordionSummary 
                        expandIcon={<ExpandMore className="expand-icon" />}
                        className="accordion-summary"
                    >
                        <Box display="flex" alignItems="center" gap={1}>
                            <Groups className="section-icon" />
                            <Typography variant="h6">COMMUNITY</Typography>
                        </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                        <TaskSection 
                            tasks={tasks.community.social} 
                            onTaskClick={handleTaskClick}
                            loading={loading}
                        />
                    </AccordionDetails>
                </Accordion>

                {/* Academy Section */}
                <Accordion 
                    expanded={expandedSection === 'academy'} 
                    onChange={() => setExpandedSection(expandedSection === 'academy' ? '' : 'academy')}
                >
                    <AccordionSummary 
                        expandIcon={<ExpandMore className="expand-icon" />}
                        className="accordion-summary"
                    >
                        <Box display="flex" alignItems="center" gap={1}>
                            <School className="section-icon" />
                            <Typography variant="h6">ACADEMY</Typography>
                        </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                        <TaskSection 
                            tasks={tasks.academy.videos} 
                            onTaskClick={handleTaskClick}
                            loading={loading}
                        />
                    </AccordionDetails>
                </Accordion>

                {/* Partner Section */}
                <Accordion 
                    expanded={expandedSection === 'partner'} 
                    onChange={() => setExpandedSection(expandedSection === 'partner' ? '' : 'partner')}
                >
                    <AccordionSummary 
                        expandIcon={<ExpandMore className="expand-icon" />}
                        className="accordion-summary"
                    >
                        <Box display="flex" alignItems="center" gap={1}>
                            <Handshake className="section-icon" />
                            <Typography variant="h6">PARTNER</Typography>
                        </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                        <TaskSection 
                            tasks={tasks.partner.tasks} 
                            onTaskClick={handleTaskClick}
                            loading={loading}
                        />
                    </AccordionDetails>
                </Accordion>
            </Box>

            <Footer />

            <Snackbar
                open={notification.open}
                autoHideDuration={6000}
                onClose={handleCloseNotification}
            >
                <Alert 
                    onClose={handleCloseNotification} 
                    severity={notification.type} 
                    sx={{ width: '100%' }}
                >
                    {notification.message}
                </Alert>
            </Snackbar>
        </div>
    );
};

// Utility function to check Instagram username
const checkInstagramUsername = async (username) => {
    try {
        const response = await fetch('/api/check-instagram', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username })
        });
        const data = await response.json();
        return data.isValid;
    } catch (err) {
        console.error('Error checking Instagram username:', err);
        return false;
    }
};

export default Tasks;
