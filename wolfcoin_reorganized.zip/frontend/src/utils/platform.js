// Platform detection utilities
export const isTelegramMobile = () => {
    // For development, always return true
    if (process.env.NODE_ENV === 'development') {
        return true;
    }
    
    const userAgent = window.navigator.userAgent.toLowerCase();
    return userAgent.includes('telegram') && 
           (userAgent.includes('android') || userAgent.includes('ios') || userAgent.includes('iphone'));
};

export const initPlatformCheck = () => {
    if (isTelegramMobile()) {
        document.body.classList.add('telegram-mobile');
    } else {
        document.body.classList.remove('telegram-mobile');
    }
};

export const showDesktopWarning = () => {
    if (!isTelegramMobile()) {
        const warning = document.createElement('div');
        warning.className = 'desktop-warning';
        warning.innerHTML = `
            <h2>Mobile Only</h2>
            <p>This app is only available through Telegram mobile app.</p>
            <p>Please open this link in Telegram mobile app to continue.</p>
        `;
        document.body.appendChild(warning);
        return true;
    }
    return false;
};
