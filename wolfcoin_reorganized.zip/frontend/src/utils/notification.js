// notification.js

export const showNotification = (message, type = 'info') => {
    const types = {
        success: '?',
        error: '?',
        warning: '??',
        info: '??'
    };

    const icon = types[type] || '??';
    alert(`${icon} ${message}`);
};
