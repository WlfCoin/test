import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://66.29.133.146:3001';

const api = axios.create({
    baseURL: BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Request interceptor
api.interceptors.request.use((config) => {
    // Get token from Telegram WebApp
    const webApp = window.Telegram?.WebApp;
    if (webApp) {
        config.headers.Authorization = `Bearer ${webApp.initData}`;
    }
    return config;
});

// Response interceptor
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            // Handle unauthorized access
            window.Telegram?.WebApp?.showAlert('Session expired. Please restart the app.');
        }
        return Promise.reject(error);
    }
);

export default api;
