// This file is for development purposes only and should not be included in production builds.

// Mock Telegram WebApp for development
const mockTelegramWebApp = {
    ready: () => console.log('Telegram WebApp Ready (Mock)'),
    expand: () => console.log('Telegram WebApp Expanded (Mock)'),
    showPopup: ({ title, message }) => {
        console.log('Telegram Popup:', { title, message });
        alert(`${title}\n${message}`);
    },
    showAlert: (message) => {
        console.log('Telegram Alert:', message);
        alert(message);
    },
    initData: 'mock-init-data',
    initDataUnsafe: {
        user: {
            id: 123456789,
            first_name: 'Test',
            last_name: 'User',
            username: 'testuser'
        }
    }
};

// Add mock Telegram object to window in development
if (process.env.NODE_ENV === 'development' && !window.Telegram) {
    window.Telegram = {
        WebApp: mockTelegramWebApp
    };
}

export default mockTelegramWebApp;
