import axios from 'axios';

const API_URL = '/api/miner';

export const minerService = {
    async getMinerStatus() {
        const response = await axios.get(`${API_URL}/status`);
        return response.data;
    },

    async startMining() {
        const response = await axios.post(`${API_URL}/start`);
        return response.data;
    },

    async claimRewards() {
        const response = await axios.post(`${API_URL}/claim`);
        return response.data;
    },

    async updateRate(newRate) {
        const response = await axios.post(`${API_URL}/rate`, { rate: newRate });
        return response.data;
    },

    async updateDuration(newDuration) {
        const response = await axios.post(`${API_URL}/duration`, { duration: newDuration });
        return response.data;
    }
};
