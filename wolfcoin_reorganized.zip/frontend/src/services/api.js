const API_BASE_URL = 'https://wolfcoin.net/api';

export const claimRewards = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/claim`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to claim rewards');
        }

        return await response.json();
    } catch (error) {
        console.error('Error claiming rewards:', error);
        throw error;
    }
};

export const getBoostStatus = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/bonus/get-status`);
        
        if (!response.ok) {
            throw new Error('Failed to get boost status');
        }

        return await response.json();
    } catch (error) {
        console.error('Error getting boost status:', error);
        throw error;
    }
};

export const claimBonus = async (day) => {
    try {
        const response = await fetch(`${API_BASE_URL}/bonus/claim`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ day })
        });
        
        if (!response.ok) {
            throw new Error('Failed to claim bonus');
        }

        return await response.json();
    } catch (error) {
        console.error('Error claiming bonus:', error);
        throw error;
    }
};
