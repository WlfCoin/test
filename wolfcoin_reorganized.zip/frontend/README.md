# Wolf Coin Frontend

## Prerequisites
- Node.js (v16 or higher)
- npm (v7 or higher)

## Installation

1. Clone the repository
```bash
git clone [repository-url]
cd wolfcoin/frontend
```

2. Install dependencies
```bash
npm install
```

3. Install TON Network dependencies
```bash
npm install @tonconnect/ui-react ton ton-core --save
```

## TON Network Integration Setup

### 1. TonConnect Configuration
Create `tonconnect-manifest.json` in the `public` directory:
```json
{
  "url": "[your-app-url]",
  "name": "Wolf Coin",
  "iconUrl": "[your-icon-url]",
  "termsOfUseUrl": "[terms-url]",
  "privacyPolicyUrl": "[privacy-url]"
}
```

### 2. Environment Variables
Create `.env` file in the root directory:
```env
REACT_APP_TON_WALLET_ADDRESS=[your-wallet-address]
REACT_APP_API_URL=[your-api-url]
```

### 3. TON Payment Integration
The app uses TonConnect for handling TON payments. Make sure to:
- Configure the wallet address in environment variables
- Test the connection with TON network
- Verify transaction handling

## Running the Application

Development mode:
```bash
npm start
```

Build for production:
```bash
npm run build
```

## Features
- User authentication via Telegram
- Mining system with customizable rates
- Booster system with TON payment integration
- Real-time mining status tracking
- Offline mining capabilities

## TON Payment Flow
1. User selects a booster to purchase
2. System creates a TON transaction with specified amount
3. User connects their TON wallet (TonKeeper, etc.)
4. Transaction is processed on TON network
5. System verifies the transaction
6. Booster is activated upon successful payment

## Important Notes
- Make sure all TON network dependencies are properly installed
- Test TON payments in testnet before deploying to mainnet
- Keep the wallet address secure and never expose it in the code
- Monitor transaction status and handle errors appropriately
