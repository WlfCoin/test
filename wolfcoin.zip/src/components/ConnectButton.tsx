'use client';

import { useEffect, useRef } from 'react';
import { useTonConnect } from './TonConnectProvider';
import styles from '@/styles/ConnectButton.module.css';

export default function ConnectButton() {
  const { tonConnectUI, loading } = useTonConnect();
  const buttonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!tonConnectUI || !buttonRef.current) return;

    // Set button options
    tonConnectUI.uiOptions = {
      buttonRootId: 'ton-connect-button'
    };
  }, [tonConnectUI]);

  // Return a placeholder div that will be used by TonConnect
  return (
    <div className={styles.buttonWrapper}>
      {loading && <div className={styles.loader}>Loading...</div>}
      <div ref={buttonRef} id="ton-connect-button" className={loading ? styles.hidden : ''} />
    </div>
  );
}
