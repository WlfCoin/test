'use client';

import { useCallback, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import styles from '@/styles/DailyBonus.module.css';

interface DailyBonusProps {
  onClaim?: (newBalance: number) => void;
}

export default function DailyBonus({ onClaim }: DailyBonusProps) {
  const { user, isLoggedIn } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const claimBonus = useCallback(async () => {
    if (!user?.id) return;
    
    setLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const response = await fetch('/api/user/daily-bonus', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to claim bonus');
      }

      setSuccess(true);
      onClaim?.(data.balance);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to claim bonus');
    } finally {
      setLoading(false);
    }
  }, [user?.id, onClaim]);

  if (!isLoggedIn) {
    return (
      <div className={styles.container}>
        <div className={styles.card}>
          <h2>Daily Bonus</h2>
          <p>Please log in to claim your daily bonus</p>
          <div className={styles.loginMessage}>
            Click the Connect Wallet button to log in
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <h2>Daily Bonus</h2>
        <p>Claim your daily bonus of 2 points!</p>
        
        {error && <div className={styles.error}>{error}</div>}
        {success && <div className={styles.success}>Bonus claimed successfully!</div>}
        
        <button
          onClick={claimBonus}
          disabled={loading}
          className={styles.claimButton}
        >
          {loading ? 'Claiming...' : 'Claim Bonus'}
        </button>
      </div>
    </div>
  );
}
