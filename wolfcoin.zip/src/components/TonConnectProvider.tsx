'use client';

import { TonConnectUI } from '@tonconnect/ui';
import { createContext, useContext, useEffect, useState } from 'react';

// تعریف تایپ‌های context
interface TonConnectContextType {
  tonConnectUI: TonConnectUI | null;
  connected: boolean;
  wallet: any | null;
  loading: boolean;
}

const TonConnectContext = createContext<TonConnectContextType>({
  tonConnectUI: null,
  connected: false,
  wallet: null,
  loading: true
});

export const useTonConnect = () => useContext(TonConnectContext);

export function TonConnectUIProvider({ children }: { children: React.ReactNode }) {
  const [tonConnectUI, setTonConnectUI] = useState<TonConnectUI | null>(null);
  const [connected, setConnected] = useState(false);
  const [wallet, setWallet] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      if (typeof window !== 'undefined') {
        const ui = new TonConnectUI({
          manifestUrl: 'https://wolfcoin.app/tonconnect-manifest.json',
          buttonRootId: 'ton-connect-button',
          uiPreferences: {
            theme: 'SYSTEM'
          }
        });

        setTonConnectUI(ui);

        // بررسی وضعیت اتصال فعلی
        await ui.connectionRestored;
        setLoading(false);

        // ثبت تغییرات وضعیت اتصال
        ui.onStatusChange(wallet => {
          setConnected(!!wallet);
          setWallet(wallet);
        });
      }
    };

    init();

    // Cleanup
    return () => {
      if (tonConnectUI) {
        tonConnectUI.disconnect();
      }
    };
  }, []);

  return (
    <TonConnectContext.Provider value={{ tonConnectUI, connected, wallet, loading }}>
      {children}
    </TonConnectContext.Provider>
  );
}
