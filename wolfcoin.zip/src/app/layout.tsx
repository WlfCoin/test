import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import '@/app/globals.css';
import { AuthProvider } from '@/contexts/AuthContext';
import BackButton from "@/components/BackButton";
import Footer from "@/components/Footer";

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Wolf Coin',
  description: 'Wolf Coin - The Future of Digital Currency',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <div className="min-h-screen text-white relative">
            <div className="absolute inset-0 bg-[url('/images/background.webp')] bg-cover bg-center z-0" />
            <div className="relative z-10">
              <div className="flex flex-col min-h-screen">
                <BackButton />
                <main className="flex-grow">
                  {children}
                </main>
                <Footer />
              </div>
            </div>
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
