import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

const DAILY_BONUS_AMOUNT = 2;

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json();

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const now = new Date();

    const existingBonus = await prisma.dailyBonus.findFirst({
      where: {
        userId,
        createdAt: {
          gte: new Date(now.setHours(0, 0, 0, 0)),
          lt: new Date(now.setHours(23, 59, 59, 999))
        }
      }
    });

    if (existingBonus) {
      return NextResponse.json({ error: 'Daily bonus already claimed today' }, { status: 400 });
    }

    await prisma.dailyBonus.create({
      data: {
        userId,
        bonus: DAILY_BONUS_AMOUNT,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    });

    const user = await prisma.users.update({
      where: { id: parseInt(userId) },
      data: {
        balance: {
          increment: DAILY_BONUS_AMOUNT
        },
        updated_at: new Date()
      }
    });

    return NextResponse.json({
      balance: user.balance,
      message: 'Daily bonus claimed successfully'
    });
  } catch (error) {
    console.error('Error claiming daily bonus:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
