// purchase/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyTransaction } from '@/services/ton';

export async function POST(request: Request) {
  try {
    const { userId, boosterId, transactionHash } = await request.json();

    if (!userId || !boosterId || !transactionHash) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const booster = await prisma.boosts.findUnique({
      where: { id: boosterId }
    });

    if (!booster) {
      return NextResponse.json(
        { error: 'Booster not found' },
        { status: 404 }
      );
    }

    if (booster.requiredBoosterId) {
      const hasPrerequisite = await prisma.userBooster.findFirst({
        where: {
          userId: parseInt(userId),
          boosterId: booster.requiredBoosterId,
          isActive: true
        }
      });

      if (!hasPrerequisite) {
        return NextResponse.json(
          { error: 'Prerequisite booster not activated' },
          { status: 400 }
        );
      }
    }

    const isValid = await verifyTransaction(transactionHash, booster.cost);
    if (!isValid) {
      return NextResponse.json(
        { error: 'Invalid transaction' },
        { status: 400 }
      );
    }

    await prisma.userBooster.updateMany({
      where: {
        userId: parseInt(userId),
        boosterId: booster.id,
        isActive: true
      },
      data: {
        isActive: false
      }
    });

    const expiryDate = booster.type === 'OFFLINE_HUNT'
      ? new Date(Date.now() + booster.rate * 60 * 60 * 1000)
      : null;

    const userBooster = await prisma.userBooster.create({
      data: {
        userId: parseInt(userId),
        boosterId,
        purchaseDate: new Date(),
        expiryDate,
        isActive: true
      }
    });

    await prisma.transactions.create({
      data: {
        user_id: parseInt(userId),
        amount: booster.cost,
        type: 'BOOSTER_PURCHASE',
        status: 'completed',
        created_at: new Date()
      }
    });

    return NextResponse.json({ success: true, userBooster });
  } catch (error) {
    console.error('Booster purchase error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
