// complete/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

type TaskType = 'telegram_news' | 'telegram_activity' | 'twitter_follow' | 'youtube_subscribe' | 'instagram_follow';

export async function POST(request: Request) {
  try {
    const { userId, taskId } = await request.json();

    if (!userId || !taskId) {
      return NextResponse.json({ error: 'User ID and Task ID are required' }, { status: 400 });
    }

    const user = await prisma.users.findUnique({
      where: { id: parseInt(userId) }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const existingTask = await prisma.completedTasks.findFirst({
      where: {
        userId: parseInt(userId),
        taskId: taskId
      }
    });

    if (existingTask) {
      return NextResponse.json({ error: 'Task already completed' }, { status: 400 });
    }

    const taskPoints: Record<TaskType, number> = {
      telegram_news: 5,
      telegram_activity: 5,
      twitter_follow: 2,
      youtube_subscribe: 2,
      instagram_follow: 2
    };

    await prisma.completedTasks.create({
      data: {
        userId: parseInt(userId),
        taskId,
        completedAt: new Date()
      }
    });

    await prisma.users.update({
      where: { id: parseInt(userId) },
      data: {
        balance: {
          increment: taskPoints[taskId as TaskType]
        },
        updated_at: new Date()
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error completing task:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
