// status/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const lastBonus = await prisma.dailyBonus.findFirst({
      where: { userId: parseInt(userId) },
      orderBy: { createdAt: 'desc' }
    });

    const now = new Date();
    let canClaim = true;
    let nextClaimTime = null;
    let streak = 0;

    if (lastBonus) {
      const lastClaim = new Date(lastBonus.createdAt);
      const hoursSinceLastClaim = (now.getTime() - lastClaim.getTime()) / (1000 * 60 * 60);

      if (
        hoursSinceLastClaim < 24 &&
        now.getDate() === lastClaim.getDate() &&
        now.getMonth() === lastClaim.getMonth() &&
        now.getFullYear() === lastClaim.getFullYear()
      ) {
        canClaim = false;
        nextClaimTime = new Date(lastClaim.getTime() + 24 * 60 * 60 * 1000).toISOString();
      } else if (hoursSinceLastClaim < 48) {
        streak += 1;
      } else {
        streak = 0;
      }
    }

    return NextResponse.json({
      success: true,
      canClaim,
      nextClaimTime,
      streak
    });

  } catch (error) {
    console.error('Daily bonus status error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
