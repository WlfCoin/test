// boosters/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const boosters = await prisma.boosts.findMany({
      orderBy: [
        { type: 'asc' },
        { rate: 'asc' }
      ]
    });

    return NextResponse.json({ boosters });
  } catch (error) {
    console.error('Error fetching boosters:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
