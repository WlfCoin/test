// boosters/add/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const { name, cost, rate, type, requiredBoosterId } = await request.json();

    if (!name || cost === undefined || rate === undefined || !type) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const boosterCount = await prisma.boosts.count({
      where: { type },
    });

    const prefix = type === 'HUNTING_RATE' ? 'hr' : 'oh';
    const id = `${prefix}${boosterCount + 1}`;

    const currentDate = new Date();
    const futureDate = new Date();
    futureDate.setFullYear(futureDate.getFullYear() + 1);

    const booster = await prisma.boosts.create({
      data: {
        id,
        name,
        cost,
        rate,
        type,
        requiredBoosterId,
        status: 'active',
        start_time: currentDate,
        end_time: futureDate,
      },
    });

    return NextResponse.json({ booster });
  } catch (error) {
    console.error('Error adding booster:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
