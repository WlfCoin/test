import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const referrals = await prisma.users.findMany({
      where: {
        referred_by: parseInt(userId)
      },
      select: {
        id: true,
        username: true,
        address: true,
        created_at: true
      }
    });

    return NextResponse.json({
      success: true,
      totalReferrals: referrals.length,
      referrals
    });
  } catch (error) {
    console.error('Error fetching referrals:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
