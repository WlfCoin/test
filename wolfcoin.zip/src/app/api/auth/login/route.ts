// login/route.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getOrCreateUser } from '@/lib/db';
import prisma from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const { address } = await request.json();

    if (!address) {
      return NextResponse.json(
        { error: 'Address is required' },
        { status: 400 }
      );
    }

    const user = await getOrCreateUser(address);

    await prisma.users.update({
      where: { id: user.id },
      data: { last_active: new Date() }
    });

    return NextResponse.json({
      id: user.id,
      address: user.address,
      username: user.username,
      balance: user.balance,
      referral_code: user.referral_code
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
