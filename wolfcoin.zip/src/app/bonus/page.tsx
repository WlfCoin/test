'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import styles from '@/styles/DailyBonus.module.css';

interface DailyStatus {
  currentDay: number;
  lastClaimDate: string | null;
  isAvailable: boolean;
}

const POINTS_BY_DAY = [5, 6, 7, 8, 9, 10, 11];

export default function BonusPage() {
  const { user } = useAuth();
  const [dailyStatus, setDailyStatus] = useState<DailyStatus>({
    currentDay: 0,
    lastClaimDate: null,
    isAvailable: false
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user?.id) {
      checkDailyStatus();
    }
  }, [user?.id]);

  const checkDailyStatus = async () => {
    try {
      const response = await fetch(`/api/daily-bonus/status?userId=${user.id}`);
      const data = await response.json();
      if (data.success) {
        setDailyStatus(data.status);
      }
    } catch (error) {
      console.error('Error checking daily status:', error);
    }
  };

  const claimBonus = async () => {
    if (loading || !dailyStatus.isAvailable || !user?.id) return;

    setLoading(true);
    try {
      const response = await fetch('/api/daily-bonus/claim', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id })
      });

      const data = await response.json();
      if (data.success) {
        await checkDailyStatus();
      }
    } catch (error) {
      console.error('Error claiming bonus:', error);
    }
    setLoading(false);
  };

  if (!user?.id) {
    return (
      <div className={styles.container}>
        <h1 className={styles.title}>Please login to claim your daily bonus.</h1>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>
        Announce your presence in the wolf pack every day and receive a bonus.
      </h1>

      <div className={styles.daysContainer}>
        {POINTS_BY_DAY.map((points, index) => {
          const isActive = index < dailyStatus.currentDay;
          const isCurrent = index === dailyStatus.currentDay;
          const isLocked = index > dailyStatus.currentDay;

          return (
            <div
              key={index}
              className={`${styles.dayBox} ${isActive ? styles.active : ''} 
                         ${isCurrent ? styles.current : ''} 
                         ${isLocked ? styles.locked : ''}`}
              onClick={isCurrent && dailyStatus.isAvailable ? claimBonus : undefined}
            >
              <div className={styles.dayNumber}>Day {index + 1}</div>
              <div className={styles.points}>{points} Points</div>
              {isActive && <div className={styles.checkmark}>✓</div>}
              {isCurrent && dailyStatus.isAvailable && (
                <div className={styles.claimButton}>
                  {loading ? 'Claiming...' : 'Claim Now!'}
                </div>
              )}
              {isLocked && <div className={styles.lock}>🔒</div>}
            </div>
          );
        })}
      </div>

      {!dailyStatus.isAvailable && dailyStatus.lastClaimDate && (
        <div className={styles.nextBonusInfo}>
          {dailyStatus.currentDay >= POINTS_BY_DAY.length ? (
            <p>Week completed! Start a new week tomorrow.</p>
          ) : (
            <p>Come back tomorrow to claim your next bonus!</p>
          )}
        </div>
      )}
    </div>
  );
}
