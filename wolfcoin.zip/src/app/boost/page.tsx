'use client';

import React from 'react';
import Boosters from '@/components/Boosters';
import ConnectButton from '@/components/ConnectButton';
import { TonConnectUIProvider } from '@/components/TonConnectProvider';
import styles from '@/styles/Boosters.module.css';

export default function BoostPage() {
  return (
    <TonConnectUIProvider>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Mining Boosters</h1>
          <ConnectButton />
        </div>
        <div className={styles.boosterContainer}>
          <Boosters />
        </div>
      </div>
    </TonConnectUIProvider>
  );
}
