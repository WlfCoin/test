import React from 'react';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      /**
       * This allows any custom element or tag to be used in JSX.
       * It's recommended to define custom elements explicitly for better type-safety.
       */
      [elemName: string]: Record<string, unknown>;
    }
  }
}
