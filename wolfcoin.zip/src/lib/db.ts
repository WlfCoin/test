import { Pool } from 'pg';

export const pool = new Pool({
  user: process.env.POSTGRES_USER,
  host: process.env.POSTGRES_HOST,
  database: process.env.POSTGRES_DB,
  password: process.env.POSTGRES_PASSWORD,
  port: parseInt(process.env.POSTGRES_PORT || '5432'),
});

export interface User {
  id: number;
  address: string;
  username: string | null;
  balance: number;
  mining_rate: number;
  last_mined: Date | null;
  last_bonus_claim: Date | null;
}

export async function getOrCreateUser(address: string): Promise<User> {
  const client = await pool.connect();
  try {
    const existingUser = await client.query(
      'SELECT * FROM users WHERE address = $1',
      [address]
    );

    if (existingUser.rows.length === 0) {
      const insertResult = await client.query(
        `INSERT INTO users (address, balance, updated_at) VALUES ($1, $2, CURRENT_TIMESTAMP) RETURNING id, address, username, balance, mining_rate, last_mined, last_bonus_claim`,
        [address, 10]
      );
      return insertResult.rows[0];
    } else {
      return existingUser.rows[0];
    }
  } finally {
    client.release();
  }
}

export async function updateMiningRate(userId: number, newRate: number): Promise<void> {
  await pool.query(
    'UPDATE users SET mining_rate = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
    [newRate, userId]
  );
}

export async function recordMining(userId: number, amount: number, miningRate: number): Promise<void> {
  await pool.query(
    'UPDATE users SET balance = balance + $1, last_mined = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
    [amount, userId]
  );
  await pool.query(
    'INSERT INTO mining_history (user_id, amount, mining_rate) VALUES ($1, $2, $3)',
    [userId, amount, miningRate]
  );
}

export async function claimDailyBonus(userId: number, amount: number): Promise<number> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const checkResult = await client.query(
      'SELECT claimed_at FROM daily_bonuses WHERE user_id = $1 AND DATE(claimed_at) = CURRENT_DATE',
      [userId]
    );

    if (checkResult.rows.length > 0) {
      throw new Error('Already claimed today');
    }

    await client.query(
      'INSERT INTO daily_bonuses (user_id, amount) VALUES ($1, $2)',
      [userId, amount]
    );

    const result = await client.query(
      'UPDATE users SET balance = balance + $1, last_bonus_claim = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING balance',
      [amount, userId]
    );

    await client.query('COMMIT');
    return result.rows[0].balance;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}
