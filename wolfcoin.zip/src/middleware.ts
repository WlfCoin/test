import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import jwt from 'jsonwebtoken';

export const dynamic = 'force-dynamic';

const RATE_LIMIT = 100;
const rateLimitMap = new Map<string, number>();

export function middleware(request: NextRequest) {
  const ip = request.headers.get('x-forwarded-for') || 'unknown';
  const currentTime = Date.now();

  // --- Rate Limiting ---
  if (request.nextUrl.pathname.startsWith('/api/')) {
    const lastRequestTime = rateLimitMap.get(ip) || 0;
    if (currentTime - lastRequestTime < 1000 && rateLimitMap.get(ip)! > RATE_LIMIT) {
      return new NextResponse(
        JSON.stringify({
          success: false,
          error: 'Too many requests',
        }),
        { status: 429 }
      );
    }
    rateLimitMap.set(ip, currentTime);
  }

  // --- Admin Route Protection ---
  if (request.nextUrl.pathname.startsWith('/admin') ||
      request.nextUrl.pathname.startsWith('/api/admin')) {
    const token = request.headers.get('Authorization')?.replace('Bearer ', '');
    const secret = process.env.ADMIN_SECRET;

    try {
      if (!token || !jwt.verify(token, secret!)) {
        throw new Error('Invalid token');
      }
    } catch (error) {
      return new NextResponse(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      );
    }
  }

  // --- Security Headers ---
  const response = NextResponse.next();
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-XSS-Protection', '1; mode=block');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('Permissions-Policy',
    'geolocation=(), midi=(), sync-xhr=(), microphone=(), camera=(), magnetometer=(), gyroscope=(), fullscreen=(self), payment=()'
  );

  return response;
}
