// --- ton.ts ---
import { getHttpEndpoint } from '@orbs-network/ton-access';
import { TonClient, Address } from 'ton';

const client = new TonClient({ endpoint: getHttpEndpoint() });

export async function verifyTransaction(transactionHash: string, expectedAmount: number): Promise<boolean> {
  try {
    const transaction = await client.getTransaction(transactionHash);
    return transaction.amount >= expectedAmount;
  } catch (error) {
    console.error('Error verifying transaction:', error);
    return false;
  }
}

export async function waitForTransaction(transactionHash: string): Promise<boolean> {
  try {
    const transaction = await client.waitForTransaction(transactionHash);
    return !!transaction;
  } catch (error) {
    console.error('Error waiting for transaction:', error);
    return false;
  }
}
