// --- api.ts ---
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

class Api {
  private baseUrl = process.env.NEXT_PUBLIC_API_URL || '';

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('API Error:', error);
      return {
        success: false,
        error: 'Network error',
      };
    }
  }

  async startMining(userId: number) {
    return this.request('/api/mining/start', {
      method: 'POST',
      body: JSON.stringify({ userId, updatedAt: new Date().toISOString() }),
    });
  }

  async claimMiningReward(userId: number, amount: number) {
    return this.request('/api/mining/claim', {
      method: 'POST',
      body: JSON.stringify({ userId, amount, updatedAt: new Date().toISOString() }),
    });
  }

  async claimDailyBonus(userId: number) {
    return this.request('/api/daily-bonus/claim', {
      method: 'POST',
      body: JSON.stringify({ userId, updatedAt: new Date().toISOString() }),
    });
  }

  async getDailyBonusStatus(userId: number) {
    return this.request(`/api/daily-bonus/status?userId=${userId}`);
  }
}

export const api = new Api();
