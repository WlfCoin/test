# Credits

## Third-Party Assets

### Loading Animation
- **Asset Name**: "Wolf with Animations"
- **Creator**: 3DHaupt
- **Source**: https://skfb.ly/GnQ6
- **License**: [CC Attribution-NonCommercial-ShareAlike](http://creativecommons.org/licenses/by-nc-sa/4.0/)

### License Terms
According to the CC Attribution-NonCommercial-ShareAlike 4.0 license, you must:
1. **Attribution** — Give appropriate credit to the creator (3DHaupt), provide a link to the license, and indicate if changes were made
2. **NonCommercial** — You may not use the material for commercial purposes
3. **ShareAlike** — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original
