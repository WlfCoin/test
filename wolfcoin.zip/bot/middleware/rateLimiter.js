const rateLimit = require('telegraf-ratelimit');

const rateLimiter = rateLimit({
    window: 3000,
    limit: 1,
    onLimitExceeded: (ctx) => {
        ctx.reply('⚠️ Please slow down! You are sending commands too quickly.');
    }
});

module.exports = rateLimiter;
