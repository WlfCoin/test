const { Markup } = require('telegraf');

const mainKeyboard = Markup.keyboard([
    ['⛏️ Mine', '🎯 Tasks', '🎁 Bonus'],
    ['🚀 Boost', '👤 Profile', '❓ Help']
]).resize();

const getMiningKeyboard = (status) => {
    const buttons = [];
    
    if (status === 'IDLE') {
        buttons.push(
            Markup.button.callback('⛏️ Start Mining', 'start_mining')
        );
    } else if (status === 'MINING') {
        buttons.push(
            Markup.button.callback('⏹️ Stop Mining', 'stop_mining'),
            Markup.button.callback('💰 Claim Points', 'claim_points')
        );
    }
    
    return Markup.inlineKeyboard(buttons);
};

const getTaskKeyboard = (tasks) => {
    const buttons = tasks.map(task => [
        Markup.button.callback(
            `${task.completed ? '✅' : '⭕'} ${task.title}`,
            `verify_task:${task._id}`
        )
    ]);
    
    return Markup.inlineKeyboard(buttons);
};

const getBoostKeyboard = (boosts) => {
    const buttons = boosts.map(boost => [
        Markup.button.callback(
            `${boost.name} (${boost.cost.points} points or ${boost.cost.ton} TON)`,
            `buy_boost:${boost.type}:${boost.level}`
        )
    ]);
    
    return Markup.inlineKeyboard(buttons);
};

const getBonusKeyboard = (canClaim) => {
    const buttons = [];
    
    if (canClaim) {
        buttons.push([
            Markup.button.callback('🎁 Claim Daily Bonus', 'claim_bonus')
        ]);
    }
    
    return Markup.inlineKeyboard(buttons);
};

const getProfileKeyboard = () => {
    return Markup.inlineKeyboard([
        [Markup.button.callback('📊 Statistics', 'profile_stats')],
        [Markup.button.callback('📜 History', 'profile_history')],
        [Markup.button.callback('⚙️ Settings', 'profile_settings')]
    ]);
};

const getHelpKeyboard = () => {
    return Markup.inlineKeyboard([
        [Markup.button.callback('🎮 How to Play', 'help_play')],
        [Markup.button.callback('💎 About Points', 'help_points')],
        [Markup.button.callback('🔄 About Mining', 'help_mining')],
        [Markup.button.callback('📞 Support', 'help_support')]
    ]);
};

module.exports = {
    mainKeyboard,
    getMiningKeyboard,
    getTaskKeyboard,
    getBoostKeyboard,
    getBonusKeyboard,
    getProfileKeyboard,
    getHelpKeyboard
};
