const formatPoints = (points) => {
    if (points >= 1e9) {
        return `${(points / 1e9).toFixed(2)}B`;
    }
    if (points >= 1e6) {
        return `${(points / 1e6).toFixed(2)}M`;
    }
    if (points >= 1e3) {
        return `${(points / 1e3).toFixed(2)}K`;
    }
    return points.toFixed(2);
};

const formatDuration = (ms) => {
    if (!ms) return '0s';

    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
        return `${days}d ${hours % 24}h`;
    }
    if (hours > 0) {
        return `${hours}h ${minutes % 60}m`;
    }
    if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
};

const formatMiningStatus = (user) => {
    if (!user) return '❌ Error: User not found';

    let status = '';

    // Mining status
    status += `⛏️ Status: ${user.isMining ? 'Mining' : 'Idle'}\n`;
    status += `💰 Total Points: ${formatPoints(user.totalPoints)}\n`;
    status += `⚡ Mining Rate: ${user.rate.toFixed(2)}/s\n`;

    // Active boosts
    if (user.activeBoosts && user.activeBoosts.length > 0) {
        status += '\n🚀 Active Boosts:\n';
        user.activeBoosts.forEach(boost => {
            const timeLeft = formatDuration(boost.expiresAt - Date.now());
            status += `- ${boost.name} (${timeLeft} left)\n`;
        });
    }

    return status;
};

const formatBoostInfo = (boost) => {
    if (!boost) return '❌ Error: Boost not found';

    let info = `${boost.name}\n`;
    info += `💰 Cost: ${formatPoints(boost.cost.points)} points`;
    
    if (boost.cost.ton > 0) {
        info += ` + ${boost.cost.ton} TON`;
    }
    
    info += '\n';

    if (boost.type === 'MINING_RATE') {
        info += `⚡ Rate: +${boost.rateIncrease}/s\n`;
    } else if (boost.type === 'OFFLINE_TIME') {
        info += `⏰ Offline: +${formatDuration(boost.offlineDuration)}\n`;
    }

    info += `⏳ Duration: ${formatDuration(boost.duration)}\n`;

    return info;
};

const formatTaskInfo = (task) => {
    if (!task) return '❌ Error: Task not found';

    let info = `${task.title}\n\n`;
    info += `📝 Description:\n${task.description}\n\n`;
    info += `💰 Reward: ${formatPoints(task.reward)} points\n`;

    // Add requirements based on task type
    switch (task.type) {
        case 'SOCIAL_MEDIA':
            info += `🌐 Platform: ${task.platform}\n`;
            info += `🔍 Requirements:\n`;
            task.requirements.forEach(req => {
                info += `- ${req}\n`;
            });
            break;
        case 'MANUAL':
            info += `📸 Requires screenshot verification\n`;
            break;
        case 'REFERRAL':
            info += `👥 Invite ${task.required} users\n`;
            break;
    }

    return info;
};

const formatBonusInfo = (bonus) => {
    if (!bonus) return '❌ Error: Bonus not found';

    let info = `🎁 Daily Bonus\n\n`;
    info += `🔥 Current Streak: ${bonus.streakDays} days\n`;
    
    if (bonus.nextAvailable > Date.now()) {
        const timeLeft = formatDuration(bonus.nextAvailable - Date.now());
        info += `⏳ Next bonus in: ${timeLeft}\n`;
    } else {
        info += `✨ Bonus is ready to claim!\n`;
    }

    return info;
};

module.exports = {
    formatPoints,
    formatDuration,
    formatMiningStatus,
    formatBoostInfo,
    formatTaskInfo,
    formatBonusInfo
};
