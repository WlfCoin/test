const { Scenes } = require('telegraf');
const { getBoostKeyboard } = require('../utils/keyboard');
const { formatBoostInfo } = require('../utils/formatter');
const Boost = require('../../backend/models/Boost');
const User = require('../../backend/models/User');
const { validateTransaction } = require('../../backend/services/paymentService');
const config = require('../../backend/config/telegram.config');

const boostScene = new Scenes.BaseScene('boost');

boostScene.enter(async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        await showBoosts(ctx, userId);
    } catch (error) {
        console.error('Boost scene error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

const showBoosts = async (ctx, userId) => {
    try {
        // Get available boosts
        const boosts = await Boost.find({ active: true });
        
        // Get user to check active boosts
        const user = await User.findOne({ _id: userId })
            .populate('activeBoosts');

        let message = '🚀 Available Boosts\n\n';

        // Group boosts by type
        const miningBoosts = boosts.filter(b => b.type === 'MINING_RATE');
        const offlineBoosts = boosts.filter(b => b.type === 'OFFLINE_TIME');

        if (miningBoosts.length > 0) {
            message += '⚡ Mining Rate Boosts:\n\n';
            for (const boost of miningBoosts) {
                const isActive = user.activeBoosts.some(
                    ab => ab._id.equals(boost._id)
                );
                message += formatBoostInfo(boost) + 
                    `Status: ${isActive ? '✅ Active' : '⏳ Available'}\n\n`;
            }
        }

        if (offlineBoosts.length > 0) {
            message += '⏰ Offline Time Boosts:\n\n';
            for (const boost of offlineBoosts) {
                const isActive = user.activeBoosts.some(
                    ab => ab._id.equals(boost._id)
                );
                message += formatBoostInfo(boost) + 
                    `Status: ${isActive ? '✅ Active' : '⏳ Available'}\n\n`;
            }
        }

        await ctx.reply(message, getBoostKeyboard());
    } catch (error) {
        console.error('Show boosts error:', error);
        await ctx.reply('❌ An error occurred while loading boosts.');
    }
};

// Handle boost purchase
boostScene.action(/boost_purchase:(.+)/, async (ctx) => {
    try {
        const boostId = ctx.match[1];
        const userId = ctx.state.user._id;

        const boost = await Boost.findById(boostId);
        const user = await User.findOne({ _id: userId })
            .populate('activeBoosts');

        if (!boost || !user) {
            return ctx.reply('❌ Invalid boost or user not found.');
        }

        // Check if boost is already active
        const isActive = user.activeBoosts.some(
            ab => ab._id.equals(boost._id)
        );
        if (isActive) {
            return ctx.reply('⚠️ This boost is already active!');
        }

        // Show purchase options
        let message = '💰 Purchase Options:\n\n';
        message += `${boost.name}\n\n`;

        if (boost.cost.points > 0) {
            message += `1️⃣ Points: ${boost.cost.points}\n`;
        }
        if (boost.cost.ton > 0) {
            message += `2️⃣ TON: ${boost.cost.ton}\n`;
        }

        await ctx.reply(message, {
            reply_markup: {
                inline_keyboard: [
                    [
                        {
                            text: '💎 Buy with Points',
                            callback_data: `boost_points:${boost._id}`
                        }
                    ],
                    [
                        {
                            text: '💰 Buy with TON',
                            callback_data: `boost_ton:${boost._id}`
                        }
                    ],
                    [
                        {
                            text: '« Back',
                            callback_data: 'boost_back'
                        }
                    ]
                ]
            }
        });
    } catch (error) {
        console.error('Boost purchase error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

// Handle points payment
boostScene.action(/boost_points:(.+)/, async (ctx) => {
    try {
        const boostId = ctx.match[1];
        const userId = ctx.state.user._id;

        // Find boost and user
        const boost = await Boost.findById(boostId);
        const user = await User.findOne({ _id: userId });

        if (!boost || !user) {
            return ctx.reply('❌ Invalid boost or user not found.');
        }

        // Check if user has enough points
        if (user.totalPoints < boost.cost.points) {
            return ctx.reply(
                '❌ Not enough points!\n' +
                `Required: ${boost.cost.points}\n` +
                `Available: ${user.totalPoints}`
            );
        }

        // Deduct points and activate boost
        user.totalPoints -= boost.cost.points;
        await activateBoost(boost, user);

        await ctx.reply(
            '✅ Boost activated successfully!\n\n' +
            `${boost.name} is now active.\n` +
            `Remaining points: ${user.totalPoints}`
        );
    } catch (error) {
        console.error('Points payment error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

// Handle TON payment
boostScene.action(/boost_ton:(.+)/, async (ctx) => {
    try {
        const boostId = ctx.match[1];
        const userId = ctx.state.user._id;

        const boost = await Boost.findById(boostId);
        if (!boost) {
            return ctx.reply('❌ Boost not found.');
        }

        // Show payment details
        const message = 
            '💎 TON Payment Details\n\n' +
            `Amount: ${boost.cost.ton} TON\n` +
            `Address: ${config.walletAddress}\n\n` +
            '1️⃣ Send the exact amount to the address above\n' +
            '2️⃣ After sending, click "Check Payment" button\n' +
            '3️⃣ Your boost will be activated after payment confirmation\n\n' +
            '⚠️ Important: Send EXACTLY the specified amount';

        await ctx.reply(message, {
            reply_markup: {
                inline_keyboard: [
                    [
                        {
                            text: '✅ Check Payment',
                            callback_data: `check_ton:${boostId}`
                        }
                    ],
                    [
                        {
                            text: '« Back',
                            callback_data: 'boost_back'
                        }
                    ]
                ]
            }
        });

        // Store payment info in user's session
        ctx.session.pendingPayment = {
            boostId,
            amount: boost.cost.ton,
            timestamp: Date.now()
        };

    } catch (error) {
        console.error('TON payment error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

// Handle TON payment verification
boostScene.action(/check_ton:(.+)/, async (ctx) => {
    try {
        const boostId = ctx.match[1];
        const userId = ctx.state.user._id;
        const pendingPayment = ctx.session.pendingPayment;

        if (!pendingPayment || pendingPayment.boostId !== boostId) {
            return ctx.reply('❌ No pending payment found.');
        }

        // Get recent transactions
        const transactions = await validateTransaction(config.walletAddress, pendingPayment.amount);
        
        if (transactions) {
            // Payment confirmed
            const boost = await Boost.findById(boostId);
            const user = await User.findById(userId);

            if (!boost || !user) {
                return ctx.reply('❌ Error activating boost.');
            }

            await activateBoost(boost, user);
            delete ctx.session.pendingPayment;

            await ctx.reply(
                '✅ Payment confirmed!\n' +
                'Your boost has been activated successfully.'
            );
        } else {
            await ctx.reply(
                '⏳ Payment not found yet.\n' +
                'Please make sure you:\n' +
                '1️⃣ Sent the exact amount\n' +
                '2️⃣ Sent to the correct address\n' +
                '3️⃣ Wait a few minutes for the transaction to be confirmed\n\n' +
                'Click "Check Payment" again after a few minutes.',
                {
                    reply_markup: {
                        inline_keyboard: [
                            [
                                {
                                    text: '🔄 Check Again',
                                    callback_data: `check_ton:${boostId}`
                                }
                            ],
                            [
                                {
                                    text: '« Back',
                                    callback_data: 'boost_back'
                                }
                            ]
                        ]
                    }
                }
            );
        }
    } catch (error) {
        console.error('Payment check error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

// Handle back button
boostScene.action('boost_back', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        await showBoosts(ctx, userId);
    } catch (error) {
        console.error('Boost back error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

const activateBoost = async (boost, user) => {
    // Set boost expiry time
    const now = new Date();
    boost.expiresAt = new Date(
        now.getTime() + boost.duration
    );

    // Add boost to user's active boosts
    user.activeBoosts.push(boost);

    // Update mining rate if it's a rate boost
    if (boost.type === 'MINING_RATE') {
        user.rate += boost.rateIncrease;
    }
    // Update offline duration if it's an offline boost
    else if (boost.type === 'OFFLINE_TIME') {
        user.offlineDuration += boost.offlineDuration;
    }

    await user.save();
};

module.exports = { boostScene };
