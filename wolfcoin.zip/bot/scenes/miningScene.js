const { Scenes } = require('telegraf');
const { getMiningKeyboard } = require('../utils/keyboard');
const { formatMiningStatus } = require('../utils/formatter');
const User = require('../../backend/models/User');

const miningScene = new Scenes.BaseScene('mining');

miningScene.enter(async (ctx) => {
    try {
        const action = ctx.scene.state.action;
        const userId = ctx.state.user._id;

        // Get user's mining status
        const user = await User.findOne({ _id: userId })
            .populate('activeBoosts');

        if (!user) {
            return ctx.reply('❌ User not found.');
        }

        let message = '';
        if (action === 'start') {
            if (user.isMining) {
                message = '⚠️ Mining is already in progress!\n\n';
            } else {
                user.isMining = true;
                user.lastMiningStart = new Date();
                await user.save();
                message = '✅ Mining started!\n\n';
            }
        } else if (action === 'stop') {
            if (!user.isMining) {
                message = '⚠️ Mining is not in progress!\n\n';
            } else {
                // Calculate earned points
                const earnedPoints = calculateEarnedPoints(user);
                user.totalPoints += earnedPoints;
                user.isMining = false;
                await user.save();

                message = `✅ Mining stopped!\n` +
                    `💰 You earned ${earnedPoints} points!\n\n`;
            }
        }

        // Add mining status to message
        message += formatMiningStatus(user);

        await ctx.reply(message, getMiningKeyboard());
    } catch (error) {
        console.error('Mining scene error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

miningScene.action('refresh', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const user = await User.findOne({ _id: userId })
            .populate('activeBoosts');

        if (!user) {
            return ctx.reply('❌ User not found.');
        }

        // Check for expired boosts
        await handleBoostExpiry(user);

        // Calculate current points if mining
        let message = '';
        if (user.isMining) {
            const earnedPoints = calculateEarnedPoints(user);
            message = `💰 Current session: ${earnedPoints} points\n\n`;
        }

        // Add mining status
        message += formatMiningStatus(user);

        await ctx.editMessageText(message, getMiningKeyboard());
    } catch (error) {
        console.error('Mining refresh error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

const calculateEarnedPoints = (user) => {
    if (!user.isMining || !user.lastMiningStart) {
        return 0;
    }

    const now = new Date();
    const miningDuration = (now - user.lastMiningStart) / 1000; // in seconds
    return Math.floor(miningDuration * user.rate);
};

// Handle mining rate boost expiry
const handleBoostExpiry = async (user) => {
    const now = new Date();
    const expiredBoosts = user.activeBoosts.filter(boost => 
        boost.expiresAt <= now
    );

    if (expiredBoosts.length > 0) {
        for (const boost of expiredBoosts) {
            // Remove boost effects
            if (boost.type === 'MINING_RATE') {
                user.rate -= boost.rateIncrease;
            } else if (boost.type === 'OFFLINE_TIME') {
                user.offlineDuration -= boost.offlineDuration;
            }

            // Remove from active boosts
            user.activeBoosts = user.activeBoosts.filter(
                ab => !ab._id.equals(boost._id)
            );
        }

        await user.save();
    }
};

module.exports = { miningScene };
