const { Scenes } = require('telegraf');
const { getTaskKeyboard } = require('../utils/keyboard');
const { formatTaskInfo } = require('../utils/formatter');
const Task = require('../../backend/models/Task');
const User = require('../../backend/models/User');
const { verifySocialMedia } = require('../../backend/utils/socialMediaUtils');

const taskScene = new Scenes.BaseScene('task');

taskScene.enter(async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        await showTasks(ctx, userId);
    } catch (error) {
        console.error('Task scene error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

const showTasks = async (ctx, userId) => {
    try {
        // Get user's tasks
        const tasks = await Task.find({ active: true });
        const user = await User.findOne({ _id: userId });

        if (!user) {
            return ctx.reply('❌ User not found.');
        }

        let message = '🎯 Available Tasks\n\n';

        for (const task of tasks) {
            const isCompleted = await task.isCompletedByUser(userId);
            const emoji = getTypeEmoji(task.type);
            
            message += `${emoji} ${task.title}\n`;
            message += `💰 Reward: ${task.reward} points\n`;
            message += `📝 ${task.description}\n`;
            message += `Status: ${isCompleted ? '✅ Completed' : '⏳ Available'}\n\n`;
        }

        await ctx.reply(message, getTaskKeyboard());
    } catch (error) {
        console.error('Show tasks error:', error);
        await ctx.reply('❌ An error occurred while loading tasks.');
    }
};

taskScene.action(/verify_task:(.+)/, async (ctx) => {
    try {
        const taskId = ctx.match[1];
        const userId = ctx.state.user._id;
        await handleTaskVerification(ctx, taskId, userId);
    } catch (error) {
        console.error('Task verification error:', error);
        await ctx.reply('❌ An error occurred during verification.');
    }
});

const handleTaskVerification = async (ctx, taskId, userId) => {
    try {
        const task = await Task.findById(taskId);
        const user = await User.findOne({ _id: userId });

        if (!task || !user) {
            return ctx.reply('❌ Task or user not found.');
        }

        // Check if task is already completed
        const isCompleted = await task.isCompletedByUser(userId);
        if (isCompleted) {
            return ctx.reply('⚠️ You have already completed this task!');
        }

        switch (task.type) {
            case 'SOCIAL_MEDIA':
                // Handle social media verification
                const isVerified = await verifySocialMedia(
                    task.platform,
                    user.username,
                    task.requirements
                );

                if (isVerified) {
                    // Add reward to user
                    user.totalPoints += task.reward;
                    await user.save();

                    // Mark task as completed
                    await task.markCompleted(userId);

                    await ctx.reply(
                        '✅ Task completed successfully!\n' +
                        `You received ${task.reward} points.`
                    );
                } else {
                    await ctx.reply(
                        '❌ Verification failed.\n' +
                        'Please make sure you have completed the task requirements.'
                    );
                }
                break;

            case 'MANUAL':
                // Request screenshot for manual verification
                ctx.scene.state.taskId = taskId;
                await ctx.reply(
                    '📸 Please send a screenshot showing that you completed the task.'
                );
                break;

            default:
                await ctx.reply('❌ Unknown task type.');
        }
    } catch (error) {
        console.error('Task verification error:', error);
        await ctx.reply('❌ An error occurred during verification.');
    }
};

const getTypeEmoji = (type) => {
    switch (type) {
        case 'SOCIAL_MEDIA':
            return '📱';
        case 'MANUAL':
            return '📝';
        case 'REFERRAL':
            return '👥';
        case 'MINING':
            return '⛏️';
        default:
            return '🎯';
    }
};

// Handle screenshot verification for manual tasks
taskScene.on('photo', async (ctx) => {
    try {
        const taskId = ctx.scene.state.taskId;
        const userId = ctx.state.user._id;

        if (!taskId) {
            return ctx.reply('❌ No pending task verification.');
        }

        const task = await Task.findById(taskId);
        if (!task) {
            return ctx.reply('❌ Task not found.');
        }

        // Get the photo ID
        const photoId = ctx.message.photo[ctx.message.photo.length - 1].file_id;

        // Notify admins for manual verification
        await notifyAdmins(ctx, task, photoId);

        await ctx.reply(
            '✅ Screenshot received!\n' +
            'An admin will verify your task completion soon.'
        );

        // Clear task ID from scene state
        ctx.scene.state.taskId = null;
    } catch (error) {
        console.error('Photo handling error:', error);
        await ctx.reply('❌ An error occurred while processing your screenshot.');
    }
});

const notifyAdmins = async (ctx, task, photoId) => {
    try {
        // Get admin chat IDs from environment variables
        const adminIds = process.env.ADMIN_IDS.split(',');

        // Send verification request to all admins
        for (const adminId of adminIds) {
            await ctx.telegram.sendPhoto(adminId, photoId, {
                caption: `🔍 Task Verification Request\n\n` +
                    `Task: ${task.title}\n` +
                    `User: @${ctx.from.username}\n` +
                    `ID: ${ctx.from.id}`
            });
        }
    } catch (error) {
        console.error('Admin notification error:', error);
    }
};

module.exports = { taskScene };
