const { Scenes } = require('telegraf');
const { getProfileKeyboard } = require('../utils/keyboard');
const { formatPoints, formatDuration } = require('../utils/formatter');
const User = require('../../backend/models/User');
const Bonus = require('../../backend/models/Bonus');
const Task = require('../../backend/models/Task');

const profileScene = new Scenes.BaseScene('profile');

profileScene.enter(async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        await showProfile(ctx, userId);
    } catch (error) {
        console.error('Profile scene error:', error);
        await ctx.reply('❌ An error occurred. Please try again.');
    }
});

const showProfile = async (ctx, userId) => {
    try {
        const user = await User.findOne({ _id: userId })
            .populate('activeBoosts');

        if (!user) {
            return ctx.reply('❌ User not found.');
        }

        let message = '👤 Your Profile\n\n';
        
        // Basic Info
        message += `Username: @${user.username}\n`;
        message += `Points: ${formatPoints(user.totalPoints)}\n`;
        message += `Mining Rate: ${user.rate.toFixed(2)}/s\n`;
        
        // Mining Status
        if (user.isMining) {
            const earnedPoints = calculateEarnedPoints(user);
            message += `\n⛏️ Currently Mining\n`;
            message += `Session Points: ${formatPoints(earnedPoints)}\n`;
            message += `Mining Time: ${formatDuration(Date.now() - user.lastMiningStart)}\n`;
        }

        // Active Boosts
        if (user.activeBoosts && user.activeBoosts.length > 0) {
            message += '\n🚀 Active Boosts:\n';
            for (const boost of user.activeBoosts) {
                const timeLeft = formatDuration(boost.expiresAt - Date.now());
                message += `- ${boost.name} (${timeLeft} left)\n`;
            }
        }

        // Statistics
        const stats = await calculateStats(user);
        message += '\n📊 Statistics:\n';
        message += `Hourly: ${formatPoints(stats.hourly)}\n`;
        message += `Daily: ${formatPoints(stats.daily)}\n`;
        message += `Weekly: ${formatPoints(stats.weekly)}\n`;

        // Recent Activities
        const activities = await getRecentActivities(userId);
        if (activities.length > 0) {
            message += '\n📝 Recent Activities:\n';
            activities.forEach(activity => {
                message += formatActivity(activity);
            });
        }

        await ctx.reply(message, getProfileKeyboard());
    } catch (error) {
        console.error('Show profile error:', error);
        await ctx.reply('❌ An error occurred while loading your profile.');
    }
};

// Calculate mining points
const calculateEarnedPoints = (user) => {
    if (!user.isMining || !user.lastMiningStart) {
        return 0;
    }

    const now = new Date();
    const miningDuration = (now - user.lastMiningStart) / 1000; // in seconds
    return Math.floor(miningDuration * user.rate);
};

// Calculate statistics
const calculateStats = async (user) => {
    const now = new Date();
    const hourlyPoints = user.rate * 3600; // Points per hour
    const dailyPoints = hourlyPoints * 24;
    const weeklyPoints = dailyPoints * 7;

    return {
        hourly: hourlyPoints,
        daily: dailyPoints,
        weekly: weeklyPoints
    };
};

// Handle profile menu actions
profileScene.action('profile_stats', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const user = await User.findOne({ _id: userId });
        
        if (!user) {
            return ctx.reply('❌ User not found.');
        }

        const stats = await calculateStats(user);
        let message = '📊 Mining Statistics\n\n';
        
        message += `Mining Rate: ${user.rate.toFixed(2)}/s\n\n`;
        message += `Hourly: ${formatPoints(stats.hourly)}\n`;
        message += `Daily: ${formatPoints(stats.daily)}\n`;
        message += `Weekly: ${formatPoints(stats.weekly)}\n`;

        await ctx.editMessageText(message, getProfileKeyboard());
    } catch (error) {
        console.error('Profile stats error:', error);
        await ctx.reply('❌ An error occurred while loading statistics.');
    }
});

profileScene.action('profile_boosts', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const user = await User.findOne({ _id: userId })
            .populate('activeBoosts');

        if (!user) {
            return ctx.reply('❌ User not found.');
        }

        let message = '🚀 Active Boosts\n\n';
        
        if (user.activeBoosts && user.activeBoosts.length > 0) {
            user.activeBoosts.forEach(boost => {
                const timeLeft = formatDuration(boost.expiresAt - Date.now());
                message += `${boost.name}\n`;
                message += `Type: ${boost.type}\n`;
                message += `Effect: ${boost.type === 'MINING_RATE' ? 
                    `+${boost.rateIncrease}/s` : 
                    `+${formatDuration(boost.offlineDuration)} offline`}\n`;
                message += `Time Left: ${timeLeft}\n\n`;
            });
        } else {
            message += 'No active boosts.\n';
            message += 'Visit the boost shop to purchase boosts!';
        }

        await ctx.editMessageText(message, getProfileKeyboard());
    } catch (error) {
        console.error('Profile boosts error:', error);
        await ctx.reply('❌ An error occurred while loading boosts.');
    }
});

profileScene.action('profile_tasks', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const tasks = await Task.find({ userId, status: 'active' });

        let message = '📋 Active Tasks\n\n';
        
        if (tasks.length > 0) {
            tasks.forEach(task => {
                message += `${task.title}\n`;
                message += `Reward: ${formatPoints(task.reward)}\n`;
                message += `Progress: ${task.progress}%\n\n`;
            });
        } else {
            message += 'No active tasks.\n';
            message += 'Visit the task center to find new tasks!';
        }

        await ctx.editMessageText(message, getProfileKeyboard());
    } catch (error) {
        console.error('Profile tasks error:', error);
        await ctx.reply('❌ An error occurred while loading tasks.');
    }
});

profileScene.action('profile_bonus', async (ctx) => {
    try {
        const userId = ctx.state.user._id;
        const bonus = await Bonus.findOne({ userId });

        let message = '🎁 Daily Bonus Status\n\n';
        
        if (bonus) {
            const nextBonus = calculateNextBonus(bonus.streakDays);
            const timeUntilNext = formatDuration(bonus.nextAvailable - Date.now());
            
            message += `Current Streak: ${bonus.streakDays} days\n`;
            message += `Next Bonus: ${formatPoints(nextBonus)}\n`;
            message += `Available in: ${timeUntilNext}\n`;
        } else {
            message += 'Daily bonus is available!\n';
            message += 'Start your streak by claiming it now.';
        }

        await ctx.editMessageText(message, getProfileKeyboard());
    } catch (error) {
        console.error('Profile bonus error:', error);
        await ctx.reply('❌ An error occurred while loading bonus info.');
    }
});

// Helper functions
const calculateNextBonus = (streakDays) => {
    const baseBonus = 100;
    const streakMultiplier = Math.min(streakDays, 7) * 0.1;
    return Math.floor(baseBonus * (1 + streakMultiplier));
};

const getRecentActivities = async (userId) => {
    // Implementation for getting recent activities
    // This could include mining sessions, completed tasks, etc.
    return [];
};

const formatActivity = (activity) => {
    // Implementation for formatting activity
    return '';
};

module.exports = { profileScene };
