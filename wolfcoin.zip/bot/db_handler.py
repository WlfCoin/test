import asyncpg
import logging
from datetime import datetime
from typing import Optional, Dict
import os
import sys
import json
import aiohttp

from db_setup import (
    DB_CONFIG,  
    USER_CACHE_TIMEOUT, 
    run_migrations
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('db.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DBError(Exception):
    pass

class MemoryCache:
    def __init__(self):
        self._cache = {}
        self._timeouts = {}

    async def get(self, key: str) -> Optional[str]:
        if key in self._cache and (key not in self._timeouts or datetime.now().timestamp() <= self._timeouts[key]):
            return self._cache[key]
        self._cache.pop(key, None)
        self._timeouts.pop(key, None)
        return None

    async def set(self, key: str, value: str, timeout: int = None):
        self._cache[key] = value
        if timeout:
            self._timeouts[key] = datetime.now().timestamp() + timeout

    async def delete(self, key: str):
        self._cache.pop(key, None)
        self._timeouts.pop(key, None)

class DBHandler:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DBHandler, cls).__new__(cls)
            cls._instance.initialized = False
        return cls._instance

    def __init__(self):
        if not self.initialized:
            self.cache = MemoryCache()
            self.initialized = True

    async def get_or_create_user(self, address: str) -> dict:
        """Request to App API to get or create a user"""
        api_url = os.getenv('APP_API_URL', 'http://localhost:3000/api/auth/login')

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(api_url, json={"address": address}) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        error_msg = await response.text()
                        logger.error(f"API Error: {error_msg}")
                        raise DBError(f"Failed to get or create user via API: {error_msg}")
        except Exception as e:
            logger.error(f"Request Error: {e}")
            raise DBError(f"Failed to request API for user: {e}")

# ایجاد نمونه singleton
db = DBHandler()
