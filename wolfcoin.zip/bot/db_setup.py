import os
import logging
from dotenv import load_dotenv

# Set up logging
logger = logging.getLogger('db_handler')
logger.setLevel(logging.INFO)

load_dotenv()

# Get db URL from environment
DB_URL = os.getenv('DATABASE_URL')

# Parse db URL
if DB_URL:
    from urllib.parse import urlparse
    db_url = urlparse(DB_URL)
    DB_CONFIG = {
        'database': db_url.path[1:],
        'user': db_url.username,
        'password': db_url.password,
        'host': db_url.hostname,
        'port': db_url.port or 5432,
        'max_size': 20,
        'command_timeout': 2.0,
        'min_size': 1,
    }
else:
    # Fallback configuration
    DB_CONFIG = {
        'database': 'wolfcoin_db',
        'user': 'wolfcoin',
        'password': os.getenv('DB_PASSWORD', 'WolfCoin2025Secure'),
        'host': os.getenv('HOST', 'localhost'),
        'port': int(os.getenv('DB_PORT', 5432)),
        'max_size': 20,
        'command_timeout': 2.0,
        'min_size': 1,
    }

# Cache Configuration
USER_CACHE_TIMEOUT = 3600  # 1 hour in seconds

# Welcome Message and Points
WELCOME_BONUS = 10  # امتیاز خوش‌آمدگویی برای کاربران جدید
WELCOME_MESSAGE = "Dear Wolf, welcome to the hunt. 10 points for your joining gift."

# Table Schemas
USER_TABLE_SCHEMA = """
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        user_id BIGINT UNIQUE NOT NULL,
        username VARCHAR(255),
        balance INTEGER DEFAULT 0,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_mining BOOLEAN DEFAULT FALSE,
        mining_start_time TIMESTAMP,
        mining_end_time TIMESTAMP,
        total_mined INTEGER DEFAULT 0,
        referral_code VARCHAR(10) UNIQUE,
        referred_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
"""

TRANSACTION_TABLE_SCHEMA = """
    CREATE TABLE IF NOT EXISTS transactions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        amount INTEGER NOT NULL,
        type VARCHAR(50) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        processed_at TIMESTAMP
    );
"""

MINING_SESSION_TABLE_SCHEMA = """
    CREATE TABLE IF NOT EXISTS mining_sessions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        end_time TIMESTAMP,
        points_earned INTEGER DEFAULT 0,
        status VARCHAR(50) DEFAULT 'active'
    );
"""

BOOST_TABLE_SCHEMA = """
    CREATE TABLE IF NOT EXISTS boosts (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        multiplier DECIMAL NOT NULL,
        start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        end_time TIMESTAMP NOT NULL,
        status VARCHAR(50) DEFAULT 'active'
    );
"""

async def run_migrations(pool):
    """Run db migrations."""
    try:
        async with pool.acquire() as conn:
            await conn.execute(USER_TABLE_SCHEMA)
            await conn.execute(TRANSACTION_TABLE_SCHEMA)
            await conn.execute(MINING_SESSION_TABLE_SCHEMA)
            await conn.execute(BOOST_TABLE_SCHEMA)
            logger.info("DB migrations completed successfully")
    except Exception as e:
        logger.error(f"Error running migrations: {e}")
        raise
