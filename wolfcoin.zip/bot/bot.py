import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, WebAppInfo, KeyboardButton, ReplyKeyboardRemove
from datetime import datetime
import pytz
from dotenv import load_dotenv
import os
import schedule
import time
import random
import sys
import logging
import asyncio
from threading import Thread
from db_handler import DBHandler, DBError

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Initialize bot
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    logger.error("TELEGRAM_BOT_TOKEN is not set in environment variables")
    sys.exit(1)

# چک کردن متغیرهای محیطی ضروری
APP_URL = os.getenv("APP_URL")
if not APP_URL:
    logger.error("APP_URL is not set in environment variables")
    sys.exit(1)
elif not APP_URL.startswith("https://"):
    logger.error("APP_URL must start with https://")
    sys.exit(1)

CHANNEL_ID = os.getenv("CHANNEL_ID")
ACTIVITY_CHANNEL = os.getenv("ACTIVITY_CHANNEL")

if not CHANNEL_ID:
    logger.warning("CHANNEL_ID is not set in environment variables")
if not ACTIVITY_CHANNEL:
    logger.warning("ACTIVITY_CHANNEL is not set in environment variables")

bot = telebot.TeleBot(BOT_TOKEN)
db = DBHandler()

# Admin panel states
class AdminState:
    SEND_MESSAGE = "send_message"
    CONFIRM_MESSAGE = "confirm_message"
    SEND_REWARD = "send_reward"
    SEND_REWARD_AMOUNT = "send_reward_amount"
    BLOCK_USER = "block_user"
    CONFIRM_BLOCK = "confirm_block"
    WAITING_2FA_SETUP = "WAITING_2FA_SETUP"
    WAITING_2FA_LOGIN = "WAITING_2FA_LOGIN"
    WAITING_2FA_CODE = "WAITING_2FA_CODE"
    WAITING_2FA_VERIFY = "WAITING_2FA_VERIFY"

admin_states = {}
temp_data = {}

def is_user_in_channel(user_id):
    try:
        # چک کردن عضویت در کانال اصلی
        if not CHANNEL_ID:
            logger.error("CHANNEL_ID is not set in environment variables")
            return True  # اگر کانال تنظیم نشده باشه، اجازه دسترسی میدیم
        
        member = bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        main_channel_member = member.status in ["member", "administrator", "creator"]
        
        # چک کردن عضویت در کانال فعالیت
        if ACTIVITY_CHANNEL:
            try:
                member = bot.get_chat_member(chat_id=ACTIVITY_CHANNEL, user_id=user_id)
                activity_channel_member = member.status in ["member", "administrator", "creator"]
            except Exception as e:
                logger.error(f"Error checking activity channel membership: {e}")
                activity_channel_member = True
        else:
            activity_channel_member = True
            
        return main_channel_member and activity_channel_member
    except Exception as e:
        logger.error(f"Error checking channel membership: {e}")
        return False

def is_admin(user_id):
    try:
        current_id = int(user_id)
        result = current_id == int(os.getenv("ADMIN_ID", "0"))
        print(f"Admin check: user_id={current_id}, ADMIN_ID={os.getenv('ADMIN_ID', '0')}, result={result}")
        return result
    except Exception as e:
        print(f"Error in admin check: {e}")
        return False

def get_2fa_status(user_id):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(db.get_2fa_status(user_id))
    finally:
        loop.close()

def save_2fa_secret(user_id, secret):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(db.save_2fa_secret(user_id, secret))
    finally:
        loop.close()

@bot.message_handler(commands=['start'])
def welcome_message(message):
    user_id = message.from_user.id
    username = message.from_user.username

    if not is_user_in_channel(user_id):
        channel_id = os.getenv("CHANNEL_ID", "")
        activity_channel = os.getenv("ACTIVITY_CHANNEL", "")
        channels_text = ""
        
        if channel_id:
            channels_text += f"\n- Community Channel: @{channel_id.lstrip('@')}"
        if activity_channel:
            channels_text += f"\n- Activity Channel: @{activity_channel.lstrip('@')}"
            
        if not channels_text:
            channels_text = "\nError: Channel information not available"
            
        bot.reply_to(
            message,
            "⚠️ To enter the Wolf Coin Hunt, membership in the following channels is required:"
            f"{channels_text}\n\nPlease join and restart the bot."
        )
        return

    # Register user and process invitation
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            # Check if user was invited
            if len(message.text.split()) > 1:
                inviter_id = int(message.text.split()[1])
                if inviter_id != user_id:  # Prevent self-invitation
                    await db.invite_user(inviter_id, user_id)
                    # Add 2 points to inviter
                    await db.update_user_balance(inviter_id, 2)
                    # Send notification to activity channel
                    bot.send_message(
                        os.getenv("ACTIVITY_CHANNEL"),
                        f"🎉 New referral! User earned 2 points for inviting a new member!"
                    )
            
            # Create user
            user_data = await db.create_user(user_id, username)
            if user_data:
                bot.send_message(
                    os.getenv("ACTIVITY_CHANNEL"),
                    f"🎉 New user joined!"
                )
        except Exception as e:
            logger.error(f"Error registering user: {e}")
    finally:
        loop.close()

    try:
        # Send welcome message with photo
        photo_path = os.path.join(os.path.dirname(__file__), 'wellcombaner.jpg')
        with open(photo_path, 'rb') as photo:
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🎮 Start Mining", web_app=WebAppInfo(url=f"{os.getenv('APP_URL')}?user_id={user_id}&start_time={int(time.time())}")))
            markup.add(
                InlineKeyboardButton("Community", url=f"https://t.me/{os.getenv('CHANNEL_ID').lstrip('@')}"),
                InlineKeyboardButton("Activity", url=f"https://t.me/{os.getenv('ACTIVITY_CHANNEL').lstrip('@')}")
            )
            markup.add(
                InlineKeyboardButton("Twitter", url="https://x.com/wlfcoinofficial"),
                InlineKeyboardButton("YouTube", url="http://www.youtube.com/@WolfCoinOfficial")
            )
            markup.add(
                InlineKeyboardButton("Instagram", url="https://www.instagram.com/wolfcoin.official"),
                InlineKeyboardButton("Get Invite Link", callback_data="get_invite")
            )

            bot.send_photo(
                message.chat.id,
                photo,
                caption=(
                    "Hello, welcome to wolf hunting.\n"
                    "Stay in the pack of wolves, let everyone know that the top hunter has come, "
                    "we will show no mercy, soon those who did not join us will definitely regret it.\n"
                    "Remember this name because you will hear it a lot in the future: Wolfcoin.\n"
                    "The hunt has started. If you want to be a part of the team and not starve, start now."
                ),
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Error sending welcome message: {e}")
        # Fallback to text-only message if photo fails
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🎮 Start Mining", web_app=WebAppInfo(url=f"{os.getenv('APP_URL')}?user_id={user_id}&start_time={int(time.time())}")))
        markup.add(
            InlineKeyboardButton("Community", url=f"https://t.me/{os.getenv('CHANNEL_ID').lstrip('@')}"),
            InlineKeyboardButton("Activity", url=f"https://t.me/{os.getenv('ACTIVITY_CHANNEL').lstrip('@')}")
        )
        markup.add(
            InlineKeyboardButton("Twitter", url="https://x.com/wlfcoinofficial"),
            InlineKeyboardButton("YouTube", url="http://www.youtube.com/@WolfCoinOfficial")
        )
        markup.add(
            InlineKeyboardButton("Instagram", url="https://www.instagram.com/wolfcoin.official"),
            InlineKeyboardButton("Get Invite Link", callback_data="get_invite")
        )

        bot.send_message(
            message.chat.id,
            "Hello, welcome to wolf hunting.\n"
            "Stay in the pack of wolves, let everyone know that the top hunter has come, "
            "we will show no mercy, soon those who did not join us will definitely regret it.\n"
            "Remember this name because you will hear it a lot in the future: Wolfcoin.\n"
            "The hunt has started. If you want to be a part of the team and not starve, start now.",
            reply_markup=markup
        )

@bot.callback_query_handler(func=lambda call: call.data == "get_invite")
def generate_invite_link(call):
    user_id = call.from_user.id
    invite_link = f"https://t.me/{bot.get_me().username}?start={user_id}"
    bot.answer_callback_query(call.id)
    bot.send_message(
        call.message.chat.id,
        f"🔗 Here's your invite link:\n{invite_link}\n\nShare this link with your friends to earn bonus points!"
    )

# Admin Panel
@bot.message_handler(commands=['ad_panel'])
def admin_panel(message):
    user_id = message.from_user.id
    logger.info(f"Admin panel requested by user {user_id}")
    
    if not is_admin(user_id):
        logger.warning(f"Access denied for user {user_id}")
        bot.reply_to(message, "⚠️ You don't have permission to access this panel.")
        return

    logger.info(f"Access granted for admin {user_id}")
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("📨 Send Message to All", callback_data="admin_broadcast"))
    markup.add(InlineKeyboardButton("🎁 Send Reward", callback_data="admin_reward"))
    markup.add(InlineKeyboardButton("🚫 Block Users", callback_data="admin_block"))

    bot.reply_to(message, "👑 Admin Panel", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_"))
def admin_panel_handler(call):
    user_id = call.from_user.id
    
    if not is_admin(user_id):
        logger.warning(f"Admin panel access denied for user {user_id}")
        bot.answer_callback_query(call.id, "⚠️ Access denied")
        return

    action = call.data.split("_")[1]
    logger.info(f"Admin {user_id} selected action: {action}")

    if action == "broadcast":
        admin_states[user_id] = AdminState.SEND_MESSAGE
        bot.send_message(user_id, "Send me the message you want to send to users")

    elif action == "reward":
        admin_states[user_id] = AdminState.SEND_REWARD
        bot.send_message(user_id, "Please enter the desired username or user ID")

    elif action == "block":
        admin_states[user_id] = AdminState.BLOCK_USER
        bot.send_message(
            user_id,
            "Please send the username or numerical ID of the desired person:\n\n"
            "Send /cancel to cancel the operation."
        )

@bot.message_handler(func=lambda message: is_admin(message.from_user.id) and message.from_user.id in admin_states)
def handle_admin_actions(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        logger.warning(f"Admin action denied for user {user_id}")
        bot.reply_to(message, "⛔️ Access denied.")
        return

    if user_id in admin_states:
        state = admin_states[user_id]
        logger.info(f"Processing admin action for {user_id} in state {state}")
        
        if state == AdminState.SEND_REWARD:
            try:
                target_user = int(message.text)
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    user = loop.run_until_complete(db.get_user(target_user))
                    if user:
                        admin_states[user_id] = AdminState.SEND_REWARD_AMOUNT
                        temp_data[user_id] = target_user
                        bot.reply_to(message, "Enter reward amount:")
                        logger.info(f"Admin {user_id} preparing to send reward to user {target_user}")
                    else:
                        bot.reply_to(message, "User not found.")
                        logger.warning(f"Admin {user_id} attempted to reward non-existent user {target_user}")
                        admin_states.pop(user_id, None)
                except Exception as e:
                    logger.error(f"Database error while processing reward: {e}")
                    bot.reply_to(message, "❌ An error occurred while processing your request.")
                    admin_states.pop(user_id, None)
                finally:
                    loop.close()
            except ValueError:
                logger.warning(f"Admin {user_id} provided invalid user ID: {message.text}")
                bot.reply_to(message, "Invalid user ID. Please enter a valid number.")
                admin_states.pop(user_id, None)
        
        elif state == AdminState.SEND_REWARD_AMOUNT:
            try:
                amount = int(message.text)
                target_user_id = temp_data.get(user_id)
                
                if target_user_id:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        loop.run_until_complete(db.update_user_balance(target_user_id, amount))
                        logger.info(f"Admin {user_id} sent {amount} points to user {target_user_id}")
                        
                        bot.reply_to(message, f"✅ Successfully sent {amount} points to user {target_user_id}")
                        # Notify user about received points
                        try:
                            bot.send_message(target_user_id, f"🎁 You received {amount} points from admin!")
                            bot.send_message(
                                ACTIVITY_CHANNEL,
                                f"🎁 Admin sent {amount} points to user {target_user_id}"
                            )
                        except Exception as e:
                            logger.error(f"Failed to notify user {target_user_id}: {e}")
                    except Exception as e:
                        logger.error(f"Database error while sending reward: {e}")
                        bot.reply_to(message, "❌ An error occurred while sending the reward.")
                    finally:
                        loop.close()
                
                admin_states.pop(user_id, None)
                temp_data.pop(user_id, None)
            except ValueError:
                logger.warning(f"Admin {user_id} provided invalid amount: {message.text}")
                bot.reply_to(message, "Invalid amount. Please enter a valid number.")
                admin_states.pop(user_id, None)
                temp_data.pop(user_id, None)
        
        elif state == AdminState.BLOCK_USER:
            try:
                target_user = int(message.text)
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    user = loop.run_until_complete(db.get_user(target_user))
                    if user:
                        admin_states[user_id] = AdminState.CONFIRM_BLOCK
                        temp_data[user_id] = target_user
                        markup = InlineKeyboardMarkup()
                        markup.row(
                            InlineKeyboardButton("✅ Confirm", callback_data=f"confirm_block"),
                            InlineKeyboardButton("❌ Cancel", callback_data="cancel_block")
                        )
                        bot.reply_to(
                            message,
                            f"Are you sure you want to block user {target_user}?",
                            reply_markup=markup
                        )
                        logger.info(f"Admin {user_id} preparing to block user {target_user}")
                    else:
                        bot.reply_to(message, "User not found.")
                        logger.warning(f"Admin {user_id} attempted to block non-existent user {target_user}")
                        admin_states.pop(user_id, None)
                except Exception as e:
                    logger.error(f"Database error while processing block: {e}")
                    bot.reply_to(message, "❌ An error occurred while processing your request.")
                    admin_states.pop(user_id, None)
                finally:
                    loop.close()
            except ValueError:
                logger.warning(f"Admin {user_id} provided invalid user ID for blocking: {message.text}")
                bot.reply_to(message, "Invalid user ID. Please enter a valid number.")
                admin_states.pop(user_id, None)

@bot.callback_query_handler(func=lambda call: call.data.startswith("confirm_"))
def handle_admin_confirmations(call):
    user_id = call.from_user.id
    
    if not is_admin(user_id):
        bot.answer_callback_query(call.id, "⛔️ Access denied.")
        return

    if call.data == "confirm_block":
        target_user_id = temp_data.get(user_id)
        if target_user_id:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(db.block_user(target_user_id))
                logger.info(f"Admin {user_id} blocked user {target_user_id}")
                
                bot.edit_message_text(
                    f"✅ User {target_user_id} has been blocked.",
                    call.message.chat.id,
                    call.message.message_id
                )
                # Notify user about being blocked
                try:
                    bot.send_message(target_user_id, "⛔️ Your account has been blocked by admin.")
                    bot.send_message(
                        ACTIVITY_CHANNEL,
                        f"⛔️ Admin blocked user {target_user_id}"
                    )
                except Exception as e:
                    logger.error(f"Failed to notify user {target_user_id}: {e}")
            except Exception as e:
                logger.error(f"Database error while blocking user: {e}")
                bot.edit_message_text(
                    f"❌ Failed to block user {target_user_id}.",
                    call.message.chat.id,
                    call.message.message_id
                )
            finally:
                loop.close()
        
        admin_states.pop(user_id, None)
        temp_data.pop(user_id, None)
    
    elif call.data == "cancel_block":
        bot.edit_message_text(
            "❌ Block operation cancelled.",
            call.message.chat.id,
            call.message.message_id
        )
        admin_states.pop(user_id, None)
        temp_data.pop(user_id, None)

@bot.message_handler(commands=['login'])
def admin_login(message):
    try:
        user_id = message.from_user.id
        print(f"Login attempt by user {user_id}")  # برای دیباگ

        if not is_admin(user_id):
            print(f"User {user_id} is not admin")  # برای دیباگ
            bot.reply_to(message, "⚠️ This command is only available for administrators.")
            return

        print(f"User {user_id} is admin, checking 2FA status")  # برای دیباگ
        two_fa_secret = get_2fa_status(user_id)
        
        if not two_fa_secret:
            print(f"Setting up 2FA for user {user_id}")  # برای دیباگ
            # First time setup - store state
            admin_states[user_id] = "WAITING_2FA_SETUP"
            markup = ReplyKeyboardMarkup(resize_keyboard=True)
            markup.add(KeyboardButton('Setup 2FA'))
            
            bot.reply_to(
                message,
                "🔐 Welcome! You need to set up Two-Factor Authentication.\n"
                "Click 'Setup 2FA' to continue.",
                reply_markup=markup
            )
        else:
            print(f"2FA already set up for user {user_id}, requesting code")  # برای دیباگ
            # Already set up, ask for code
            admin_states[user_id] = "WAITING_2FA_CODE"
            markup = ReplyKeyboardRemove()
            bot.reply_to(
                message,
                "🔐 Please enter your 6-digit authentication code:",
                reply_markup=markup
            )
    except Exception as e:
        print(f"Error in admin_login: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred. Please try again later.")

@bot.message_handler(func=lambda message: message.text == 'Setup 2FA')
def setup_2fa(message):
    try:
        user_id = message.from_user.id
        print(f"Setup 2FA attempt by user {user_id}")  # برای دیباگ
        
        if not is_admin(user_id) or admin_states.get(user_id) != "WAITING_2FA_SETUP":
            print(f"Invalid setup attempt: admin={is_admin(user_id)}, state={admin_states.get(user_id)}")  # برای دیباگ
            return

        # Generate random secret
        secret = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        temp_data[user_id] = {"temp_2fa_secret": secret}
        
        markup = ReplyKeyboardRemove()
        bot.reply_to(
            message,
            f"🔐 Your secret code is: {secret}\n\n"
            "Please save this code securely and enter it back to verify:",
            reply_markup=markup
        )
        admin_states[user_id] = "WAITING_2FA_VERIFY"
    except Exception as e:
        print(f"Error in setup_2fa: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred. Please try again later.")

@bot.message_handler(func=lambda message: admin_states.get(message.from_user.id) in ["WAITING_2FA_CODE", "WAITING_2FA_VERIFY"])
def verify_2fa(message):
    try:
        user_id = message.from_user.id
        print(f"Verify 2FA attempt by user {user_id}")  # برای دیباگ
        
        if not is_admin(user_id):
            print(f"User {user_id} is not admin")  # برای دیباگ
            return

        state = admin_states.get(user_id)
        entered_code = message.text.strip()

        if state == "WAITING_2FA_VERIFY":
            # Verifying during setup
            stored_secret = temp_data.get(user_id, {}).get("temp_2fa_secret")
            if not stored_secret:
                bot.reply_to(message, "⚠️ Something went wrong. Please try /login again.")
                admin_states.pop(user_id, None)
                return

            if entered_code == stored_secret:
                save_2fa_secret(user_id, stored_secret)
                temp_data.pop(user_id, None)
                admin_states.pop(user_id, None)
                send_admin_panel(message)
            else:
                bot.reply_to(message, "❌ Invalid code. Please try again or use /login to restart.")

        elif state == "WAITING_2FA_CODE":
            # Verifying during login
            stored_secret = get_2fa_status(user_id)
            if entered_code == stored_secret:
                admin_states.pop(user_id, None)
                send_admin_panel(message)
            else:
                bot.reply_to(message, "❌ Invalid code. Please try again or use /login to restart.")
    except Exception as e:
        print(f"Error in verify_2fa: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred. Please try again later.")

def send_admin_panel(message):
    try:
        keyboard = InlineKeyboardMarkup()
        webapp_btn = InlineKeyboardButton(
            text="Open Admin Panel",
            web_app=WebAppInfo(url=f"{APP_URL}/admin")
        )
        
        keyboard.add(webapp_btn)
        bot.reply_to(
            message,
            "✅ 2FA verification successful!\n\n"
            "Welcome to the admin panel. Click below to access the management interface:",
            reply_markup=keyboard
        )
    except Exception as e:
        print(f"Error in send_admin_panel: {str(e)}")  # برای دیباگ
        bot.reply_to(message, "❌ An error occurred while opening admin panel.")

def schedule_checker():
    while True:
        try:
            schedule.run_pending()
            time.sleep(1)
        except Exception as e:
            logging.error(f"Error in schedule_checker: {e}")
            time.sleep(5)

def daily_report():
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            total_extracted = loop.run_until_complete(db.get_total_extracted())
            users = loop.run_until_complete(db.get_users())
        finally:
            loop.close()

        # Format report message
        report = (
            "📊 Daily Report\n\n"
            f"Total Extracted: {total_extracted:,} WC\n"
            f"Total Users: {len(users):,}\n"
            f"Remaining Supply: {120_000_000_000 - total_extracted:,} WC"
        )
        
        # Send report to admin
        bot.send_message(int(os.getenv("ADMIN_ID", "0")), report)
        
        # Send report to channel
        bot.send_message(CHANNEL_ID, report)
        
    except Exception as e:
        logging.error(f"Error in daily_report: {e}")

def main():
    """Initialize the bot and start running it"""
    logger.info("Initializing bot...")
    
    # Initialize database
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(db.init_db())
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        return
    finally:
        loop.close()

    # Schedule daily report
    schedule.every().day.at("00:00").do(daily_report)
    logger.info("Daily report scheduled")

    # Start the bot and scheduler in separate threads
    bot_thread = Thread(target=run_bot)
    scheduler_thread = Thread(target=run_schedule_checker)

    try:
        logger.info("Starting bot thread...")
        bot_thread.start()
        logger.info("Starting scheduler thread...")
        scheduler_thread.start()

        # Keep the main thread alive
        bot_thread.join()
        scheduler_thread.join()
    except KeyboardInterrupt:
        logger.info("Received shutdown signal")
    except Exception as e:
        logger.error(f"Error in main thread: {e}")
    finally:
        logger.info("Bot shutting down...")

def run_bot():
    """Run the Telegram bot"""
    logger.info("Bot is starting...")
    bot.infinity_polling()

def run_schedule_checker():
    """Run the schedule checker"""
    logger.info("Schedule checker is starting...")
    while True:
        try:
            schedule.run_pending()
            time.sleep(1)
        except Exception as e:
            logger.error(f"Error in schedule checker: {e}")
            time.sleep(5)  # Wait a bit before retrying

# Initialize database and start bot
if __name__ == "__main__":
    main()
