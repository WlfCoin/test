-- CreateTable
CREATE TABLE "boosts" (
    "id" TEXT NOT NULL,
    "user_id" INTEGER,
    "multiplier" DECIMAL NOT NULL,
    "start_time" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    "end_time" TIMESTAMP(6) NOT NULL,
    "status" VARCHAR(50) DEFAULT 'active',
    "type" VARCHAR(50),

    CONSTRAINT "boosts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "mining_sessions" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER,
    "start_time" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    "end_time" TIMESTAMP(6),
    "points_earned" INTEGER DEFAULT 0,
    "status" VARCHAR(50) DEFAULT 'active',

    CONSTRAINT "mining_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "transactions" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER,
    "amount" INTEGER NOT NULL,
    "type" VARCHAR(50) NOT NULL,
    "status" VARCHAR(50) DEFAULT 'pending',
    "created_at" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    "processed_at" TIMESTAMP(6),

    CONSTRAINT "transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" SERIAL NOT NULL,
    "user_id" BIGINT NOT NULL,
    "username" VARCHAR(255),
    "balance" INTEGER DEFAULT 0,
    "last_active" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    "is_mining" BOOLEAN DEFAULT false,
    "mining_start_time" TIMESTAMP(6),
    "mining_end_time" TIMESTAMP(6),
    "total_mined" INTEGER DEFAULT 0,
    "referral_code" VARCHAR(10),
    "referred_by" INTEGER,
    "created_at" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_user_id_key" ON "users"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "users_referral_code_key" ON "users"("referral_code");

-- AddForeignKey
ALTER TABLE "boosts" ADD CONSTRAINT "boosts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "mining_sessions" ADD CONSTRAINT "mining_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_referred_by_fkey" FOREIGN KEY ("referred_by") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
