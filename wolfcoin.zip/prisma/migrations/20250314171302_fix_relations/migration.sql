/*
  Warnings:

  - You are about to drop the column `end_time` on the `boosts` table. All the data in the column will be lost.
  - You are about to drop the column `multiplier` on the `boosts` table. All the data in the column will be lost.
  - You are about to drop the column `start_time` on the `boosts` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `boosts` table. All the data in the column will be lost.
  - You are about to drop the column `claimed` on the `dailyBonus` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `userBooster` table. All the data in the column will be lost.
  - You are about to drop the column `endTime` on the `userBooster` table. All the data in the column will be lost.
  - You are about to drop the column `startTime` on the `userBooster` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `userBooster` table. All the data in the column will be lost.
  - You are about to drop the column `address` on the `users` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[userId,boosterId]` on the table `userBooster` will be added. If there are existing duplicate values, this will fail.
  - Made the column `type` on table `boosts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `name` on table `boosts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `cost` on table `boosts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `rate` on table `boosts` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `bonus` to the `dailyBonus` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "boosts" DROP CONSTRAINT "boosts_user_id_fkey";

-- DropForeignKey
ALTER TABLE "userBooster" DROP CONSTRAINT "userBooster_boosterId_fkey";

-- AlterTable
ALTER TABLE "boosts" DROP COLUMN "end_time",
DROP COLUMN "multiplier",
DROP COLUMN "start_time",
DROP COLUMN "status",
ALTER COLUMN "type" SET NOT NULL,
ALTER COLUMN "type" SET DATA TYPE TEXT,
ALTER COLUMN "name" SET NOT NULL,
ALTER COLUMN "cost" SET NOT NULL,
ALTER COLUMN "rate" SET NOT NULL,
ALTER COLUMN "rate" SET DATA TYPE DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "dailyBonus" DROP COLUMN "claimed",
ADD COLUMN     "bonus" INTEGER NOT NULL,
ALTER COLUMN "createdAt" SET DATA TYPE TIMESTAMP(6);

-- AlterTable
ALTER TABLE "userBooster" DROP COLUMN "createdAt",
DROP COLUMN "endTime",
DROP COLUMN "startTime",
DROP COLUMN "updatedAt",
ALTER COLUMN "purchaseDate" DROP DEFAULT;

-- AlterTable
ALTER TABLE "users" DROP COLUMN "address";

-- CreateIndex
CREATE UNIQUE INDEX "userBooster_userId_boosterId_key" ON "userBooster"("userId", "boosterId");

-- AddForeignKey
ALTER TABLE "boosts" ADD CONSTRAINT "boosts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "userBooster" ADD CONSTRAINT "userBooster_boosterId_fkey" FOREIGN KEY ("boosterId") REFERENCES "boosts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
