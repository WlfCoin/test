-- AlterTable
ALTER TABLE "userBooster" ADD COLUMN     "expiryDate" TIMESTAMP(3);
