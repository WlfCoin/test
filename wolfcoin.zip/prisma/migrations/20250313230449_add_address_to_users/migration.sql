-- AlterTable
ALTER TABLE "users" ADD COLUMN     "address" VARCHAR(255);
