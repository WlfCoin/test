const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const currentDate = new Date();
const futureDate = new Date();
futureDate.setFullYear(futureDate.getFullYear() + 1);

const boosters = [
  { id: 'hr1', name: 'Basic Hunter', cost: 0.2, rate: 0.6, type: 'HUNTING_RATE', start_time: currentDate, end_time: futureDate },
  { id: 'hr2', name: 'Advanced Hunter', cost: 0.4, rate: 0.7, type: 'HUNTING_RATE', requiredBoosterId: 'hr1', start_time: currentDate, end_time: futureDate },
  { id: 'hr3', name: 'Expert Hunter', cost: 0.6, rate: 0.8, type: 'HUNTING_RATE', requiredBoosterId: 'hr2', start_time: currentDate, end_time: futureDate },
  { id: 'hr4', name: 'Master Hunter', cost: 0.8, rate: 0.9, type: 'HUNTING_RATE', requiredBoosterId: 'hr3', start_time: currentDate, end_time: futureDate },
  { id: 'hr5', name: 'Elite Hunter', cost: 1.0, rate: 1.0, type: 'HUNTING_RATE', requiredBoosterId: 'hr4', start_time: currentDate, end_time: futureDate },
  { id: 'hr6', name: 'Legend Hunter', cost: 1.2, rate: 1.2, type: 'HUNTING_RATE', requiredBoosterId: 'hr5', start_time: currentDate, end_time: futureDate },
  { id: 'hr7', name: 'Mythic Hunter', cost: 1.4, rate: 1.3, type: 'HUNTING_RATE', requiredBoosterId: 'hr6', start_time: currentDate, end_time: futureDate },
  { id: 'hr8', name: 'Divine Hunter', cost: 1.6, rate: 1.5, type: 'HUNTING_RATE', requiredBoosterId: 'hr7', start_time: currentDate, end_time: futureDate },
  { id: 'hr9', name: 'Celestial Hunter', cost: 1.8, rate: 1.7, type: 'HUNTING_RATE', requiredBoosterId: 'hr8', start_time: currentDate, end_time: futureDate },
  { id: 'hr10', name: 'Supreme Hunter', cost: 2.0, rate: 2.0, type: 'HUNTING_RATE', requiredBoosterId: 'hr9', start_time: currentDate, end_time: futureDate },
  { id: 'oh1', name: '6 Hours Offline', cost: 0.2, rate: 6, type: 'OFFLINE_HUNT', start_time: currentDate, end_time: futureDate },
  { id: 'oh2', name: '8 Hours Offline', cost: 0.4, rate: 8, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh1', start_time: currentDate, end_time: futureDate },
  { id: 'oh3', name: '10 Hours Offline', cost: 0.6, rate: 10, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh2', start_time: currentDate, end_time: futureDate },
  { id: 'oh4', name: '12 Hours Offline', cost: 0.8, rate: 12, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh3', start_time: currentDate, end_time: futureDate },
  { id: 'oh5', name: '14 Hours Offline', cost: 1.0, rate: 14, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh4', start_time: currentDate, end_time: futureDate },
  { id: 'oh6', name: '16 Hours Offline', cost: 1.2, rate: 16, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh5', start_time: currentDate, end_time: futureDate },
  { id: 'oh7', name: '18 Hours Offline', cost: 1.4, rate: 18, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh6', start_time: currentDate, end_time: futureDate },
  { id: 'oh8', name: '20 Hours Offline', cost: 1.6, rate: 20, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh7', start_time: currentDate, end_time: futureDate },
  { id: 'oh9', name: '22 Hours Offline', cost: 1.8, rate: 22, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh8', start_time: currentDate, end_time: futureDate },
  { id: 'oh10', name: '24 Hours Offline', cost: 2.0, rate: 24, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh9', start_time: currentDate, end_time: futureDate },
];

async function seedBoosters() {
  try {
    console.log('?? Starting booster seeding...');
    for (const booster of boosters) {
      await prisma.boosts.create({ data: booster });
    }
    console.log('? Booster seeding completed!');
  } catch (error) {
    console.error('? Error during booster seeding:', error);
  } finally {
    await prisma.$disconnect();
  }
}

seedBoosters();
